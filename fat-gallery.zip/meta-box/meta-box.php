<?php
/**  Meta Box  4.8.4 **/
if ( defined( 'ABSPATH' ) && ! class_exists( 'RWMB_Loader' ) )
{
	require plugin_dir_path( __FILE__ ) . 'inc/loader.php';
	new RWMB_Loader;
}
