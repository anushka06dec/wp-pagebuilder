<?php
global $post;
$post_id = get_the_ID();
$gallery_format = get_post_meta(get_the_ID(),'fat_gallery_format',true);
$popup_type = 'mfp-image';
$width = 475;
$height = 475;
$size = explode('x', $image_size);
if (isset($size) && count($size) > 1) {
    $width = $size[0];
    $height = $size[1];
}
$item_class = $excerpt = $attachments_meta = $attachment_id = $percent = '';
$cat_filter = isset($cat_filter) ? $cat_filter : '';
$sub_html_id = '';
$return_origin_size = isset($disable_crop_masonry) && $disable_crop_masonry;

$order = isset($order) ? $order : 'none';
$video_iframe = '';
$link_target = '_blank';

if($gallery_format=='mix'){
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    for($i=(count($meta_values['galleries']) - 1); $i>=0;$i--){
        $image = $meta_values['galleries'][$i];
        $item_class = sprintf('fat-gallery-item %s %s',$hover_effect,$cat_filter )  ;
        $url_origin = $thumbnail_url = isset($image['imgurl']) ? $image['imgurl']: '';
        $title = isset($image['title']) ? $image['title'] : '';
        $excerpt = isset($image['description']) ? $image['description'] : '';

        $video = isset($image['video']) ? $image['video'] : '' ;
        $video_iframe = isset($image['video_iframe']) ? $image['video_iframe'] : '' ;
        $popup_type = ($video=='') ? 'mfp-image' : 'mfp-iframe';
        $href = isset($image['link_detail']) ? $image['link_detail'] : '#';
        $link_target = isset($image['link_target']) ? $image['link_target'] : $link_target;
        if ($layout_type == 'masonry' &&  $url_origin!='') {
            $attachment_id = attachment_url_to_postid($image['imgurl']);
            fat_resize_constrain($attachment_id, $width, $height, $return_origin_size);
        }
        if ($url_origin != '' && (!$return_origin_size || $layout_type != 'masonry')) {
            $resize = matthewruddy_image_resize($url_origin, $width, $height);
            if ($resize != null && is_array($resize))
                $thumbnail_url = $resize['url'];
        }
        if($video!=''){
            $url_origin = $video;
        }
        $total_post++; //increase item had display for display type: full
        if(isset($limit) && $total_post>$limit && $limit > 0){
            $item_class .= ' fat-lazy-load ';
        }else{
            $item_class .=  !isset($href) || $href!='#' ? '' : ' fat-light-gallery';
        }
        $sub_html_id =  uniqid();
        $extra_class = get_post_meta($attachment_id, 'extra_class', 1);
        $extra_title_link = get_post_meta($post->ID, 'extra_title_link', 1);
        ?>
        <div class="<?php echo esc_attr($item_class) ?>" data-gallery="<?php echo esc_attr($attachment_id); ?>" data-sub-html="#<?php echo esc_attr($sub_html_id) ?>" data-src="<?php echo $url_origin; ?>" data-index="<?php echo esc_attr($total_post); ?>" >
            <?php include(plugin_dir_path(__FILE__) . '/' . $overlay_style . '.php'); ?>
            <div id="<?php echo esc_attr($sub_html_id) ?>" style="display: none">
                <div><?php echo wp_kses_post($title); ?></div>
                <div><?php echo wp_kses_post($excerpt); ?></div>
            </div>
        </div>
        <?php
    }
}
if($gallery_format=='image'){
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);

    if(isset($img_show_up) && is_array($img_show_up) && is_array($meta_values)){
        $arr_tmp = array();
        foreach($meta_values as $v){
            if(!in_array($v,$img_show_up)){
                $arr_tmp[]= $v;
                $img_show_up[] = $v;
            }
        }
        $meta_values = $arr_tmp;
    }

    if (!isset($meta_values) || !is_array($meta_values) || count($meta_values)===0 ) {
        return;
    }

    if(isset($order_by) && $order_by==='rand'){
        shuffle($meta_values);
    }
    if(isset($order_by) && $order_by==='ID'){
        if(isset($order) && $order=='ASC'){
            asort($meta_values);
        }else{
            krsort($meta_values);
        }
    }
    $order_by =  'post__in';
    $args = array(
        'orderby' => $order_by,
        'post__in' => $meta_values,
        'post_type' => 'attachment',
        'posts_per_page' => '-1',
        'post_status' => 'inherit');

    $attachments = new WP_Query($args);
    $settings = get_option(FAT_GALLERY_POST_TYPE . '-settings', array());
    while ($attachments->have_posts()) : $attachments->the_post();
        $item_class = sprintf('fat-gallery-item %s %s',$hover_effect,$cat_filter )  ;
        if(isset($settings['old_domain']) && isset($settings['new_domain']) && $settings['old_domain'] && $settings['new_domain']){
            $post->guid = str_replace($settings['old_domain'],$settings['new_domain'],$post->guid);
        }
        $url_origin = $thumbnail_url = $ex_thumbnail_url = $post->guid;
        $title = $post->post_title;
        $excerpt = $post->post_excerpt;
        $href = '';
        if ($layout_type == 'masonry' && $url_origin != '') {
            fat_resize_constrain($post->ID, $width, $height, $return_origin_size);
        }
        if ($url_origin != '' && (!$return_origin_size || $layout_type != 'masonry')) {
            $resize = matthewruddy_image_resize($url_origin, $width, $height);
            if ($resize != null && is_array($resize))
                $thumbnail_url = $resize['url'];
        }

        $total_post++; //increase item had display for display type: full
        if(isset($limit) && $total_post>$limit && $limit > 0){
            $item_class .= ' fat-lazy-load';
        }else{
            $item_class .= ' fat-light-gallery';
        }
        $sub_html_id = uniqid();
        $extra_class = get_post_meta($post->ID, 'extra_class', 1);
        $extra_title_link = get_post_meta($post->ID, 'extra_title_link', 1);
        ?>
        <div class="<?php echo esc_attr($item_class) ?>" data-gallery="<?php echo esc_attr($post->ID); ?>" data-sub-html="#<?php echo esc_attr($sub_html_id) ?>" data-src="<?php echo $url_origin; ?>"  data-index="<?php echo esc_attr($total_post); ?>">
            <?php include(plugin_dir_path(__FILE__) . '/' . $overlay_style . '.php'); ?>
            <div id="<?php echo esc_attr($sub_html_id) ?>" style="display: none">
                <div><?php echo wp_kses_post($title); ?></div>
                <div><?php echo wp_kses_post($excerpt); ?></div>
            </div>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
}

?>