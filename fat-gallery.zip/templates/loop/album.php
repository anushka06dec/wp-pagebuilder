<?php
global $post;

$gallery_format = get_post_meta(get_the_ID(), 'fat_gallery_format', true);

$total_item_of_album = isset($total_item_of_album) && is_numeric($total_item_of_album) ? $total_item_of_album : 9;

if ($gallery_format == 'mix') {
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    $index = 0;
    foreach ($meta_values['galleries'] as $image) {
        $index++;
        $thumb_class = $index <= $total_item_of_album ? 'thumb-show' : 'thumb-hide';
        $url_origin = $thumbnail_url = $image['imgurl'];
        $resize = matthewruddy_image_resize($thumbnail_url, $image_width, $image_height);
        if ($resize != null && is_array($resize))
            $thumbnail_url = $resize['url'];
        $title = $image['title'];
        ?>
        <a href="<?php echo esc_url($url_origin) ?>" class="fat-light-gallery <?php echo esc_attr($thumb_class) ?>"
           title="<?php echo esc_attr($title) ?>">
            <img src="<?php echo esc_url($thumbnail_url) ?>" title="<?php echo esc_attr($title) ?>" />
        </a>
        <?php
    }
}
$order = isset($order) ? $order : 'none';
if ($gallery_format == 'image') {
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);
    if (!isset($meta_values) || !is_array($meta_values) || count($meta_values) == 0) {
        return;
    }
    $args = array(
        'orderby'        => 'post__in',
        'order'          => $order,
        'post__in'       => $meta_values,
        'post_type'      => 'attachment',
        'posts_per_page' => '-1',
        'post_status'    => 'inherit');

    $attachments = new WP_Query($args);
    $index = 0;
    while ($attachments->have_posts()) : $attachments->the_post();
        $index++;
        $thumb_class = $index <= $total_item_of_album ? 'thumb-show' : 'thumb-hide';
        $url_origin = $thumbnail_url = $post->guid;
        $resize = matthewruddy_image_resize($thumbnail_url, $image_width, $image_height);
        if ($resize != null && is_array($resize))
            $thumbnail_url = $resize['url'];
        $title = $post->post_title;
        ?>
        <a href="<?php echo esc_url($url_origin) ?>" class="fat-light-gallery <?php echo esc_attr($thumb_class) ?>"
           title="<?php echo esc_attr($title) ?>">
            <img src="<?php echo esc_url($thumbnail_url) ?>" title="<?php echo esc_attr($title) ?>" />
        </a>
        <?php
    endwhile;
    wp_reset_postdata();
}

?>