<?php
$post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
$extra_class = get_post_meta($post_thumbnail_id, 'extra_class', 1);
$popup_type = 'mfp-image';
$arrImages = wp_get_attachment_image_src($post_thumbnail_id, 'full');
$title = get_the_title();
$excerpt = get_the_excerpt();
$width = 475;
$height = 475;
$thumbnail_url = $video_iframe = '';
$return_origin_size = isset($disable_crop_masonry) && $disable_crop_masonry;

if ($layout_type != 'masonry') {
    $size = explode('x', $image_size);
    if (isset($size) && count($size) > 1) {
        $width = $size[0];
        $height = $size[1];
    }
    if (count($arrImages) > 0) {
        $resize = matthewruddy_image_resize($arrImages[0], $width, $height);
        if ($resize != null && is_array($resize))
            $thumbnail_url = $resize['url'];
    }
} elseif (count($arrImages) > 0) {
    $thumbnail_url = $arrImages[0];
    fat_resize_constrain($post_thumbnail_id, $width, $height, $return_origin_size);
    $resize = matthewruddy_image_resize($arrImages[0], $width, $height);
    if ($resize != null && is_array($resize))
        $thumbnail_url = $resize['url'];
}
$url_origin = $arrImages[0];
$video=''; //reset icon before write overlay
?>
<div class="fat-gallery-item fat-light-gallery-compact <?php echo esc_attr($hover_effect); ?> gallery-<?php echo esc_attr($post_thumbnail_id); ?>  <?php if(isset($cat_filter)) { echo esc_attr($cat_filter); } ?>"
     data-src="<?php echo esc_url($url_origin); ?>"
     data-gallery="<?php echo esc_attr($post_thumbnail_id); ?>">
    <?php include(plugin_dir_path(__FILE__) . '/' . $overlay_style . '.php'); ?>
    <div class="hide">
        <?php include(plugin_dir_path(__FILE__) . '/gallery.php'); ?>
    </div>
</div>