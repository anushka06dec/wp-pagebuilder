<?php
global $post;
$settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
$gallery_format = get_post_meta(get_the_ID(), 'fat_gallery_format', true);
$width = $height = 475;
$disable_crop_masonry = isset($settings['disable_crop_masonry']) && $settings['disable_crop_masonry']==='1' ? true : false;
if ($gallery_format == 'mix') {
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    if (is_array($meta_values) && count($meta_values) > 0) {
        foreach ($meta_values['galleries'] as $image) {
            $url_origin = $thumbnail_url = isset($image['imgurl']) ? $image['imgurl'] : '';
            $title = isset($image['title']) ? $image['title'] : '';
            $description = isset($image['description']) ? $image['description'] : '';
            $attachment_id = attachment_url_to_postid($image['imgurl']);
            $size = wp_get_attachment_metadata($attachment_id);
            if(isset($size['width']) && isset($size['height'])){
                $width = $size['width'];
                $height = $size['height'];
            }
            $data_size = $width.'x'.$height;
            fat_resize_constrain($post->ID, $width, $height, false);
            $resize = matthewruddy_image_resize($url_origin, $width, $height);
            if ($resize != null && is_array($resize))
                $thumbnail_url = $resize['url'];
            if ($thumbnail_url == '') {
                break;
            }
            ?>
            <div class="fat-gallery-item fat-light-gallery  <?php echo esc_attr($cat_filter) ?>"
                 data-size="<?php echo esc_attr($data_size) ?>">
                <div class="fat-thumbnail">
                    <div class="fat-thumbnail-hover">
                        <div class="fat-hover-outer">
                            <div class="fat-hover-inner line-height-1">
                                <div class="fat-gallery-icon">
                                    <a href="<?php echo esc_url($url_origin) ?>" title="<?php echo esc_attr($title) ?>">
                                        <i class="<?php if (isset($video) && $video != '') {
                                            echo 'fa fa-play-circle-o';
                                        } else {
                                            echo 'fa fa-search';
                                        } ?>"></i>
                                    </a>
                                </div>
                                <div class="fat-gallery-title">
                                    <h5><?php echo sprintf('%s', $title) ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo esc_url($url_origin) ?>" class="img-wrap">
                        <img src="<?php echo esc_url($thumbnail_url) ?>" alt="<?php echo sprintf('%s', $title); ?>" />
                        <div class="description description--grid">
                            <h3><?php echo sprintf('%s', $title) ?></h3>
                            <div class="desc">
                                <?php echo sprintf('%s', $description); ?>
                            </div>

                        </div>
                    </a>
                </div>

            </div>
            <?php
        }
    }
}

if ($gallery_format == 'image') {
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);
    if(isset($img_show_up) && is_array($img_show_up) && is_array($meta_values)){
        $arr_tmp = array();
        foreach($meta_values as $v){
            if(!in_array($v,$img_show_up)){
                $arr_tmp[]= $v;
                $img_show_up[] = $v;
            }
        }
        $meta_values = $arr_tmp;
    }

    if (!isset($meta_values) || !is_array($meta_values) || count($meta_values)===0 ) {
        return;
    }

    $order_by = 'post__in';
    $args = array(
        'orderby'        => $order_by,
        'post__in'       => $meta_values,
        'post_type'      => 'attachment',
        'posts_per_page' => '-1',
        'post_status'    => 'inherit');

    $attachments = new WP_Query($args);
    while ($attachments->have_posts()) : $attachments->the_post();
        $url_origin = $thumbnail_url = $post->guid;
        $title = $post->post_title;
        $description = $post->post_content;
        $size = wp_get_attachment_metadata($post->ID);
        if(isset($size['width']) && isset($size['height'])){
            $width = $size['width'];
            $height = $size['height'];
        }
        $data_size = $width.'x'.$height;
        fat_resize_constrain($post->ID, $width, $height, false);
        $resize = matthewruddy_image_resize($url_origin, $width, $height);
        if ($resize != null && is_array($resize))
            $thumbnail_url = $resize['url'];
        if ($thumbnail_url == '') {
            break;
        }
        ?>
        <div class="fat-gallery-item  <?php echo isset($cat_filter) ? esc_attr($cat_filter) : '' ?>"
             data-size="<?php echo esc_attr($data_size) ?>">
            <div class="fat-thumbnail">
                <div class="fat-thumbnail-hover">
                    <div class="fat-hover-outer">
                        <div class="fat-hover-inner line-height-1">
                            <div class="fat-gallery-icon">
                                <a href="<?php echo esc_url($url_origin) ?>" title="<?php echo esc_attr($title) ?>">
                                    <i class="<?php if (isset($video) && $video != '') {
                                        echo 'fa fa-play-circle-o';
                                    } else {
                                        echo 'fa fa-search';
                                    } ?>"></i>
                                </a>
                            </div>
                            <div class="fat-gallery-title">
                                <h5><?php echo sprintf('%s', $title) ?></h5>
                            </div>
                        </div>
                    </div>
                </div>

                <a href="<?php echo esc_url($url_origin) ?>" class="img-wrap">
                    <img src="<?php echo esc_url($thumbnail_url) ?>" alt="<?php echo sprintf('%s', $title); ?>" />

                    <div class="description description--grid">
                        <h3><?php echo sprintf('%s', $title) ?></h3>
                        <div class="desc">
                            <?php echo sprintf('%s', $description); ?>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
}

?>