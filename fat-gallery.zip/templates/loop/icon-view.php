<?php
$thumbnail_hover_class = 'fat-thumbnail-hover';
$is_extend_link = false;
if (isset($href) && $href != '#' && $href !='' && $gallery_format=='mix') {
    $url_origin = $href;
    $is_extend_link = true;
}

$link_class = (!isset($href) || $href=='#' || $href=='') ? 'magnific-popup ' : '';
if(isset($video_iframe) && $video_iframe!=''){
    $link_class.= ' video-iframe';
}

$extra_class = isset($extra_class) ? $extra_class : '';
$extra_title_link = isset($extra_title_link) ? $extra_title_link : '';
$excerpt = isset($excerpt) ? $excerpt : '';
$post_thumbnail_id = isset($post_thumbnail_id) && $display_type=='' ? $post_thumbnail_id : $post_id;
$link_target = isset($link_target) ? $link_target : '_blank';

?>
<div class="fat-thumbnail <?php echo esc_attr($extra_class); ?>" data-width="<?php echo esc_attr($width) ?>"
     data-height="<?php echo esc_attr($height) ?>" data-lazy-src="<?php echo esc_url($thumbnail_url) ?>"
     data-alt="<?php echo esc_attr($title) ?>"
>
    <a class="fat-image-clickable" href="<?php echo ($is_extend_link ? $url_origin : 'javascript:void(0)'); ?>"></a>
    <?php if ($display_type == '' || !isset($limit) || $total_post <= $limit || $limit < 0) : ?>
        <img width="<?php echo esc_attr($width) ?>" height="<?php echo esc_attr($height) ?>"
             src="<?php echo esc_url($thumbnail_url) ?>" alt="<?php echo esc_attr($title) ?>" />
    <?php endif; ?>
    <div class="<?php echo esc_attr($thumbnail_hover_class) ?>">
        <div class="fat-hover-outer">
            <div class="fat-hover-inner line-height-1">
                <div class="fat-gallery-icon">
                    <a href="<?php echo esc_url($url_origin) ?>" target="<?php echo esc_attr($link_target); ?>"  data-exthumbimage="<?php echo esc_url($url_origin) ?>"
                       class="<?php echo esc_attr($link_class) ?> <?php echo esc_attr($popup_type) ?> gallery-<?php echo esc_attr($post_thumbnail_id)?>"
                       data-gallery="<?php echo esc_attr($post_thumbnail_id); ?>"
                       data-iframe = '<?php echo esc_attr($video_iframe); ?>'
                       data-extra-title-link="<?php echo esc_attr($extra_title_link);?>"
                       data-excerpt = "<?php echo esc_attr($excerpt); ?>"
                       title="<?php echo esc_attr($title) ?>">
                        <i class="<?php if ( (isset($video) && $video != '') || (isset($video_iframe) && $video_iframe != '') ){
                            echo 'fa fa-play-circle-o';
                        } else {
                            echo 'fa fa-search';
                        } ?>"></i>
                    </a>
                </div>
                <?php if (!isset($hide_title) || !$hide_title)  : ?>
                    <div class="fat-gallery-title">
                        <?php if (isset($href)) : ?>
                            <a href="<?php echo esc_url($href) ?>" target="<?php echo esc_attr($link_target); ?>">
                                <h5><?php echo sprintf('%s', $title) ?></h5>
                            </a>
                        <?php else: ?>
                            <h5><?php echo sprintf('%s', $title) ?></h5>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($excerpt) && (!isset($hide_excerpt) || !$hide_excerpt)): ?>
                    <div class="fat-gallery-excerpt">
                        <?php echo wp_kses_post($excerpt); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>