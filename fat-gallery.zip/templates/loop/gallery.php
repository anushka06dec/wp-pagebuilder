<?php
$gallery_format = get_post_meta(get_the_ID(), 'fat_gallery_format', true);
$popup_type = 'mfp-image';
$post_thumbnail_id = isset($post_thumbnail_id) ? $post_thumbnail_id : 0;
if ($gallery_format == 'mix') {
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    if (count($meta_values) > 0) {
        foreach ($meta_values['galleries'] as $image) {
            $url_origin = isset($image['imgurl']) ? $image['imgurl'] : '';
            $title = isset($image['title']) ? $image['title'] : '';
            $video = isset($image['video']) ? $image['video'] : '';
            $popup_type = ($video == '') ? 'mfp-image' : 'mfp-iframe';
           /* if ($video != '') {
                $url_origin = $video;
            }*/
            $video = $video !='' ? $video : $url_origin;
            if ($url_origin == '') {
                continue;
            }
            ?>
            <div >
                <a href="<?php echo esc_url($video) ?>" data-exthumbimage="<?php echo esc_url($url_origin) ?>"  class="magnific-popup <?php echo esc_attr($popup_type) ?> gallery-<?php echo esc_attr($post_thumbnail_id); ?>"
                   title="<?php echo esc_attr($title) ?>">
                </a>
            </div>
            <?php
        }
    }
}
if ($gallery_format == 'image') {
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);
    if (!isset($meta_values) || !is_array($meta_values) || count($meta_values) == 0) {
        return;
    }

    $args_attachment = array(
        'orderby' => 'post__in',
        'post__in' => $meta_values,
        'post_type' => 'attachment',
        'posts_per_page' => '-1',
        'post_status' => 'inherit');

    $attachments = new WP_Query($args_attachment);
    global $post;
    while ($attachments->have_posts()) : $attachments->the_post();
        $extra_title_link = get_post_meta($post->ID, 'extra_title_link', 1);
        ?>
        <div >
            <a href="<?php echo esc_url($post->guid) ?>" data-exthumbimage="<?php echo esc_url($post->guid) ?>"  data-gallery="<?php echo esc_attr($post_thumbnail_id); ?>" class="magnific-popup <?php echo esc_attr($popup_type) ?> gallery-<?php echo esc_attr($post_thumbnail_id); ?>"
               title="<?php echo esc_attr($post->post_title) ?>" data-extra-title-link="<?php echo esc_attr($extra_title_link);?>"  data-excerpt="<?php echo esc_attr($post->post_content) ?>"></a>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
}
?>