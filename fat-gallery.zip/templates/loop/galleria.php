<?php
global $post;

$gallery_format = get_post_meta(get_the_ID(), 'fat_gallery_format', true);
$popup_type = 'mfp-image';
$link_target = '_blank';
if ($gallery_format == 'mix') {
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    foreach ($meta_values['galleries'] as $image) {
        $url_origin = $thumbnail_url = $image['imgurl'];
        $title = $image['title'];
        $video = isset($image['video']) ? $image['video'] : '';
        $popup_type = ($video == '') ? 'mfp-image' : 'mfp-iframe';
        $link_target = isset($image['link_target']) ? $image['link_target'] : $link_target;
        if ($video != '') {
            $url_origin = $video;
        }
        ?>
        <img src="<?php echo esc_url($url_origin) ?>" />
        <?php
    }
}
if ($gallery_format == 'image') {
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);
    if (!isset($meta_values) || !is_array($meta_values) || count($meta_values) == 0) {
        return;
    }
    $args = array(
        'orderby'        => 'post__in',
        'post__in'       => $meta_values,
        'post_type'      => 'attachment',
        'posts_per_page' => '-1',
        'post_status'    => 'inherit');

    $attachments = new WP_Query($args);

    while ($attachments->have_posts()) : $attachments->the_post();
        $url_origin = $post->guid;
        $title = $post->post_title;
        ?>
        <img src="<?php echo esc_url($url_origin) ?>" />
        <?php
    endwhile;
    wp_reset_postdata();
}

?>