<?php
global $post;

$gallery_format = get_post_meta(get_the_ID(),'fat_gallery_format',true);
$popup_type = 'mfp-image';
$width = 475;
$height = 475;
$size = explode('x', $image_size);
if (isset($size) && count($size) > 1) {
    $width = $size[0];
    $height = $size[1];
}
$link_target = '_blank';
if($gallery_format=='mix'){
    $meta_values = get_post_meta(get_the_ID(), 'fat_gallery_acf', true);
    foreach ($meta_values['galleries'] as $image) {
        ?>
        <div class="fat-gallery-item hover-dir <?php echo esc_attr($cat_filter) ?>">
            <?php
            $url_origin = $thumbnail_url = $image['imgurl'];
            $title = $image['title'];
            $video = isset($image['video']) ? $image['video'] : '' ;
            $popup_type = ($video=='') ? 'mfp-image' : 'mfp-iframe';
            $link_target = isset($image['link_target']) ? $image['link_target'] : $link_target;
            if ($layout_type != 'masonry') {
                if ($url_origin != '') {
                    $resize = matthewruddy_image_resize($url_origin, $width, $height);
                    if ($resize != null && is_array($resize))
                        $thumbnail_url = $resize['url'];
                }
            }
            if($video!=''){
                $url_origin = $video;
            }
            include(plugin_dir_path(__FILE__) . '/' . $overlay_style . '.php');

            ?>

        </div>
        <?php
    }
}
if($gallery_format=='image'){
    $meta_values = get_post_meta(get_the_ID(), 'galleries', false);
    if(!isset($meta_values) || !is_array($meta_values) || count($meta_values) ==0 ){
        return;
    }
    $args = array(
        'orderby' => 'post__in',
        'post__in' => $meta_values,
        'post_type' => 'attachment',
        'posts_per_page' => '-1',
        'post_status' => 'inherit');

    $attachments = new WP_Query($args);

    while ($attachments->have_posts()) : $attachments->the_post(); ?>
        <div class="fat-gallery-item hover-dir <?php echo isset($cat_filter) ? esc_attr($cat_filter) : '' ?>">
            <?php
            $url_origin = $thumbnail_url = $post->guid;
            $title = $post->post_title;
            if ($layout_type != 'masonry') {
                if ($url_origin != '') {
                    $resize = matthewruddy_image_resize($url_origin, $width, $height);
                    if ($resize != null && is_array($resize))
                        $thumbnail_url = $resize['url'];
                }
            }
            include(plugin_dir_path(__FILE__) . '/overlay/' . $overlay_style . '.php');
            ?>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
}

?>