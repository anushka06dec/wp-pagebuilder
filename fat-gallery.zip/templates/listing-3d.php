<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/24/2016
 * Time: 10:02 PM
 */
$args = array(
    'offset' => 0,
    'orderby' => 'post__in',
    'post__in' => explode(",", $gallery_ids),
    'posts_per_page' => -1,
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');

if ($data_source == '') {
    $args = array(
        'offset' => 0,
        'posts_per_page' => -1,
        'post_type' => FAT_GALLERY_POST_TYPE,
        FAT_GALLERY_CATEGORY_TAXONOMY => strtolower($category),
        'post_status' => 'publish');
}

$posts_array = new WP_Query($args);
$data_section_id = uniqid();

$width = 480;
$height = $gallery_3d_enable_window == 'bg-window' ? 260 : 320;
if(isset($atts['image_width']) && $atts['image_width'] != ''){
    $width = $atts['image_width'];
}
if(isset($atts['image_height']) && $atts['image_height'] != ''){
    $height = $atts['image_height'];
}

?>
<div class="fat-gallery gallery-3d overflow-hidden <?php echo esc_attr($gallery_3d_enable_window) ?> " style="opacity: 0" id="fat-gallery-<?php echo esc_attr($data_section_id) ?>">
    <div class="dg-wrapper">
        <?php
        $template_path = plugin_dir_path(__FILE__) . 'loop/3d.php';
        while ($posts_array->have_posts()) : $posts_array->the_post();
            if (file_exists($template_path)) {
                include($template_path);
            }
            ?>
            <?php
        endwhile;
        wp_reset_postdata();
        ?>
    </div>
    <nav class="<?php echo esc_attr($nav_position); ?>">
        <span class="dg-prev"><i class="fa fa-chevron-left"></i></span>
        <span class="dg-next"><i class="fa fa-chevron-right"></i></span>
    </nav>
</div>
<?php if(isset($atts['image_height']) && $atts['image_height'] != '' && isset($atts['image_width']) && $atts['image_width'] != '' ) : ?>
<style type="text/css">
    #fat-gallery-<?php echo esc_attr($data_section_id) ?> .dg-wrapper{
        width: <?php echo esc_attr($atts['image_width']); ?>px;
        height: <?php echo esc_attr($atts['image_height']); ?>px;
    }
    #fat-gallery-<?php echo esc_attr($data_section_id) ?> .dg-wrapper a{
         width:  <?php echo esc_attr($atts['image_width']); ?>px;
    }
</style>
<?php endif; ?>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('#fat-gallery-<?php echo esc_attr($data_section_id) ?>').gallery({
            autoplay: <?php echo esc_attr($auto_play); ?>
        });
        jQuery('#fat-gallery-<?php echo esc_attr($data_section_id) ?>').css('opacity',1);
    })
</script/>

