<?php
$args = array(
    'offset' => 0,
    'orderby' => 'post__in',
    'post__in' => explode(",", $gallery_ids),
    'posts_per_page' => -1,
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');

if ($data_source == '') {
    $args = array(
        'offset' => 0,
        'post_type' => FAT_GALLERY_POST_TYPE,
        'posts_per_page' => -1,
        FAT_GALLERY_CATEGORY_TAXONOMY => strtolower($category),
        'post_status' => 'publish');
}

$posts_array = new WP_Query($args);
$data_section_id = uniqid();
$loading_color = '#333';
if(isset($fat_settings) && isset($fat_settings['loading_color'])){
    $loading_color = $fat_settings['loading_color'];
}
$column_of_album = isset($column_of_album) && is_numeric($column_of_album) ? $column_of_album : 3;
$image_width = 80;
$image_height = 60;
$arr_image_size = explode('x',$image_size);
if(!is_null($arr_image_size) && is_array($arr_image_size) && count($arr_image_size)==2){
    $image_width = $arr_image_size[0];
    $image_height = $arr_image_size[1];
}
$col_class = 'fat-col-md-' . $column . ' album-col-'.$column_of_album;
$all_category_filter = apply_filters( 'wpml_translate_single_string', $all_category_filter, 'fat-gallery', 'All gallery');
?>
<div class="fat-gallery album overflow-hidden <?php echo esc_attr($padding) ?>" id="fat-gallery-<?php echo esc_attr($data_section_id) ?>">

    <?php if ($show_category != '') { ?>
        <div class="fat-gallery-tabs">
            <?php
            $termIds = array();
            $portfolio_terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY);
            if ($category != '') {
                $slugSelected = explode(',', $category);
                foreach($slugSelected as $term_slug){
                    foreach ($portfolio_terms as $term) {
                        if ($term->slug == $term_slug)
                            $termIds[$term->term_id] = $term->term_id;
                    }
                }
            }
            $array_terms = array(
                'include' => $termIds,
                'orderby' => 'include'
            );
            $terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY, $array_terms);

            if (count($terms) > 0) { ?>
                <div
                    class="tab-wrapper line-height-1 <?php echo esc_attr($show_category) ?> ">
                    <ul class="fat-mg-bottom-50">
                        <li class="active">
                            <a class="isotope-fat-gallery ladda-button active "
                               data-section-id="<?php echo esc_attr($data_section_id) ?>"
                               data-load-type="<?php echo esc_attr($filter_type) ?>"
                               data-category="<?php echo strtolower($category) ?>"
                               data-filter="*"
                               data-padding="<?php echo esc_attr($padding) ?>"
                               data-source="<?php echo esc_attr($data_source) ?>"
                               data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                               data-image-size="<?php echo esc_attr($image_size) ?>"
                               data-column="<?php echo esc_attr($column) ?>"
                               data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                               href="javascript:">
                                <?php echo wp_kses_post($all_category_filter); ?>
                            </a>
                        </li>
                        <?php
                        foreach ($terms as $term) {
                            ?>
                            <li>
                                <a class="isotope-food ladda-button "
                                   href="javascript:"
                                   data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                   data-load-type="<?php echo esc_attr($filter_type) ?>"
                                   data-category="<?php echo strtolower($category) ?>"
                                   data-filter=".<?php echo esc_attr($term->slug) ?>"
                                   data-padding="<?php echo esc_attr($padding) ?>"
                                   data-source="<?php echo esc_attr($data_source) ?>"
                                   data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                   data-image-size="<?php echo esc_attr($image_size) ?>"
                                   data-column="<?php echo esc_attr($column) ?>"
                                   data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                >

                                    <?php echo wp_kses_post($term->name) ?>
                                </a>
                            </li>
                        <?php } ?>
                    </ul>

                    <select>
                        <option value=""
                                data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                data-load-type="<?php echo esc_attr($filter_type) ?>"
                                data-category="<?php echo strtolower($category) ?>"
                                data-filter="*"
                                data-padding="<?php echo esc_attr($padding) ?>"
                                data-source="<?php echo esc_attr($data_source) ?>"
                                data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                data-image-size="<?php echo esc_attr($image_size) ?>"
                                data-column="<?php echo esc_attr($column) ?>"
                                data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                        >
                            <?php echo wp_kses_post($all_category_filter); ?>
                        </option>
                        <?php foreach ($terms as $term) { ?>
                            <option value=''
                                    data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                    data-load-type="<?php echo esc_attr($filter_type) ?>"
                                    data-category="<?php echo strtolower($category) ?>"
                                    data-filter=".<?php echo esc_attr($term->slug) ?>"
                                    data-padding="<?php echo esc_attr($padding) ?>"
                                    data-source="<?php echo esc_attr($data_source) ?>"
                                    data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                    data-image-size="<?php echo esc_attr($image_size) ?>"
                                    data-column="<?php echo esc_attr($column) ?>"
                                    data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                <?php if ($category == $term->slug) {
                                    echo 'selected';
                                } ?>
                            ><?php echo wp_kses_post($term->name) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <?php
            }
            ?>
        </div>
    <?php } ?>

    <div
        class="fat-gallery-wrapper <?php echo esc_attr($col_class) ?>"
        data-section-id="<?php echo esc_attr($data_section_id) ?>"
        id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>" >

        <?php
        $template_path = plugin_dir_path(__FILE__) . 'loop/album.php';
        $album_detail_page = $cat = $cat_filter = $item_class = '';
        while ($posts_array->have_posts()) : $posts_array->the_post();
            $terms = wp_get_post_terms(get_the_ID(), array(FAT_GALLERY_CATEGORY_TAXONOMY));
            $cat = $cat_filter = '';
            $album_detail_page = get_post_meta(get_the_ID(), 'fat_gallery_album_page', true);
            foreach ($terms as $term) {
                $cat_filter .= preg_replace('/\s+/', '', $term->slug) . ' ';
            }
            $item_class = $album_detail_page!=='' ? 'fat-thumbnail' : 'fat-gallery-item-inner';
            if (file_exists($template_path)): ?>
                <div class="fat-gallery-item <?php echo esc_attr($cat_filter); ?>">
                    <div class="<?php echo esc_attr($item_class); ?>">
                        <div class="inner album-item <?php echo sprintf('%s %s', $has_box_shadow, $has_padding) ?>">
                            <?php if (isset($album_detail_page) && $album_detail_page !== ''): ?>
                                <div class="fat-thumbnail-hover">
                                    <div class="fat-hover-outer">
                                        <div class="fat-hover-inner line-height-1">
                                            <div class="fat-gallery-title">
                                                <a class="link-to-album" href="<?php echo esc_url($album_detail_page);?>"><?php the_title();?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php include($template_path); ?>
                        </div>
                    </div>
                </div>
            <?php endif;
        endwhile;
        wp_reset_postdata();
        ?>

    </div>
</div>
<script type="text/javascript">
    (function ($) {
        "use strict";
        $(document).ready(function () {
            FatGallery.initAlbum('<?php echo esc_attr($data_section_id)?>', 'light-gallery', 'lg-slide');
            $('.fat-gallery-item .fat-thumbnail-hover','#fat-gallery-container-' + '<?php echo esc_attr($data_section_id)?>').on('click',function(){
                var link_to_album = $('a.link-to-album',this).attr('href');
                if(typeof link_to_album!=='undefined' && link_to_album!=''){
                    window.location.href = link_to_album;
                }

            })
        })
    })(jQuery);
</script>
