<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 02/02/16
 * Time: 11:05 AM
 */

$settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
$loading_color = '#333';
if (isset($settings) && isset($settings['loading_color'])) {
    $loading_color = $settings['loading_color'];
}
$hide_title = isset($settings['hide_title']) && $settings['hide_title'] === '1' ? true : false;
$hide_excerpt = isset($settings['hide_excerpt']) && $settings['hide_excerpt'] === '1' ? true : false;
$disable_crop_masonry = isset($settings['disable_crop_masonry']) && $settings['disable_crop_masonry'] === '1' ? true : false;
$all_category_filter = isset($settings['all_category_filter']) ? $settings['all_category_filter'] : 'All';
$popup_image_action = isset($settings['popup_image_action']) ? $settings['popup_image_action'] : 'fat-gallery-move';
$order_by = isset($order_by) && $order_by != 'none' && $order_by != '' ? $order_by : 'post__in';

if(isset($_GET['ajax_load']) && $_GET['ajax_load']=='1'){
    $current_category = isset($_GET['category']) && $_GET['category'] ?  $_GET['category'] : '';
}else{
    $category_filter = isset($filter_type) && $filter_type === 'ajax' ? $default_category : $category;
    $current_category = $default_category;
}


$args = array(
    'orderby' => $order_by,
    'post__in' => explode(",", $gallery_ids),
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish'
);

if ($data_source == '') {
    $order_by = isset($order_by) ? $order_by : 'none';
    $args = array(
        'orderby' => $order_by,
        'order' => $order,
        'post_type' => FAT_GALLERY_POST_TYPE,
        FAT_GALLERY_CATEGORY_TAXONOMY => strtolower($category_filter),
        'post_status' => 'publish');

}

if ($layout_type == 'codo-effect' || $item === '') {
    $args['offset'] = 0;
    $post_per_page = -1;
}

$args['offset'] = $offset;
$args['posts_per_page'] = $post_per_page;

$posts_array = new WP_Query($args);
$total_post = $display_type === '' || $item === '' ? $posts_array->found_posts : 0;
$col_class = '';
$col_class = 'fat-col-md-' . $column;
$data_section_id = uniqid();
$paging_style = 'paging';

$all_category_filter = apply_filters('wpml_translate_single_string', $all_category_filter, 'fat-gallery', 'All gallery');

?>
<div
        class="fat-gallery overflow-hidden <?php echo sprintf('%s %s %s', $padding, $paging_style, $popup_image_action) ?>"
        id="fat-gallery-<?php echo esc_attr($data_section_id) ?>">
    <?php if ($show_category != '') { ?>
        <div class="fat-gallery-tabs">
            <?php
            $termIds = array();
            $portfolio_terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY);
            if ($category != '') {
                $slugSelected = explode(',', $category);
                foreach ($slugSelected as $term_slug) {
                    foreach ($portfolio_terms as $term) {
                        if ($term->slug == $term_slug)
                            $termIds[$term->term_id] = $term->term_id;
                    }
                }
            }
            $array_terms = array(
                'include' => $termIds,
                'orderby' => 'include'
            );
            $terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY, $array_terms);
            if (count($terms) > 0) { ?>
                <div
                        class="tab-wrapper line-height-1 <?php echo esc_attr($show_category) ?> ">
                    <ul class="fat-mg-bottom-30">
                        <?php if ($show_root_category=='1'): ?>
                            <li>
                                <a class="isotope-fat-gallery ladda-button <?php echo($current_category === '' || $current_category === $category ? 'active' : ''); ?> <?php echo esc_attr($category_style); ?>"
                                   data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                   data-load-type="<?php echo esc_attr($filter_type) ?>"
                                   data-category="<?php echo strtolower($category) ?>"
                                   data-filter="*"
                                   data-display-type="<?php echo esc_attr($display_type) ?>"
                                   data-padding="<?php echo esc_attr($padding) ?>"
                                   data-overlay-style="<?php echo esc_attr($overlay_style) ?>"
                                   data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                   data-title-style="<?php echo esc_attr($title_style) ?>"
                                   data-source="<?php echo esc_attr($data_source) ?>"
                                   data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                   data-layout-type="<?php echo esc_attr($layout_type) ?>"
                                   data-image-size="<?php echo esc_attr($image_size) ?>"
                                   data-current-page="1"
                                   data-offset="<?php echo esc_attr($offset) ?>"
                                   data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
                                   data-column="<?php echo esc_attr($column) ?>"
                                   data-order-by="<?php echo esc_attr($order_by) ?>"
                                   data-order="<?php echo esc_attr($order) ?>"
                                   data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                   data-animation-filter="<?php echo esc_attr($animation_filter) ?>"
                                   data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                   data-effect="<?php echo esc_attr($detail_effect) ?>"
                                   href="javascript:">
                                    <?php echo wp_kses_post($all_category_filter); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php
                        foreach ($terms as $term) {
                            ?>
                            <li>
                                <a class="isotope-food ladda-button <?php echo($current_category === $term->slug ? 'active' : ''); ?> <?php echo esc_attr($category_style); ?> "
                                   href="javascript:" data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                   data-load-type="<?php echo esc_attr($filter_type) ?>"
                                   data-category="<?php echo esc_attr($term->slug) ?>"
                                   data-display-type="<?php echo esc_attr($display_type) ?>"
                                   data-filter=".<?php echo esc_attr($term->slug) ?>"
                                   data-padding="<?php echo esc_attr($padding) ?>"
                                   data-overlay-style="<?php echo esc_attr($overlay_style) ?>"
                                   data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                   data-title-style="<?php echo esc_attr($title_style) ?>"
                                   data-source="<?php echo esc_attr($data_source) ?>"
                                   data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                   data-layout-type="<?php echo esc_attr($layout_type) ?>"
                                   data-image-size="<?php echo esc_attr($image_size) ?>"
                                   data-current-page="1"
                                   data-offset="<?php echo esc_attr($offset) ?>"
                                   data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
                                   data-column="<?php echo esc_attr($column) ?>"
                                   data-order-by="<?php echo esc_attr($order_by) ?>"
                                   data-order="<?php echo esc_attr($order) ?>"
                                   data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                   data-animation-filter="<?php echo esc_attr($animation_filter) ?>"
                                   data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                   data-effect="<?php echo esc_attr($detail_effect); ?>"
                                >

                                    <?php echo wp_kses_post($term->name) ?>
                                </a>
                            </li>
                        <?php } ?>
                    </ul>

                    <select>
                        <?php if ($show_root_category=='1'): ?>
                            <option value=""
                                    data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                    data-load-type="<?php echo esc_attr($filter_type) ?>"
                                    data-category=""
                                    data-filter="*"
                                    data-display-type="<?php echo esc_attr($display_type) ?>"
                                    data-padding="<?php echo esc_attr($padding) ?>"
                                    data-overlay-style="<?php echo esc_attr($overlay_style) ?>"
                                    data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                    data-title-style="<?php echo esc_attr($title_style) ?>"
                                    data-source="<?php echo esc_attr($data_source) ?>"
                                    data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                    data-layout-type="<?php echo esc_attr($layout_type) ?>"
                                    data-image-size="<?php echo esc_attr($image_size) ?>"
                                    data-current-page="1"
                                    data-offset="<?php echo esc_attr($offset) ?>"
                                    data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
                                    data-column="<?php echo esc_attr($column) ?>"
                                    data-order-by="<?php echo esc_attr($order_by) ?>"
                                    data-order="<?php echo esc_attr($order) ?>"
                                    data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                    data-animation-filter="<?php echo esc_attr($animation_filter) ?>"
                                    data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                    data-effect="<?php echo esc_attr($detail_effect) ?>"
                            >
                                <?php echo wp_kses_post($all_category_filter); ?>
                            </option>
                        <?php endif; ?>
                        <?php foreach ($terms as $term) { ?>
                            <option value=''
                                    data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                    data-load-type="<?php echo esc_attr($filter_type) ?>"
                                    data-category="<?php echo esc_attr($term->slug) ?>"
                                    data-filter=".<?php echo esc_attr($term->slug) ?>"
                                    data-display-type="<?php echo esc_attr($display_type) ?>"
                                    data-padding="<?php echo esc_attr($padding) ?>"
                                    data-overlay-style="<?php echo esc_attr($overlay_style) ?>"
                                    data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                    data-title-style="<?php echo esc_attr($title_style) ?>"
                                    data-source="<?php echo esc_attr($data_source) ?>"
                                    data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                    data-layout-type="<?php echo esc_attr($layout_type) ?>"
                                    data-image-size="<?php echo esc_attr($image_size) ?>"
                                    data-current-page="1"
                                    data-offset="<?php echo esc_attr($offset) ?>"
                                    data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
                                    data-column="<?php echo esc_attr($column) ?>"
                                    data-order-by="<?php echo esc_attr($order_by) ?>"
                                    data-order="<?php echo esc_attr($order) ?>"
                                    data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                    data-animation-filter="<?php echo esc_attr($animation_filter) ?>"
                                    data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                    data-effect="<?php echo esc_attr($detail_effect) ?>"
                                <?php if ($category == $term->slug) {
                                    echo 'selected';
                                } ?>
                            ><?php echo wp_kses_post($term->name) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <?php
            }
            ?>
        </div>
        <div class="fat-gallery-tab-desc">
            <ul>
                <?php foreach ($terms as $term) {
                    if ($term->description) {
                        ?>
                        <li class="<?php echo esc_attr($term->slug) ?> <?php echo($current_category === $term->slug ? 'active' : ''); ?>"><?php echo esc_html($term->description); ?></li>
                    <?php }
                }
                ?>
            </ul>
        </div>
    <?php } ?>
    <?php
    $settings = get_option(FAT_GALLERY_POST_TYPE . '-settings', array());
    ?>
    <div
            class="fat-gallery-wrapper <?php echo sprintf('%s %s %s', $col_class, $layout_type, $bg_color) ?>"
            data-section-id="<?php echo esc_attr($data_section_id) ?>"
            id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>"
            data-columns="<?php echo esc_attr($column) ?>" style="opacity: 0"
            data-hide-download="<?php echo isset($settings['hide_download']) ? $settings['hide_download'] : 0;?>"
            data-hide-fullscreen="<?php echo isset($settings['hide_fullscreen']) ? $settings['hide_fullscreen'] : 0;?>"
            data-hide-zoom="<?php echo isset($settings['hide_zoom_icon']) ? $settings['hide_zoom_icon'] : 0;?>"
            data-hide-autoplay="<?php echo isset($settings['hide_autoplay']) ? $settings['hide_autoplay'] : 0;?>"
            data-hide-share="<?php echo isset($settings['hide_share_icon']) ? $settings['hide_share_icon'] : 0;?>"
            data-hide-image-counter="<?php echo isset($settings['hide_image_counter']) ? $settings['hide_image_counter'] : 0;?>"
    >
        <?php

        $ext = ($display_type != '' || $layout_type == 'codo-effect') ? '-full.php' : '.php';
        if ($layout_type == 'grid' || $layout_type == 'masonry') {
            $template_path = plugin_dir_path(__FILE__) . 'loop/grid' . $ext;
        } else {
            $template_path = plugin_dir_path(__FILE__) . 'loop/' . $layout_type . $ext;
        }

        $limit = $current_page * $post_per_page; //limit show item for display type: full
        $img_show_up = array();
        while ($posts_array->have_posts()) : $posts_array->the_post();
            $terms = wp_get_post_terms(get_the_ID(), array(FAT_GALLERY_CATEGORY_TAXONOMY));
            $cat = $cat_filter = '';
            foreach ($terms as $term) {
                $cat_filter .= preg_replace('/\s+/', '', $term->slug) . ' ';
                $cat .= $term->name . ', ';
            }
            $cat = rtrim($cat, ', ');
            if (file_exists($template_path)) {
                include($template_path);
            }
            ?>
        <?php
        endwhile;
        wp_reset_postdata();
        ?>

    </div>

    <?php
    $total_page = 1;
    if ($post_per_page > 0) {
        $total_page = floor($total_post / $post_per_page);
        if ($total_post % $post_per_page > 0) {
            $total_page++;
        }
    }
    if ($show_pagging == '1' && $total_page > 1 && $total_page > $current_page) { ?>
        <div style="clear: both"></div>
        <div class="paging fat-mg-top-30" id="load-more-<?php echo esc_attr($data_section_id) ?>">
            <a href="javascript:" class="ladda-button load-more <?php echo esc_attr($display_type); ?>"
               data-load-type="load-more"
               data-source="<?php echo esc_attr($data_source) ?>"
               data-display-type="<?php echo esc_attr($display_type) ?>"
               data-overlay-style="<?php echo esc_attr($overlay_style) ?>"
               data-bg-color="<?php echo esc_attr($bg_color) ?>"
               data-title-style="<?php echo esc_attr($title_style) ?>"
               data-category="<?php echo esc_attr($category); ?>"
               data-padding="<?php echo esc_attr($padding) ?>"
               data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
               data-section-id="<?php echo esc_attr($data_section_id) ?>"
               data-current-page="<?php echo esc_attr($current_page + 1) ?>"
               data-offset="<?php echo esc_attr($offset) ?>"
               data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
               data-column="<?php echo esc_attr($column); ?>"
               data-padding="<?php echo esc_attr($padding) ?>"
               data-layout-type="<?php echo esc_attr($layout_type) ?>"
               data-image-size="<?php echo esc_attr($image_size) ?>"
               data-order-by="<?php echo esc_attr($order_by) ?>"
               data-order="<?php echo esc_attr($order) ?>"
               data-show-paging="<?php echo esc_attr($show_pagging) ?>"
               data-animation-filter="<?php echo esc_attr($animation_filter) ?>"
               data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
               data-effect="<?php echo esc_attr($detail_effect) ?>"
               data-filter-type="<?php echo esc_attr($filter_type) ?>"
               data-show-category="<?php echo esc_attr($show_category) ?>"
               data-total-page="<?php echo esc_attr($total_page) ?>"
            >
                <?php
                $view_more = isset($settings['view_more']) ? $settings['view_more'] : esc_html__('VIEW MORE', 'fat-gallery');
                $view_more = apply_filters('wpml_translate_single_string', $view_more, 'fat-gallery', 'View more');
                echo esc_attr($view_more); ?>
            </a>
        </div>
    <?php } ?>

</div>

<?php if (isset($ajax_load) && $ajax_load == '0') { ?>
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $(document).ready(function () {
                var $container = jQuery('#fat-gallery-container-<?php echo esc_attr($data_section_id) ?>');
                jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();


                <?php if ($layout_type == 'codo-effect') { ?>
                var $prev_code_effect = '<div class="preview-codo-effect" data-id="<?php echo esc_attr($data_section_id) ?>">';
                $prev_code_effect += '<button class="codo-action codo-action--close"><i class="fa fa-times"></i><span class="text-hidden"><?php esc_html_e('Close', 'fat-gallery')?></span> </button>';
                $prev_code_effect += '<div class="description description--preview"></div>';
                $prev_code_effect += '</div>';
                $('body').append($prev_code_effect);

                <?php } ?>

                FatGallery.init('<?php echo esc_url(get_site_url() . '/wp-admin/admin-ajax.php')?>', '<?php echo esc_attr($data_section_id)?>', '<?php echo esc_attr($detail_effect) ?>', '<?php echo esc_attr($popup_transition) ?>');
                <?php if(($filter_type == 'isotope' && $show_category != '') || $layout_type == 'masonry' || $layout_type == 'codo-effect'){ ?>

                $container.imagesLoaded(function () {
                    $container.isotope({
                        itemSelector: '.fat-gallery-item'
                    }).isotope('layout')
                });

                <?php  if( (isset($_GET['category']) && $_GET['category'] !== '') || $default_category!==''){
                $_GET['category'] = isset($_GET['category']) && $_GET['category'] !== '' ? isset($_GET['category']) && $_GET['category'] !== '' : $default_category;
                    ?>
                $container.isotope({filter: '<?php echo sprintf('.%s', $_GET['category']); ?>'});
                <?php } ?>

                setTimeout(function () {
                    try {
                        $container.isotope('layout');
                    } catch (err) {
                    }
                }, 500);
                <?php } ?>
                $container.css('opacity', '1');
            })
        })(jQuery);
    </script>
<?php } ?>
