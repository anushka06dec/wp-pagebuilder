<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/24/2016
 * Time: 10:02 PM
 */
$args = array(
    'offset' => 0,
    'orderby' => 'post__in',
    'post__in' => explode(",", $gallery_ids),
    'posts_per_page' => -1,
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');

if ($data_source == '') {
    $args = array(
        'offset' => 0,
        'posts_per_page' => -1,
        'post_type' => FAT_GALLERY_POST_TYPE,
        FAT_GALLERY_CATEGORY_TAXONOMY => strtolower($category),
        'post_status' => 'publish');
}

$posts_array = new WP_Query($args);
$data_section_id = uniqid();
$class_wrap = $nav_position;
$total_post = $posts_array->found_posts;
$cat_filter = '';

$settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
$loading_color = '#333';
if(isset($settings) && isset($settings['loading_color'])){
    $loading_color = $settings['loading_color'];
}
$hide_title = isset($settings['hide_title']) && $settings['hide_title']==='1' ? true : false;
$hide_excerpt = isset($settings['hide_excerpt']) && $settings['hide_excerpt']==='1' ? true : false;
$popup_image_action = isset($settings['popup_image_action']) ? $settings['popup_image_action'] : 'fat-gallery-move';
$class_wrap .= isset($atts['two_halves']) && $atts['two_halves']=='true' ? ' two-halves-style': '';

?>
<div class="fat-gallery fat-slider overflow-hidden <?php echo sprintf('%s %s',$popup_image_action, $class_wrap); ?>" style="opacity: 0" id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>">
    <div class="slider-wrapper owl-carousel">
        <?php
        $ext = $display_type != '' ? '-full.php' : '.php';
        $template_path = plugin_dir_path(__FILE__) . 'loop/grid'. $ext;
        $img_show_up = array();
        while ($posts_array->have_posts()) : $posts_array->the_post();
            if (file_exists($template_path)) {
                include($template_path);
            }
            ?>
            <?php
        endwhile;
        wp_reset_postdata();
        ?>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();
        FatGallery.initCarousel(
            '<?php echo esc_attr($data_section_id)?>',
            'magnificPopup',
            <?php echo esc_attr($auto_play) ?>,
            <?php echo esc_attr($loop) ?>,
            <?php echo esc_attr($margin) ?>,
            <?php echo esc_attr($center) ?>,
            <?php echo esc_attr($show_nav) ?>,
            <?php echo esc_attr($show_dot) ?>,
            <?php echo esc_attr($columns) ?>
        );
    })
</script/>
