<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/21/2016
 * Time: 10:41 PM
 */
global $post;


$settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
$loading_color = '#333';
if(isset($settings) && isset($settings['loading_color'])){
    $loading_color = $settings['loading_color'];
}
$all_category_filter = isset($settings['all_category_filter']) ? $settings['all_category_filter'] : 'All';
$order_by = isset($order_by) && $order_by!='none' ? $order_by : 'post__in';
$args = array(
    'orderby'     => 'post__in',
    'post__in'    => explode(",", $gallery_ids),
    'post_type'   => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');

if ($data_source == '') {
    $args = array(
        'orderby'                     => $order_by,
        'order'                       => $order,
        'post_type'                   => FAT_GALLERY_POST_TYPE,
        FAT_GALLERY_CATEGORY_TAXONOMY => strtolower($category),
        'post_status'                 => 'publish');
}

$args['offset'] = $offset;
$args['posts_per_page'] = $post_per_page;

$posts_array = new WP_Query($args);
$total_post = 0;//$posts_array->found_posts;
$data_section_id = uniqid();
$hide_title = isset($settings['hide_title']) && $settings['hide_title'] === '1' ? true : false;
$hide_excerpt = isset($settings['hide_excerpt']) && $settings['hide_excerpt'] === '1' ? true : false;
$disable_crop_masonry = isset($settings['disable_crop_masonry']) && $settings['disable_crop_masonry']==='1' ? true : false;
$popup_image_action = isset($settings['popup_image_action']) ? $settings['popup_image_action'] : 'fat-gallery-move';

$limit = $attachments = $meta_values = $item_class = $is_lazy_load = $url_origin = $thumbnail_url = '';

$limit = $current_page * $post_per_page; //limit show item for display type: full
$all_category_filter = apply_filters( 'wpml_translate_single_string', $all_category_filter, 'fat-gallery', 'All gallery');
?>
<div class="fat-gallery-justified-wrap <?php echo esc_attr($popup_image_action); ?>">
    <?php if ($show_category != '') { ?>
        <div class="fat-gallery-tabs">
            <?php
            $termIds = array();
            $portfolio_terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY);
            if ($category != '') {
                $slugSelected = explode(',', $category);
                foreach($slugSelected as $term_slug){
                    foreach ($portfolio_terms as $term) {
                        if ($term->slug == $term_slug)
                            $termIds[$term->term_id] = $term->term_id;
                    }
                }
            }
            $array_terms = array(
                'include' => $termIds,
                'orderby' => 'include'
            );
            $terms = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY, $array_terms);

            if (count($terms) > 0) { ?>
                <div
                    class="tab-wrapper line-height-1 <?php echo esc_attr($show_category) ?> ">
                    <ul class="fat-mg-bottom-50">
                        <li class="active">
                            <a class="ladda-button active <?php echo esc_attr($category_style); ?>"
                               data-section-id="<?php echo esc_attr($data_section_id) ?>"
                               data-category="<?php echo strtolower($category) ?>"
                               data-margin="<?php echo esc_attr($margin) ?>"
                               data-row-height="<?php echo esc_attr($row_height) ?>"
                               data-bg-color="<?php echo esc_attr($bg_color) ?>"
                               data-title-style="<?php echo esc_attr($title_style) ?>"
                               data-source="<?php echo esc_attr($data_source) ?>"
                               data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                               data-item="<?php echo esc_attr($item) ?>"
                               data-order-by = "<?php echo esc_attr($order_by) ?>"
                               data-order="<?php echo esc_attr($order) ?>"
                               data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                               data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                               href="javascript:">
                                <?php echo wp_kses_post($all_category_filter); ?>
                            </a>
                        </li>
                        <?php
                        foreach ($terms as $term) {
                            ?>
                            <li>
                                <a class="ladda-button <?php echo esc_attr($category_style); ?>"
                                   data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                   data-category="<?php echo esc_attr($term->slug) ?>"
                                   data-margin="<?php echo esc_attr($margin) ?>"
                                   data-row-height="<?php echo esc_attr($row_height) ?>"
                                   data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                   data-title-style="<?php echo esc_attr($title_style) ?>"
                                   data-source="<?php echo esc_attr($data_source) ?>"
                                   data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                   data-item="<?php echo esc_attr($item) ?>"
                                   data-order-by = "<?php echo esc_attr($order_by) ?>"
                                   data-order="<?php echo esc_attr($order) ?>"
                                   data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                   data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                   href="javascript:">
                                    <?php echo wp_kses_post($term->name) ?>
                                </a>
                            </li>
                        <?php } ?>
                    </ul>

                    <select data-section-id="<?php echo esc_attr($data_section_id) ?>">
                        <option value=""
                                data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                data-category=""
                                data-margin="<?php echo esc_attr($margin) ?>"
                                data-row-height="<?php echo esc_attr($row_height) ?>"
                                data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                data-title-style="<?php echo esc_attr($title_style) ?>"
                                data-source="<?php echo esc_attr($data_source) ?>"
                                data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                data-item="<?php echo esc_attr($item) ?>"
                                data-order-by = "<?php echo esc_attr($order_by) ?>"
                                data-order="<?php echo esc_attr($order) ?>"
                                data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                        >
                            <?php echo wp_kses_post($all_category_filter); ?>
                        </option>
                        <?php foreach ($terms as $term) { ?>
                            <option value=''
                                    data-section-id="<?php echo esc_attr($data_section_id) ?>"
                                    data-category="<?php echo esc_attr($term->slug) ?>"
                                    data-margin="<?php echo esc_attr($margin) ?>"
                                    data-row-height="<?php echo esc_attr($row_height) ?>"
                                    data-bg-color="<?php echo esc_attr($bg_color) ?>"
                                    data-title-style="<?php echo esc_attr($title_style) ?>"
                                    data-source="<?php echo esc_attr($data_source) ?>"
                                    data-gallery-ids="<?php echo esc_attr($gallery_ids) ?>"
                                    data-item="<?php echo esc_attr($item) ?>"
                                    data-order-by = "<?php echo esc_attr($order_by) ?>"
                                    data-order="<?php echo esc_attr($order) ?>"
                                    data-style="zoom-out" data-spinner-color="<?php echo esc_attr($loading_color) ?>"
                                    data-show-paging="<?php echo esc_attr($show_pagging) ?>"
                                <?php if ($category == $term->slug) {
                                    echo 'selected';
                                } ?>
                            ><?php echo wp_kses_post($term->name) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <?php
            }
            ?>
        </div>
        <div class="fat-gallery-tab-desc">
            <ul>
                <?php foreach ($terms as $term) {
                    if ($term->description) {
                        ?>
                        <li class="<?php echo esc_attr($term->slug) ?> <?php echo($current_category === $term->slug ? 'active' : ''); ?>"><?php echo esc_html($term->description); ?></li>
                    <?php }
                }
                ?>
            </ul>
        </div>
    <?php } ?>

    <div class="fat-gallery-justified" id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>">
        <?php while ($posts_array->have_posts()) : $posts_array->the_post();
            $post_id = get_the_ID();
            $meta_values = get_post_meta($post_id, 'galleries', false);
            if (!isset($meta_values) || !is_array($meta_values) || count($meta_values) == 0) {
                break;
            }
            $args = array(
                'orderby'        => 'post__in',
                'post__in'       => $meta_values,
                'post_type'      => 'attachment',
                'posts_per_page' => '-1',
                'post_status'    => 'inherit');

            $attachments = new WP_Query($args);
            $width = 475;
            $height = 475;
            $img_show_up = array();
            while ($attachments->have_posts()) : $attachments->the_post();
                $url_origin = $thumbnail_url = $post->guid;
                $title = $post->post_title;
                $total_post++; //increase item had display for display type: full
                $item_class = 'fat-gallery-item';
                $is_lazy_load = isset($limit) && $total_post > $limit && $limit > 0;
                if ($is_lazy_load) {
                    $item_class .= ' fat-lazy-load';
                } else {
                    $item_class .= ' fat-light-gallery';
                }

                if(!$disable_crop_masonry){
                    fat_resize_constrain($post->ID, $width, $height);
                    if ($url_origin != '') {
                        $resize = matthewruddy_image_resize($url_origin, $width, $height);
                        if ($resize != null && is_array($resize))
                            $thumbnail_url = $resize['url'];
                    }
                }
                ?>
                <div id="<?php echo sprintf('item-%s-%s',$post_id,$post->ID);?>" class="<?php echo esc_attr($item_class); ?>" data-src="<?php echo $url_origin; ?>"
                     data-lazy-src="<?php echo esc_url($thumbnail_url) ?>">
                    <?php if (!$is_lazy_load): ?>
                        <img alt="<?php echo esc_attr($title) ?>" src="<?php echo esc_url($thumbnail_url); ?>" />
                    <?php endif; ?>
                    <div class="fat-thumbnail">
                        <div class="fat-thumbnail-hover">
                            <div class="fat-hover-outer">
                                <div class="fat-hover-inner line-height-1">
                                    <div class="fat-gallery-icon">
                                        <a href="javascript:" title="<?php echo esc_attr($title) ?>">
                                            <i class="fa fa-search"></i>
                                        </a>
                                    </div>
                                    <?php if (!isset($hide_title) || !$hide_title)  : ?>
                                        <div class="fat-gallery-title">
                                            <?php if (isset($href)) : ?>
                                                <a href="<?php echo esc_url($href) ?>">
                                                    <h5><?php echo sprintf('%s', $title) ?></h5>
                                                </a>
                                            <?php else: ?>
                                                <h5><?php echo sprintf('%s', $title) ?></h5>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (isset($excerpt) && (!isset($hide_excerpt) || !$hide_excerpt)): ?>
                                        <div class="fat-gallery-excerpt">
                                            <?php echo wp_kses_post($excerpt); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>
        <?php endwhile;
        wp_reset_postdata();
        ?>
    </div>

    <?php if ( isset($limit) && $total_post > $limit && $limit > 0): ?>
        <div class="paging paging-justified fat-mg-top-30" id="load-more-<?php echo esc_attr($data_section_id) ?>">
            <a href="javascript:" data-current-page="<?php echo esc_attr($current_page + 1) ?>"
               data-post-per-page="<?php echo esc_attr($post_per_page) ?>"
               data-total-post="<?php echo esc_attr($total_post) ?>"
            >
                <?php
                $view_more = isset($settings['view_more']) ? $settings['view_more'] : esc_html__('VIEW MORE', 'fat-gallery');
				$view_more = apply_filters( 'wpml_translate_single_string', $view_more, 'fat-gallery', 'View more');
                echo esc_attr($view_more); ?>
            </a>
        </div>
    <?php endif; ?>
</div>


<?php if($ajax_load!='1'): ?>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            FatGallery.initJustified('<?php echo esc_url(get_site_url() . '/wp-admin/admin-ajax.php')?>', '<?php echo esc_attr($data_section_id) ?>', '<?php echo esc_attr($row_height) ?>', '<?php echo esc_attr($margin) ?>');
        });
    </script>
<?php endif; ?>

