<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/21/2016
 * Time: 10:41 PM
 */

$args = array(
    'offset'         => $offset,
    'orderby'        => 'post__in',
    'post__in'       => explode(",", $gallery_ids),
    'posts_per_page' => $post_per_page,
    'post_type'      => FAT_GALLERY_POST_TYPE,
    'post_status'    => 'publish');

$posts_array = new WP_Query($args);
$total_post = $posts_array->found_posts;
$col_class = 'fat-col-md-' . $column;
$data_section_id = uniqid();

$settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
$loading_color = '#333';
if(isset($settings) && isset($settings['loading_color'])){
    $loading_color = $settings['loading_color'];
}
$hide_title = isset($settings['hide_title']) && $settings['hide_title']==='1' ? true : false;
$hide_excerpt = isset($settings['hide_excerpt']) && $settings['hide_excerpt']==='1' ? true : false;
$disable_crop_masonry = isset($settings['disable_crop_masonry']) && $settings['disable_crop_masonry']==='1' ? true : false;
$popup_image_action = isset($settings['popup_image_action']) ? $settings['popup_image_action'] : 'fat-gallery-move';

?>
    <div class="fat-gallery overflow-hidden  <?php echo sprintf('%s %s',$padding,$popup_image_action);?>"
         id="fat-gallery-<?php echo esc_attr($data_section_id) ?>">
        <div
            class="fat-gallery-wrapper <?php echo sprintf('%s %s', $col_class, $layout_type) ?>"
            data-section-id="<?php echo esc_attr($data_section_id) ?>"
            id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>"
            data-columns="<?php echo esc_attr($column) ?>" style="opacity: 0">

            <?php
            $template_path = '';
            $ext = '.php';
            if ($display_type != '' || $layout_type == 'codo-effect')
                $ext = '-full' . $ext;
            if ($layout_type == 'grid' || $layout_type == 'masonry') {
                $template_path = plugin_dir_path(__FILE__) . 'loop/grid' . $ext;
            } else {
                $template_path = plugin_dir_path(__FILE__) . 'loop/' . $layout_type . $ext;
            }
            $img_show_up = array();

            while ($posts_array->have_posts()) : $posts_array->the_post();
                if (file_exists($template_path)) {
                    include($template_path);
                }
                ?>
                <?php
            endwhile;
            wp_reset_postdata();

            ?>

        </div>


    </div>

<?php if (isset($ajax_load) && $ajax_load == '0') { ?>
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $(document).ready(function () {
                jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();

                <?php if ($layout_type == 'codo-effect') { ?>
                    var $prev_code_effect = '<div class="preview-codo-effect">';
                    $prev_code_effect. = '<button class="codo-action codo-action--close"><i class="fa fa-times"></i><span class="text-hidden"><?php esc_html_e('Close', 'fat-gallery')?></span> </button>';
                    $prev_code_effect. = '<div class="description description--preview"></div>';
                    $prev_code_effect. = '</div>';
                    $('body').appendChild($prev_code_effect);
                <?php } ?>

                var $container = jQuery('#fat-gallery-container-<?php echo esc_attr($data_section_id) ?>');
                FatGallery.init('<?php echo esc_url(get_site_url() . '/wp-admin/admin-ajax.php')?>', '<?php echo esc_attr($data_section_id)?>', '<?php echo esc_attr($detail_effect) ?>', '<?php echo esc_attr($popup_transition) ?>');
                <?php if( ($filter_type == 'isotope' && $show_category!='') || $layout_type == 'masonry' || $layout_type == 'codo-effect'){ ?>

                $container.imagesLoaded(function () {
                    $container.isotope({
                        itemSelector: '.fat-gallery-item'
                    }).isotope('layout')
                });
                setTimeout(function(){
                    try{
                        $container.isotope('layout');
                    }catch(err){}
                },500);
                <?php } ?>
                $container.css('opacity', '1');
            })
        })(jQuery);
    </script>
<?php } ?>