<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/21/2016
 * Time: 10:41 PM
 */

$args = array(
    'offset' => 0,
    'orderby' => 'post__in',
    'post__in' => explode(",", $gallery_ids),
    'posts_per_page' => -1,
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');

$posts_array = new WP_Query($args);
$data_section_id = uniqid();
?>
    <div class="fat-gallery galleria overflow-hidden" id="fat-gallery-<?php echo esc_attr($data_section_id) ?>">
        <div
            class="fat-gallery-wrapper"
            data-section-id="<?php echo esc_attr($data_section_id) ?>"
            id="fat-gallery-container-<?php echo esc_attr($data_section_id) ?>" >

            <?php
            $template_path = plugin_dir_path(__FILE__) . 'loop/galleria.php';
            while ($posts_array->have_posts()) : $posts_array->the_post();
                if (file_exists($template_path)) {
                    include($template_path);
                }
                ?>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>

        </div>
    </div>
<script type="text/javascript">
    (function ($) {
        "use strict";
        $(document).ready(function () {
            var $container = jQuery('#fat-gallery-container-<?php echo esc_attr($data_section_id) ?>');
            FatGallery.initGalleria('<?php echo esc_attr($data_section_id)?>', '<?php echo esc_attr($width) ?>','<?php echo esc_attr($height) ?>');
        })
    })(jQuery);
</script>