<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 3/20/15
 * Time: 4:53 PM
 */

if (!function_exists('roninwp_gallery_load_by_category')) {
    function roninwp_gallery_load_by_category()
    {
        $displayType = $_REQUEST['displayType'];
        $overlay_style = $_REQUEST['overlay_style'];
        $current_page = $_REQUEST['current_page'];
        $dataSource = $_REQUEST['data_source'];
        $show_paging = $_REQUEST['data_show_paging'];
        $galleryIds = $_REQUEST['galleryIds'];
        $posts_per_page = $_REQUEST['postsPerPage'];
        $layout_type = $_REQUEST['layoutType'];
        $column = $_REQUEST['columns'];
        $padding = $_REQUEST['colPadding'];
        $category = $_REQUEST['category'];
        $order_by = isset($_REQUEST['order_by']) ? $_REQUEST['order_by'] : 'none' ;
        $order = $_REQUEST['order'];
        $bgColor = $_REQUEST['bgColor'];
        $titleStyle = $_REQUEST['titleStyle'];
        $imageSize = $_REQUEST['imageSize'];
        $animationFilter = $_REQUEST['animationFilter'];
        $detailEffect = $_REQUEST['detailEffect'];
        $short_code = sprintf('[fat_adv_gallery display_type ="%s" overlay_style="%s" category="%s" column="%s" item="%s" show_pagging="%s" padding="%s" current_page="%s"  order_by = "%s" order="%s" data_source="%s" gallery_ids = "%s"
                            ajax_load="%s" bg_color="%s" title_style = "%s" animation_filter= "%s" image_size="%s" layout_type = "%s" detail_effect = "%s" ]', $displayType, $overlay_style,
            $category, $column, $posts_per_page, $show_paging, $padding, $current_page, $order_by, $order, $dataSource, $galleryIds, 1, $bgColor, $titleStyle,
            $animationFilter, $imageSize, $layout_type, $detailEffect);

        echo do_shortcode($short_code);
        wp_die();
    }
    add_action("wp_ajax_nopriv_roninwp_gallery_load_by_category", "roninwp_gallery_load_by_category");
    add_action("wp_ajax_roninwp_gallery_load_by_category", "roninwp_gallery_load_by_category");
}

if (!function_exists('roninwp_gallery_justified_load_by_category')) {
    function roninwp_gallery_justified_load_by_category()
    {
        $margin = $_REQUEST['margin'];
        $category = $_REQUEST['category'];
        $item = $_REQUEST['item'];
        $order_by = isset($_REQUEST['order_by']) ? $_REQUEST['order_by'] : 'none' ;
        $order = $_REQUEST['order'];
        $bgColor = $_REQUEST['bgColor'];
        $titleStyle = $_REQUEST['titleStyle'];
        $rowHeight = $_REQUEST['rowHeight'];
        $show_paging = $_REQUEST['showPagging'];
        $short_code = sprintf('[fat_gallery_justified  show_category="%s"  row_height="%s" item="%s" order_by = "%s" order="%s"
        show_pagging="%s" margin="%s" bg_color="%s" title_style="%s" category="%s" ajax_load="1" ]',
            0, $rowHeight, $item, $order_by, $order, $show_paging, $margin, $bgColor, $titleStyle, $category);
        echo do_shortcode($short_code);
        wp_die();
    }
    add_action("wp_ajax_nopriv_roninwp_gallery_justified_load_by_category", "roninwp_gallery_justified_load_by_category");
    add_action("wp_ajax_roninwp_gallery_justified_load_by_category", "roninwp_gallery_justified_load_by_category");
}