<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 7/1/15
 * Time: 4:35 PM
 */
wp_register_style('fat-gallery-setting', plugins_url() . '/fat-gallery/assets/css/admin/setting.css', array(), false);
wp_print_styles('fat-gallery-setting');

wp_enqueue_script('bootstrap-colorpicker', plugins_url() . '/fat-gallery/assets/js/color-picker/js/bootstrap-colorpicker.min.js', false, true);
wp_enqueue_script('rangeslider', plugins_url() . '/fat-gallery/assets/js/rangeslider/rangeslider.min.js', false, true);
wp_enqueue_script('fat-gallery-setting', plugins_url() . '/fat-gallery/assets/js/setting.js', false, true);
wp_enqueue_style('rangeslider', plugins_url() . '/fat-gallery/assets/js/rangeslider/rangeslider.css', array(), false);
wp_enqueue_style('bootstrap-colorpicker', plugins_url() . '/fat-gallery/assets/js/color-picker/css/bootstrap-colorpicker.min.css', array(), false);

$gallery_categories = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY, array('hide_empty' => 0, 'orderby' => 'ASC'));

$args = array(
    'posts_per_page' => -1,
    'post_type' => FAT_GALLERY_POST_TYPE,
    'post_status' => 'publish');
$post_array = get_posts($args);


if (!current_user_can('edit_posts')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'fat-gallery'));
}

$screen = get_current_screen();
$post_type = $screen->post_type;
if (!isset($post_type) || $post_type == '') {
    if (isset($_REQUEST['post_type'])) {
        $post_type = sanitize_key($_REQUEST['post_type']);
    }
}

$message = '';
$message_class = 'updated';

$fat_settings = array(
    'old_domain' => '',
    'new_domain' => '',
    'slug' => FAT_GALLERY_POST_TYPE,
    'category_slug' => FAT_GALLERY_CATEGORY_TAXONOMY,
    'all_category_filter' => 'All',
    'view_more' => 'View more',

    'hide_title' => '',
    'hide_excerpt' => '',
    'disable_crop_masonry' => '',
    'layout_type' => 'grid',
    'popup_type' => 'light-gallery',
    'popup_transition' => 'lg-slide',
    'popup_image_action' => 'fat-gallery-move',
    'bold_icon' => '0',
    'hide_image_counter' => '0',
    'hide_actual_size' => '0',
    'hide_download' => '0',
    'hide_fullscreen' => '0',
    'hide_zoom_icon' => '0',
    'hide_autoplay' => '0',
    'hide_share_icon' => '0',
    'display_social_icon_simple' => '0',
    'hide_image_title' => '0',
    'filter_type' => 'isotope',
    'animation_filter' => '1',
    'show_paging' => '',
    'padding' => 'col-padding-5',
    'columns' => '4',
    'image_size_width' => '475',
    'image_size_height' => '475',
    'category_font_size' => '14',
    'category_style' => 'normal',
    'category_text_transform' => 'none',
    'category_text_color' => '#333',
    'category_text_hover_color' => '#333',
    'title_font_size' => '18',
    'title_style' => 'normal',
    'title_text_transform' => 'none',
    'title_text_color' => '#fff',
    'icon_font_size' => '18',
    'icon_color' => '#fff',
    'icon_hover_color' => '#fff',
    'bg_hover_color' => 'rgba(40, 150, 223, 0.8)',
    'loading_color' => '#333',
    'gallery_3d_enable_window' => 'true',
    'gallery_3d_auto_play' => 'true',
    'gallery_3d_nav_position' => 'nav-bottom',
    'image_3d_size_width' => '',
    'image_3d_size_height' => '',
    'carousel_auto_play' => 'true',
    'carousel_columns' => '4',
    'image_carousel_size_width' => '270',
    'image_carousel_size_height' => '270',
    'carousel_margin' => '0',
    'carousel_loop' => 'false',
    'carousel_center' => 'fasle',
    'carousel_two_halves' => 'fasle',
    'carousel_animation' => '',
    'carousel_show_nav' => 'true',
    'carousel_nav_position' => 'nav-bottom',
    'carousel_show_dot' => 'false',
    'custom_css' => '',
);

$settings = get_option($post_type . '-settings', $fat_settings);

if (isset($settings) && is_array($settings)) {
    $fat_settings = array_merge($fat_settings, $settings);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    foreach ($fat_settings as $key => $value) {
        $fat_settings[$key] = isset($_POST[$key]) ? $_POST[$key] : '';
    }
    $fat_settings['require_flush_slug'] = '1';
    $fat_settings['require_flush_category_slug'] = '1';
    update_option($post_type . '-settings', $fat_settings);
    $message = 'Your settings have been saved.';
}

if (isset($message) && $message != '') {
    ?>
    <div id="message" class="<?php echo esc_attr($message_class) ?>">
        <p><?php echo esc_html($message) ?> </p>
    </div>
<?php }
do_action('wpml_register_single_string', 'fat-gallery', 'All gallery', $fat_settings['all_category_filter']);
do_action('wpml_register_single_string', 'fat-gallery', 'View more', $fat_settings['view_more']);
?>
<form name="frmFatGallerySetting" id="frmFatGallerySetting" method="post" class="fat-gallery-setting"
      action="">
    <h1 class="setting-title">FAT Gallery Settings</h1>

    <ul class="tab-settings-nav">
        <li class="active"><a href="#" data-tab="tab-layout"><?php echo esc_html__('Layout', 'fat-gallery'); ?></a>
        </li>
        <li><a href="#" data-tab="tab-3d"><?php echo esc_html__('Slider', 'fat-gallery'); ?></a></li>
        <li><a href="#" data-tab="tab-font-style"><?php echo esc_html__('Font style', 'fat-gallery'); ?></a></li>
        <li><a href="#" data-tab="tab-custom-css"><?php echo esc_html__('Custom CSS', 'fat-gallery'); ?></a></li>
        <li><a href="#" title="Shortcode Gallery Generate"
               data-tab="tab-shortcode-fat-adv-generate"><?php echo esc_html__('SC Gallery Generate', 'fat-gallery'); ?></a>
        </li>
        <li><a href="#" title="Shortcode Gallery Justified Generate"
               data-tab="tab-shortcode-fat-justified-generate"><?php echo esc_html__('SC Gallery Justified', 'fat-gallery'); ?></a>
        </li>
        <li><a href="#" title="Shortcode Gallery 3D Slide Generate"
               data-tab="tab-shortcode-fat-3d-generate"><?php echo esc_html__('SC 3D Slide Generate', 'fat-gallery'); ?></a>
        </li>
        <li><a href="#" title="Shortcode Gallery Slide Generate"
               data-tab="tab-shortcode-fat-slide-generate"><?php echo esc_html__('SC Slide Generate', 'fat-gallery'); ?></a>
        </li>
        <li><a href="#" title="Shortcode Gallery Album Generate"
               data-tab="tab-shortcode-fat-album-generate"><?php echo esc_html__('SC Album Generate', 'fat-gallery'); ?></a>
        </li>
    </ul>

    <div class="tab-setting active" id="tab-layout">
        <h3>Fix image path</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Old domain:</div>
                <div class="fat-field">
                    <input type="text" name="old_domain"
                           value="<?php echo esc_attr($fat_settings['old_domain']) ?>"/>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">New domain:</div>
                <div class="fat-field">
                    <input type="text" name="new_domain"
                           value="<?php echo esc_attr($fat_settings['new_domain']) ?>"/>
                </div>
            </li>
        </ul>
        <h3>Slug</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Slug:</div>
                <div class="fat-field">
                    <input type="text" name="slug"
                           value="<?php echo esc_attr($fat_settings['slug']) ?>"/>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Category Slug:</div>
                <div class="fat-field">
                    <input type="text" name="category_slug"
                           value="<?php echo esc_attr($fat_settings['category_slug']) ?>"/>
                </div>
            </li>
        </ul>
        <h3>Layout</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">All category filter label:</div>
                <div class="fat-field">
                    <input type="text" name="all_category_filter"
                           value="<?php echo esc_attr($fat_settings['all_category_filter']) ?>"/>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">View more label:</div>
                <div class="fat-field">
                    <input type="text" name="view_more"
                           value="<?php echo esc_attr($fat_settings['view_more']) ?>"/>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Hide title:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_title" value="1"
                           title="Hide title" <?php if (isset($fat_settings['hide_title']) && $fat_settings['hide_title'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide excerpt:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_excerpt" value="1"
                           title="Hide excerpt" <?php if (isset($fat_settings['hide_excerpt']) && $fat_settings['hide_excerpt'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Disable crop image in masonry:</div>
                <div class="fat-field">
                    <input type="checkbox" name="disable_crop_masonry" value="1"
                           title="Disable crop image in masonry" <?php if (isset($fat_settings['disable_crop_masonry']) && $fat_settings['disable_crop_masonry'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Layout type:</div>
                <div class="fat-field">
                    <select name="layout_type">
                        <option value="grid" <?php if ($fat_settings['layout_type'] == 'grid') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Grid', 'fat-gallery'); ?></option>
                        <option value="masonry" <?php if ($fat_settings['layout_type'] == 'masonry') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Masonry', 'fat-gallery'); ?></option>
                        <option value="codo-effect" <?php if ($fat_settings['layout_type'] == 'codo-effect') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Masonry & Codo effect', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Popup type:</div>
                <div class="fat-field">
                    <select name="popup_type">
                        <option value="magnificPopup" <?php if ($fat_settings['popup_type'] == 'magnificPopup') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Magnific Popup', 'fat-gallery'); ?></option>
                        <option value="light-gallery" <?php if ($fat_settings['popup_type'] == 'light-gallery') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Light gallery', 'fat-gallery'); ?></option>

                    </select>
                </div>
                <div class="fat-desc">
                    <span class="description">The popup type only effect on layout type is grid or masonry</span>
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Popup light gallery transition:</div>
                <div class="fat-field">
                    <select name="popup_transition">
                        <option value="lg-slide" <?php if ($fat_settings['popup_transition'] == 'lg-slide') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Slide', 'fat-gallery'); ?></option>
                        <option value="lg-fade" <?php if ($fat_settings['popup_transition'] == 'lg-fade') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Fade', 'fat-gallery'); ?></option>
                        <option value="lg-zoom-in" <?php if ($fat_settings['popup_transition'] == 'lg-zoom-in') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Zoom in', 'fat-gallery'); ?></option>
                        <option value="lg-zoom-out" <?php if ($fat_settings['popup_transition'] == 'lg-zoom-out') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Zoom out', 'fat-gallery'); ?></option>
                        <option
                                value="lg-zoom-out-in" <?php if ($fat_settings['popup_transition'] == 'lg-zoom-out-in') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Zoom out in', 'fat-gallery'); ?></option>
                        <option value="lg-scale-up" <?php if ($fat_settings['popup_transition'] == 'lg-scale-up') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Scale up', 'fat-gallery'); ?></option>
                        <option
                                value="lg-slide-circular" <?php if ($fat_settings['popup_transition'] == 'lg-slide-circular') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Slide Circular', 'fat-gallery'); ?></option>
                        <option
                                value="lg-slide-circular-vertical" <?php if ($fat_settings['popup_transition'] == 'lg-slide-circular-vertical') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Slide Circular Vertical', 'fat-gallery'); ?></option>
                    </select>
                </div>
                <div class="fat-desc">
                    <span class="description">The popup transition only effect on popup type is light gallery</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Popup image action:</div>
                <div class="fat-field">
                    <select name="popup_image_action">
                        <option
                                value="fat-gallery-move" <?php if ($fat_settings['popup_image_action'] == 'fat-gallery-move') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Move image', 'fat-gallery'); ?></option>
                        <option
                                value="fat-gallery-zoom" <?php if ($fat_settings['popup_image_action'] == 'fat-gallery-zoom') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Zoom in/out image', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show bold icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="bold_icon" value="1"
                           title="Show bold icon" <?php if (isset($fat_settings['bold_icon']) && $fat_settings['bold_icon'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Hide image counter on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_image_counter" value="1"
                           title="Hide image counter" <?php if (isset($fat_settings['hide_image_counter']) && $fat_settings['hide_image_counter'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide download icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_download" value="1"
                           title="Hide download icon" <?php if (isset($fat_settings['hide_download']) && $fat_settings['hide_download'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Hide actual size icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_actual_size" value="1"
                           title="Hide actual size" <?php if (isset($fat_settings['hide_actual_size']) && $fat_settings['hide_actual_size'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide zoom icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_zoom_icon" value="1"
                           title="Hide zoom icon" <?php if (isset($fat_settings['hide_zoom_icon']) && $fat_settings['hide_zoom_icon'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide fullscreen icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_fullscreen" value="1"
                           title="Hide fullscreen" <?php if (isset($fat_settings['hide_fullscreen']) && $fat_settings['hide_fullscreen'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide autoplay icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_autoplay" value="1"
                           title="Hide autoplay" <?php if (isset($fat_settings['hide_autoplay']) && $fat_settings['hide_autoplay'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Hide share icon on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_share_icon" value="1"
                           title="Hide social icon" <?php if (isset($fat_settings['hide_share_icon']) && $fat_settings['hide_share_icon'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Show social icon simple on popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="display_social_icon_simple" value="1"
                           title="Show social icon simple" <?php if (isset($fat_settings['display_social_icon_simple']) && $fat_settings['display_social_icon_simple'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Hide image title popup gallery:</div>
                <div class="fat-field">
                    <input type="checkbox" name="hide_image_title" value="1"
                           title="Hide image title" <?php if (isset($fat_settings['hide_image_title']) && $fat_settings['hide_image_title'] === '1') {
                        echo 'checked';
                    } ?> >
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Filter type:</div>
                <div class="fat-field">
                    <select name="filter_type">
                        <option value="isotope" <?php if ($fat_settings['filter_type'] == 'isotope') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Isotope', 'fat-gallery'); ?></option>
                        <option value="ajax" <?php if ($fat_settings['filter_type'] == 'ajax') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Ajax', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Animation filter / load more:</div>
                <div class="fat-field">
                    <select name="animation_filter">
                        <option value="1" <?php if ($fat_settings['animation_filter'] == '1') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="" <?php if ($fat_settings['animation_filter'] == '') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show Slide / Load more :</div>
                <div class="fat-field">
                    <select name="show_paging">
                        <option value="" <?php if ($fat_settings['show_paging'] == '') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="1" <?php if ($fat_settings['show_paging'] == '1') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Load more', 'fat-gallery'); ?></option>
                        <option value="2" <?php if ($fat_settings['show_paging'] == '2') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Slider', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Padding between items :</div>
                <div class="fat-field">
                    <select name="padding">
                        <option value="col-padding-5" <?php if ($fat_settings['padding'] == 'col-padding-5') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('5 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-10" <?php if ($fat_settings['padding'] == 'col-padding-10') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('10 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-15" <?php if ($fat_settings['padding'] == 'col-padding-15') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('15 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-20" <?php if ($fat_settings['padding'] == 'col-padding-20') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('20 px', 'fat-gallery'); ?></option>
                        <option value="" <?php if ($fat_settings['padding'] == '') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image column:</div>
                <div class="fat-field">
                    <select name="columns">
                        <option value="1" <?php if ($fat_settings['columns'] == '1') {
                            echo 'selected';
                        } ?> ><?php echo '1' ?></option>
                        <option value="2" <?php if ($fat_settings['columns'] == '2') {
                            echo 'selected';
                        } ?> ><?php echo '2' ?></option>
                        <option value="3" <?php if ($fat_settings['columns'] == '3') {
                            echo 'selected';
                        } ?> ><?php echo '3' ?></option>
                        <option value="4" <?php if ($fat_settings['columns'] == '4') {
                            echo 'selected';
                        } ?> ><?php echo '4' ?></option>
                        <option value="5" <?php if ($fat_settings['columns'] == '5') {
                            echo 'selected';
                        } ?> ><?php echo '5' ?></option>
                    </select>
                </div>
                <div class="fat-desc">
                    <span class="description">The column number that display on each row</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="number" name="image_size_width" class="number"
                           value="<?php echo esc_attr($fat_settings['image_size_width']) ?>"/> x <input
                            value="<?php echo esc_attr($fat_settings['image_size_height']) ?>" type="number"
                            name="image_size_height" class="number"/> (px)

                </div>
                <div class="fat-desc">
                    <span class="description">The image size for thumbnails. Set empty for display orginal on masonry layout</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Background hover color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="bg_hover_color"
                               value="<?php echo esc_attr($fat_settings['bg_hover_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field">
                    <input class="button button-large button-primary" type="submit" value="Save Changes"/>
                </div>
            </li>
        </ul>
    </div>

    <div class="tab-setting" id="tab-3d">
        <h3>3D Slider</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Enable background window:</div>
                <div class="fat-field">
                    <select name="gallery_3d_enable_window">
                        <option
                                value="bg-window" <?php if ($fat_settings['gallery_3d_enable_window'] == 'bg-window') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="" <?php if ($fat_settings['gallery_3d_enable_window'] == '') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Auto play:</div>
                <div class="fat-field">
                    <select name="gallery_3d_auto_play">
                        <option value="true" <?php if ($fat_settings['gallery_3d_auto_play'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['gallery_3d_auto_play'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>
            <li class="field-group">
                <div class="fat-title">Navigation position:</div>
                <div class="fat-field">
                    <select name="gallery_3d_nav_position">
                        <option
                                value="nav-bottom" <?php if ($fat_settings['gallery_3d_nav_position'] == 'nav-bottom') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Bottom', 'fat-gallery'); ?></option>
                        <option
                                value="nav-middle" <?php if ($fat_settings['gallery_3d_nav_position'] == 'nav-middle') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Middle', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>
        </ul>

        <h3>Carousel Slider</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Auto play:</div>
                <div class="fat-field">
                    <select name="carousel_auto_play">
                        <option value="true" <?php if ($fat_settings['carousel_auto_play'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['carousel_auto_play'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>


            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="text" name="image_carousel_size_width" class="number"
                           value="<?php echo esc_attr($fat_settings['image_carousel_size_width']) ?>"/> x <input
                            value="<?php echo esc_attr($fat_settings['image_carousel_size_height']) ?>" type="text"
                            name="image_carousel_size_height" class="number"/> (px)

                </div>
                <div class="fat-desc">
                    <span class="description">The image size for thumbnails. Set empty for display orginal on masonry layout</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Columns :</div>
                <div class="fat-field">
                    <select name="carousel_columns">
                        <option
                                value="1" <?php if ($fat_settings['carousel_columns'] == '1') {
                            echo 'selected';
                        } ?> ><?php echo '1'; ?></option>
                        <option
                                value="2" <?php if ($fat_settings['carousel_columns'] == '2') {
                            echo 'selected';
                        } ?> ><?php echo '2'; ?></option>
                        <option
                                value="3" <?php if ($fat_settings['carousel_columns'] == '3') {
                            echo 'selected';
                        } ?> ><?php echo '3'; ?></option>
                        <option
                                value="4" <?php if ($fat_settings['carousel_columns'] == '4') {
                            echo 'selected';
                        } ?> ><?php echo '4'; ?></option>
                        <option value="5" <?php if ($fat_settings['carousel_columns'] == '5') {
                            echo 'selected';
                        } ?> ><?php echo '5'; ?></option>
                        <option value="6" <?php if ($fat_settings['carousel_columns'] == '5') {
                            echo 'selected';
                        } ?> ><?php echo '6'; ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Margin between items :</div>
                <div class="fat-field">
                    <select name="carousel_margin">
                        <option
                                value="5" <?php if ($fat_settings['carousel_margin'] == '5') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('5 px', 'fat-gallery'); ?></option>
                        <option
                                value="10" <?php if ($fat_settings['carousel_margin'] == '10') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('10 px', 'fat-gallery'); ?></option>
                        <option
                                value="15" <?php if ($fat_settings['carousel_margin'] == '15') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('15 px', 'fat-gallery'); ?></option>
                        <option
                                value="20" <?php if ($fat_settings['carousel_margin'] == '20') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('20 px', 'fat-gallery'); ?></option>
                        <option value="" <?php if ($fat_settings['carousel_margin'] == '') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Loop:</div>
                <div class="fat-field">
                    <select name="carousel_loop">
                        <option value="true" <?php if ($fat_settings['carousel_loop'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['carousel_loop'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Center:</div>
                <div class="fat-field">
                    <select name="carousel_center">
                        <option value="true" <?php if ($fat_settings['carousel_center'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['carousel_center'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>


            <li class="field-group">
                <div class="fat-title">Transition Effect:</div>
                <div class="fat-field">
                    <select name="carousel_animation">
                        <option value="1" <?php if ($fat_settings['carousel_center'] == '1') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="0" <?php if ($fat_settings['carousel_center'] == '0') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show navigation:</div>
                <div class="fat-field">
                    <select name="carousel_show_nav">
                        <option value="true" <?php if ($fat_settings['carousel_show_nav'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['carousel_show_nav'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Navigation position:</div>
                <div class="fat-field">
                    <select name="carousel_nav_position">
                        <option
                                value="nav-bottom" <?php if ($fat_settings['carousel_nav_position'] == 'nav-bottom') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Bottom', 'fat-gallery'); ?></option>
                        <option
                                value="nav-middle" <?php if ($fat_settings['carousel_nav_position'] == 'nav-middle') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Middle', 'fat-gallery'); ?></option>
                    </select>
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Show paging dot:</div>
                <div class="fat-field">
                    <select name="carousel_show_dot">
                        <option value="true" <?php if ($fat_settings['carousel_show_dot'] == 'true') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false" <?php if ($fat_settings['carousel_show_dot'] == 'false') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>


            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field">
                    <input class="button button-large button-primary" type="submit" value="Save Changes"/>
                </div>
            </li>
        </ul>
    </div>

    <div class="tab-setting" id="tab-font-style">
        <h3>Font style</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Category font size:</div>
                <div class="fat-field">
                    <div class="ranger-slider-container">
                        <div class="ranger-slider" style="width: 300px">
                            <input id="rg-category-font-size" type="range" min="10" max="50" step="1"
                                   value="<?php echo esc_attr($fat_settings['category_font_size']) ?>"
                                   data-output-id="rg-output-category-font-size" name="category_font_size"/>
                        </div>
                        <input id="rg-output-category-font-size" data-range-id="rg-category-font-size" type="number"
                               value="<?php echo esc_attr($fat_settings['category_font_size']) ?>"> (px)
                    </div>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Category style:</div>
                <div class="fat-field">
                    <select name="category_style">
                        <option value="normal" <?php if ($fat_settings['category_style'] == 'normal') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Normal', 'fat-gallery') ?></option>
                        <option value="italic" <?php if ($fat_settings['category_style'] == 'italic') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Italic', 'fat-gallery') ?></option>
                        <option value="bold" <?php if ($fat_settings['category_style'] == 'italic') {
                            echo 'bold';
                        } ?> ><?php echo esc_html__('Bold', 'fat-gallery') ?></option>
                    </select>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Category text transform:</div>
                <div class="fat-field">
                    <select name="category_text_transform">
                        <option value="none" <?php if ($fat_settings['category_text_transform'] == 'none') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('None', 'fat-gallery') ?></option>
                        <option
                                value="uppercase" <?php if ($fat_settings['category_text_transform'] == 'uppercase') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Uppercase', 'fat-gallery') ?></option>
                        <option
                                value="lowercase" <?php if ($fat_settings['category_text_transform'] == 'lowercase') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Lowercase', 'fat-gallery') ?></option>
                    </select>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Category text color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="category_text_color"
                               value="<?php echo esc_attr($fat_settings['category_text_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Category text hover/active color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="category_text_hover_color"
                               value="<?php echo esc_attr($fat_settings['category_text_hover_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title font size:</div>
                <div class="fat-field">
                    <div class="ranger-slider-container">
                        <div class="ranger-slider" style="width: 300px">
                            <input id="rg-title-font-size" type="range" min="10" max="50" step="1"
                                   value="<?php echo esc_attr($fat_settings['title_font_size']) ?>"
                                   data-output-id="rg-output-title-font-size" name="title_font_size"/>
                        </div>
                        <input id="rg-output-title-font-size" data-range-id="rg-title-font-size" type="number"
                               value="14"> (px)
                    </div>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title style:</div>
                <div class="fat-field">
                    <select name="title_style">
                        <option value="normal" <?php if ($fat_settings['title_style'] == 'normal') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Normal', 'fat-gallery') ?></option>
                        <option value="italic" <?php if ($fat_settings['title_style'] == 'italic') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Italic', 'fat-gallery') ?></option>
                        <option value="bold" <?php if ($fat_settings['title_style'] == 'bold') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Bold', 'fat-gallery') ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title text transform:</div>
                <div class="fat-field">
                    <select name="title_text_transform">
                        <option value="none" <?php if ($fat_settings['title_text_transform'] == 'none') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('None', 'fat-gallery') ?></option>
                        <option value="uppercase" <?php if ($fat_settings['title_text_transform'] == 'uppercase') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Uppercase', 'fat-gallery') ?></option>
                        <option value="lowercase" <?php if ($fat_settings['title_text_transform'] == 'lowercase') {
                            echo 'selected';
                        } ?> ><?php echo esc_html__('Lowercase', 'fat-gallery') ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title text color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="title_text_color"
                               value="<?php echo esc_attr($fat_settings['title_text_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Icon font size:</div>
                <div class="fat-field">
                    <div class="ranger-slider-container">
                        <div class="ranger-slider" style="width: 300px">
                            <input id="rg-icon-font-size" type="range" min="10" max="50" step="1"
                                   value="<?php echo esc_attr($fat_settings['icon_font_size']) ?>"
                                   data-output-id="rg-output-icon-font-size" name="icon_font_size"/>
                        </div>
                        <input id="rg-output-icon-font-size" data-range-id="rg-icon-font-size" type="number" value="14">
                        (px)
                    </div>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Icon color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="icon_color"
                               value="<?php echo esc_attr($fat_settings['icon_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Icon hover color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="icon_hover_color"
                               value="<?php echo esc_attr($fat_settings['icon_hover_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Loading color :</div>
                <div class="fat-field">
                    <div class="input-group colorpicker-component  colorpicker-element">
                        <input type="text" name="loading_color"
                               value="<?php echo esc_attr($fat_settings['loading_color']) ?>"
                               class="colorPicker form-control"/>
                        <span class="input-group-addon"><i></i></span>
                    </div>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input class="button button-large button-primary" type="submit"
                                              value="Save Changes"/></div>
            </li>
        </ul>
    </div>

    <div class="tab-setting" id="tab-custom-css">
        <h3>Custom Css</h3>
        <textarea name="custom_css" class="custom-css"
                  spellcheck="false"><?php echo sprintf('%s', $fat_settings['custom_css']); ?></textarea>
        <h3>General class</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">fat-gallery :</div>
                <div class="fat-field"><?php echo esc_html__('Gallery container', 'fat-gallery') ?></div>
            </li>
            <li class="field-group">
                <div class="fat-title">fat-gallery-tabs :</div>
                <div
                        class="fat-field"><?php echo esc_html__('Gallery category container', 'fat-gallery') ?></div>
            </li>
            <li class="field-group">
                <div class="fat-title">fat-gallery-wrapper :</div>
                <div class="fat-field"><?php echo esc_html__('Gallery item container', 'fat-gallery') ?></div>
            </li>
            <li class="field-group">
                <div class="fat-title">paging :</div>
                <div class="fat-field"><?php echo esc_html__('Gallery paging container', 'fat-gallery') ?></div>
            </li>
            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input class="button button-large button-primary" type="submit"
                                              value="Save Changes"/></div>
            </li>
        </ul>
    </div>

    <div class="tab-setting" id="tab-shortcode-fat-adv-generate">
        <h3>Shortcode FAT Gallery</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Layout type:</div>
                <div class="fat-field">
                    <select name="sc_layout_type" id="sc_fat_adv_layout_type">
                        <option value="grid"><?php echo esc_html__('Grid', 'fat-gallery'); ?></option>
                        <option value="masonry"><?php echo esc_html__('Masonry', 'fat-gallery'); ?></option>
                        <option
                                value="codo-effect"><?php echo esc_html__('Masonry & Codo effect', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Display type:</div>
                <div class="fat-field">
                    <select name="sc_display_type" id="sc_fat_adv_display_type">
                        <option value="full"><?php echo esc_html__('Full', 'fat-gallery'); ?></option>
                        <option value=""><?php echo esc_html__('Compact', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Hover effect:</div>
                <div class="fat-field">
                    <select name="sc_overlay_style" id="sc_fat_adv_overlay_style">
                        <option value="icon-view"><?php echo esc_html__('Hover dir', 'fat-gallery'); ?></option>
                        <option value="lily"><?php echo esc_html__('Lily', 'fat-gallery'); ?></option>
                        <option value="zoe"><?php echo esc_html__('Zoe', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Popup type:</div>
                <div class="fat-field">
                    <select name="sc_popup_type" id="sc_fat_adv_popup_type">
                        <option
                                value="magnificPopup"><?php echo esc_html__('Magnific Popup', 'fat-gallery'); ?></option>
                        <option value="light-gallery"><?php echo esc_html__('Light gallery', 'fat-gallery'); ?></option>

                    </select>
                </div>
                <div class="fat-desc">
                    <span class="description">The popup type only effect on layout type is grid or masonry</span>
                </div>

            </li>

            <li class="field-group">
                <div class="fat-title">Popup light gallery transition:</div>
                <div class="fat-field">
                    <select name="sc_popup_transition" id="sc_fat_adv_popup_transition">
                        <option value="lg-slide"><?php echo esc_html__('Slide', 'fat-gallery'); ?></option>
                        <option value="lg-fade"><?php echo esc_html__('Fade', 'fat-gallery'); ?></option>
                        <option value="lg-zoom-in"><?php echo esc_html__('Zoom in', 'fat-gallery'); ?></option>
                        <option value="lg-zoom-out"><?php echo esc_html__('Zoom out', 'fat-gallery'); ?></option>
                        <option value="lg-zoom-out-in"><?php echo esc_html__('Zoom out in', 'fat-gallery'); ?></option>
                        <option value="lg-scale-up"><?php echo esc_html__('Scale up', 'fat-gallery'); ?></option>
                        <option
                                value="lg-slide-circular"><?php echo esc_html__('Slide Circular', 'fat-gallery'); ?></option>
                        <option
                                value="lg-slide-circular-vertical"><?php echo esc_html__('Slide Circular Vertical', 'fat-gallery'); ?></option>
                    </select>
                </div>
                <div class="fat-desc">
                    <span class="description">The popup transition only effect on popup type is light gallery</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="text" name="sc_image_size_width" id="sc_fat_adv_image_width" class="number"
                           value=""/> x <input
                            value="" type="text"
                            name="sc_image_size_height" id="sc_fat_adv_image_height" class="number"/> (px)

                </div>
                <div class="fat-desc">
                    <span class="description">The image size for thumbnails. Set empty for display orginal on masonry layout</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Select from source:</div>
                <div class="fat-field">
                    <select class="dependence" name="sc_data_source" id="sc_fat_adv_data_source">
                        <option value=""><?php echo esc_html__('From Category', 'fat-gallery'); ?></option>
                        <option value="list_id"><?php echo esc_html__('From Gallery IDs', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_adv_data_source" data-value="">
                <div class="fat-title">Select category:</div>
                <div class="fat-field">
                    <select name="sc_data_source" id="sc_fat_adv_category" class="select2" multiple="true">
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name . ' ( ' . $cat->slug . ' )'); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_adv_data_source" data-value="list_id">
                <div class="fat-title">Select gallery:</div>
                <div class="fat-field">
                    <select name="sc_data_source" class="select2" id="sc_fat_adv_gallery_ids" multiple="true">
                        <?php foreach ($post_array as $post) : setup_postdata($post); ?>
                            <option
                                    value="<?php echo esc_attr($post->ID) ?>"><?php echo wp_kses_post($post->post_title) ?></option>
                        <?php
                        endforeach;
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_adv_data_source" data-value="">
                <div class="fat-title">Show Category Filter:</div>
                <div class="fat-field">
                    <select name="sc_show_category" id="sc_fat_show_category">
                        <option value=""><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="left"><?php echo esc_html__('Show in left', 'fat-gallery'); ?></option>
                        <option value="center"><?php echo esc_html__('Show in center', 'fat-gallery'); ?></option>
                        <option value="right"><?php echo esc_html__('Show in right', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_adv_data_source" data-value="">
                <div class="fat-title">Default category filter active:</div>
                <div class="fat-field">
                    <select name="sc_show_default_category" id="sc_fat_default_category">
                        <option value=""><?php echo esc_html__('All', 'fat-gallery'); ?></option>
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name . ' ( ' . $cat->slug . ' )'); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_adv_data_source" data-value="">
                <div class="fat-title">Show 'ALL' category filter:</div>
                <div class="fat-field">
                    <select name="sc_show_default_category" id="sc_fat_show_all_category_filter">
                        <option value="1"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="0"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Category Style:</div>
                <div class="fat-field">
                    <select name="sc_category_style" id="sc_fat_adv_category_style">
                        <option value=""><?php echo esc_html__('Inherit from setting', 'fat-gallery'); ?></option>
                        <option value="normal"><?php echo esc_html__('Normal', 'fat-gallery'); ?></option>
                        <option value="uppercase"><?php echo esc_html__('Uppercase', 'fat-gallery'); ?></option>
                        <option value="lowercase"><?php echo esc_html__('Lowercase', 'fat-gallery'); ?></option>
                        <option value="italic"><?php echo esc_html__('Italic', 'fat-gallery'); ?></option>
                        <option value="bold"><?php echo esc_html__('Bold', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Filter type:</div>
                <div class="fat-field">
                    <select name="sc_filter_type" id="sc_fat_adv_filter_type">
                        <option value="isotope"><?php echo esc_html__('Isotope', 'fat-gallery'); ?></option>
                        <option value="ajax"><?php echo esc_html__('Ajax', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Animation filter / load more:</div>
                <div class="fat-field">
                    <select name="sc_animation_filter" id="sc_fat_adv_animation_filter">
                        <option value="1"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="0"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Number of column:</div>
                <div class="fat-field">
                    <select name="sc_column" id="sc_fat_adv_column">
                        <option value="5"><?php echo esc_html__('5', 'fat-gallery'); ?></option>
                        <option value="4"><?php echo esc_html__('4', 'fat-gallery'); ?></option>
                        <option value="3"><?php echo esc_html__('3', 'fat-gallery'); ?></option>
                        <option value="2"><?php echo esc_html__('2', 'fat-gallery'); ?></option>
                        <option value="1"><?php echo esc_html__('1', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Total item:</div>
                <div class="fat-field">
                    <input type="number" name="sc_item" value="" id="sc_fat_total_item">
                </div>
                <div class="fat-desc">
                    <span class="description">Set empty for display all</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show load more:</div>
                <div class="fat-field">
                    <select name="sc_show_pagging" id="sc_fat_adv_view_more">
                        <option value=""><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                        <option value="1"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Padding:</div>
                <div class="fat-field">
                    <select name="sc_padding" id="sc_fat_adv_padding">
                        <option value=""><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="col-padding-5"><?php echo esc_html__('5 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-10"><?php echo esc_html__('10 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-15"><?php echo esc_html__('15 px', 'fat-gallery'); ?></option>
                        <option value="col-padding-20"><?php echo esc_html__('20 px', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Overlay Background Color:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_adv_bg_color">
                        <option
                                value="inherit"><?php echo esc_html__('Inherit from settings', 'fat-gallery'); ?></option>
                        <option value="bg-dark"><?php echo esc_html__('Dark', 'fat-gallery'); ?></option>
                        <option value="bg-light"><?php echo esc_html__('Light', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title Style:</div>
                <div class="fat-field">
                    <select name="sc_title_style" id="sc_fat_adv_title_style">
                        <option value=""><?php echo esc_html__('Inherit from setting', 'fat-gallery'); ?></option>
                        <option value="normal"><?php echo esc_html__('Normal', 'fat-gallery'); ?></option>
                        <option value="uppercase"><?php echo esc_html__('Uppercase', 'fat-gallery'); ?></option>
                        <option value="lowercase"><?php echo esc_html__('Lowercase', 'fat-gallery'); ?></option>
                        <option value="italic"><?php echo esc_html__('Italic', 'fat-gallery'); ?></option>
                        <option value="bold"><?php echo esc_html__('Bold', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Order by:</div>
                <div class="fat-field">
                    <select name="sc_layout_type" id="sc_fat_adv_order_by">
                        <option value="none"><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="ID"><?php echo esc_html__('Post ID', 'fat-gallery'); ?></option>
                        <option value="title"><?php echo esc_html__('Post title', 'fat-gallery'); ?></option>
                        <option value="slug"><?php echo esc_html__('Post slug', 'fat-gallery'); ?></option>
                        <option value="rand"><?php echo esc_html__('Random', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Order:</div>
                <div class="fat-field">
                    <select name="sc_layout_type" id="sc_fat_adv_order">
                        <option value="DESC"><?php echo esc_html__('Descending', 'fat-gallery'); ?></option>
                        <option value="ASC"><?php echo esc_html__('Ascending', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>


            <li class="field-group" id="sc_fat_adv_output" style="display: none;">
                <div class="fat-title">Shortcode:</div>
                <div class="fat-field" style="width: 70%">
                    <p>Please copy shortcode bellow and paste to page, post or widget that you want display</p>
                    <textarea style="width: 100%;height: 200px;line-height: 2" spellcheck="false"></textarea>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input id="bt_sc_fat_avd"
                                              class="button button-large button-primary bt-sc-fat-adv-generate"
                                              type="button"
                                              value="Generate"/></div>
            </li>

        </ul>
    </div>

    <div class="tab-setting" id="tab-shortcode-fat-justified-generate">
        <h3>Shortcode Justified Gallery</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Select from source:</div>
                <div class="fat-field">
                    <select class="dependence" name="sc_data_source" id="sc_fat_justified_data_source">
                        <option value=""><?php echo esc_html__('From Category', 'fat-gallery'); ?></option>
                        <option value="list_id"><?php echo esc_html__('From Gallery IDs', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_justified_data_source" data-value="">
                <div class="fat-title">Select category:</div>
                <div class="fat-field">
                    <select name="sc_data_source" id="sc_fat_justified_category" class="select2" multiple="true">
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_justified_data_source"
                data-value="list_id">
                <div class="fat-title">Select gallery:</div>
                <div class="fat-field">
                    <select name="sc_data_source" class="select2" id="sc_fat_justified_gallery_ids" multiple="true">
                        <?php foreach ($post_array as $post) : setup_postdata($post); ?>
                            <option
                                    value="<?php echo esc_attr($post->ID) ?>"><?php echo wp_kses_post($post->post_title) ?></option>
                        <?php
                        endforeach;
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_justified_data_source" data-value="">
                <div class="fat-title">Show Category Filter:</div>
                <div class="fat-field">
                    <select name="sc_show_category" id="sc_fat_justified_show_category">
                        <option value=""><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="left"><?php echo esc_html__('Show in left', 'fat-gallery'); ?></option>
                        <option value="center"><?php echo esc_html__('Show in center', 'fat-gallery'); ?></option>
                        <option value="right"><?php echo esc_html__('Show in right', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Row height (pixel):</div>
                <div class="fat-field">
                    <input type="number" name="sc_item" value="120" id="sc_fat_justified_row_height">
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Margin between items (pixel):</div>
                <div class="fat-field">
                    <input type="number" name="sc_item" value="5" id="sc_fat_justified_margin">
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Total item (item per page if show load more, set empty for display all):</div>
                <div class="fat-field">
                    <input type="number" name="sc_item" value="" id="sc_fat_justified_total_item">
                </div>
                <div class="fat-desc">
                    <span class="description">Set empty for display all</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show load more:</div>
                <div class="fat-field">
                    <select name="sc_show_pagging" id="sc_fat_justified_view_more">
                        <option value=""><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                        <option value="1"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Overlay Background Color:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_justified_bg_color">
                        <option
                                value="inherit"><?php echo esc_html__('Inherit from settings', 'fat-gallery'); ?></option>
                        <option value="bg-dark"><?php echo esc_html__('Dark', 'fat-gallery'); ?></option>
                        <option value="bg-light"><?php echo esc_html__('Light', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Category Style:</div>
                <div class="fat-field">
                    <select name="sc_category_style" id="sc_fat_justified_category_style">
                        <option value=""><?php echo esc_html__('Inherit from setting', 'fat-gallery'); ?></option>
                        <option value="normal"><?php echo esc_html__('Normal', 'fat-gallery'); ?></option>
                        <option value="uppercase"><?php echo esc_html__('Uppercase', 'fat-gallery'); ?></option>
                        <option value="lowercase"><?php echo esc_html__('Lowercase', 'fat-gallery'); ?></option>
                        <option value="italic"><?php echo esc_html__('Italic', 'fat-gallery'); ?></option>
                        <option value="bold"><?php echo esc_html__('Bold', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Title Style:</div>
                <div class="fat-field">
                    <select name="sc_title_style" id="sc_fat_justified_title_style">
                        <option value=""><?php echo esc_html__('Inherit from setting', 'fat-gallery'); ?></option>
                        <option value="normal"><?php echo esc_html__('Normal', 'fat-gallery'); ?></option>
                        <option value="uppercase"><?php echo esc_html__('Uppercase', 'fat-gallery'); ?></option>
                        <option value="lowercase"><?php echo esc_html__('Lowercase', 'fat-gallery'); ?></option>
                        <option value="italic"><?php echo esc_html__('Italic', 'fat-gallery'); ?></option>
                        <option value="bold"><?php echo esc_html__('Bold', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group" id="sc_fat_justified_output" style="display: none;">
                <div class="fat-title">Shortcode:</div>
                <div class="fat-field" style="width: 70%">
                    <p>Please copy shortcode bellow and paste to page, post or widget that you want display</p>
                    <textarea style="width: 100%;height: 200px;line-height: 2" spellcheck="false"></textarea>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input id="bt_sc_fat_justified"
                                              class="button button-large button-primary bt_sc_fat_justified-generate"
                                              type="button"
                                              value="Generate"/></div>
            </li>

        </ul>
    </div>

    <div class="tab-setting" id="tab-shortcode-fat-slide-generate">
        <h3>Shortcode Slide Gallery</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Display type:</div>
                <div class="fat-field">
                    <select name="sc_display_type" id="sc_fat_slide_display_type">
                        <option value="full"><?php echo esc_html__('Full', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="text" name="sc_image_size_width" id="sc_fat_adv_image_width" class="number"
                           value="475"/> x <input
                            value="475" type="text"
                            name="sc_image_size_height" id="sc_fat_adv_image_height" class="number"/> (px)

                </div>
                <div class="fat-desc">
                    <span class="description">The image size for thumbnails. Set empty for display orginal on masonry layout</span>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Auto play:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_slide_auto_play">
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Center:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_slide_center">
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>

                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Two halves style:</div>
                <div class="fat-field">
                    <select name="sc_fat_slide_two_halves" id="sc_fat_slide_two_halves">
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Select from source:</div>
                <div class="fat-field">
                    <select class="dependence" name="sc_data_source" id="sc_fat_slide_data_source">
                        <option value=""><?php echo esc_html__('From Category', 'fat-gallery'); ?></option>
                        <option value="list_id"><?php echo esc_html__('From Gallery IDs', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_slide_data_source" data-value="">
                <div class="fat-title">Select category:</div>
                <div class="fat-field">
                    <select name="sc_data_source" id="sc_fat_slide_category" class="select2" multiple="true">
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_slide_data_source"
                data-value="list_id">
                <div class="fat-title">Select gallery:</div>
                <div class="fat-field">
                    <select name="sc_data_source" class="select2" id="sc_fat_slide_gallery_ids" multiple="true">
                        <?php foreach ($post_array as $post) : setup_postdata($post); ?>
                            <option
                                    value="<?php echo esc_attr($post->ID) ?>"><?php echo wp_kses_post($post->post_title) ?></option>
                        <?php
                        endforeach;
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Number of column:</div>
                <div class="fat-field">
                    <select name="sc_column" id="sc_fat_slide_column">
                        <option value="5"><?php echo esc_html__('5', 'fat-gallery'); ?></option>
                        <option value="4"><?php echo esc_html__('4', 'fat-gallery'); ?></option>
                        <option value="3"><?php echo esc_html__('3', 'fat-gallery'); ?></option>
                        <option value="2"><?php echo esc_html__('2', 'fat-gallery'); ?></option>
                        <option value="1"><?php echo esc_html__('1', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Margin between items:</div>
                <div class="fat-field">
                    <select name="sc_margin" id="sc_fat_slide_margin">
                        <option value="0"><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="5"><?php echo esc_html__('5 px', 'fat-gallery'); ?></option>
                        <option value="10"><?php echo esc_html__('10 px', 'fat-gallery'); ?></option>
                        <option value="15"><?php echo esc_html__('15 px', 'fat-gallery'); ?></option>
                        <option value="20"><?php echo esc_html__('20 px', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show navigation:</div>
                <div class="fat-field">
                    <select name="sc_margin" id="sc_fat_slide_show_navigation">
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Navigation position:</div>
                <div class="fat-field">
                    <select name="sc_margin" id="sc_fat_slide_nav_position">
                        <option value="nav-bottom"><?php echo esc_html__('Bottom', 'fat-gallery'); ?></option>
                        <option value="nav-middle"><?php echo esc_html__('Middle', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Show dot paging:</div>
                <div class="fat-field">
                    <select name="sc_margin" id="sc_fat_slide_show_dot">
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group" id="sc_fat_slide_output" style="display: none;">
                <div class="fat-title">Shortcode:</div>
                <div class="fat-field" style="width: 70%">
                    <p>Please copy shortcode bellow and paste to page, post or widget that you want display</p>
                    <textarea style="width: 100%;height: 200px;line-height: 2" spellcheck="false"></textarea>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input id="bt_sc_fat_slide"
                                              class="button button-large button-primary bt-sc-fat-slide-generate"
                                              type="button"
                                              value="Generate"/></div>
            </li>

        </ul>
    </div>

    <div class="tab-setting" id="tab-shortcode-fat-3d-generate">
        <h3>Shortcode FAT 3D Slide Gallery</h3>
        <ul>
            <li class="field-group">
                <div class="fat-title">Auto play:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_3d_auto_play">
                        <option value="true"><?php echo esc_html__('Yes', 'fat-gallery'); ?></option>
                        <option value="false"><?php echo esc_html__('No', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Navigation position:</div>
                <div class="fat-field">
                    <select name="sc_bg_color" id="sc_fat_3d_navigation_position">
                        <option value="nav-bottom"><?php echo esc_html__('Bottom', 'fat-gallery'); ?></option>
                        <option value="nav-middle"><?php echo esc_html__('Middle', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Select from source:</div>
                <div class="fat-field">
                    <select class="dependence" name="sc_data_source" id="sc_fat_3d_data_source">
                        <option value=""><?php echo esc_html__('From Category', 'fat-gallery'); ?></option>
                        <option value="list_id"><?php echo esc_html__('From Gallery IDs', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_3d_data_source" data-value="">
                <div class="fat-title">Select category:</div>
                <div class="fat-field">
                    <select name="sc_data_source" id="sc_fat_3d_category" class="select2" multiple="true">
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_3d_data_source" data-value="list_id">
                <div class="fat-title">Select gallery:</div>
                <div class="fat-field">
                    <select name="sc_data_source" class="select2" id="sc_fat_3d_gallery_ids" multiple="true">
                        <?php foreach ($post_array as $post) : setup_postdata($post); ?>
                            <option
                                    value="<?php echo esc_attr($post->ID) ?>"><?php echo wp_kses_post($post->post_title) ?></option>
                        <?php
                        endforeach;
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="number" name="image_3d_size_width" class="number" id="sc_fat_3d_image_width"
                           value="<?php echo esc_attr($fat_settings['image_3d_size_width']) ?>"/> x <input
                            value="<?php echo esc_attr($fat_settings['image_3d_size_height']) ?>" type="number"
                            id="sc_fat_3d_image_height"
                            name="sc_fat_3d_image_height" class="number"/> (px)

                </div>
                <div class="fat-desc">
                    <span class="description">The image size for thumbnails. Set empty for display orginal on masonry layout</span>
                </div>
            </li>

            <li class="field-group" id="sc_fat_3d_output" style="display: none;">
                <div class="fat-title">Shortcode:</div>
                <div class="fat-field" style="width: 70%">
                    <p>Please copy shortcode bellow and paste to page, post or widget that you want display</p>
                    <textarea style="width: 100%;height: 200px;line-height: 2" spellcheck="false"></textarea>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input id="bt_sc_fat_3d"
                                              class="button button-large button-primary bt-sc-fat-3d-generate"
                                              type="button"
                                              value="Generate"/></div>
            </li>

        </ul>
    </div>

    <div class="tab-setting" id="tab-shortcode-fat-album-generate">
        <h3>Shortcode Album Gallery</h3>
        <ul>

            <li class="field-group">
                <div class="fat-title">Select from source:</div>
                <div class="fat-field">
                    <select class="dependence" name="sc_data_source" id="sc_fat_album_data_source">
                        <option value=""><?php echo esc_html__('From Category', 'fat-gallery'); ?></option>
                        <option value="list_id"><?php echo esc_html__('From Gallery IDs', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_album_data_source" data-value="">
                <div class="fat-title">Select category:</div>
                <div class="fat-field">
                    <select name="sc_data_source" id="sc_fat_album_category" class="select2" multiple="true">
                        <?php foreach ($gallery_categories as $cat) { ?>
                            <option
                                    value="<?php echo esc_attr($cat->slug) ?>"><?php echo wp_kses_post($cat->name . ' ( ' . $cat->slug . ' )'); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_album_data_source"
                data-value="list_id">
                <div class="fat-title">Select gallery:</div>
                <div class="fat-field">
                    <select name="sc_data_source" class="select2" id="sc_fat_album_gallery_ids" multiple="true">
                        <?php foreach ($post_array as $post) : setup_postdata($post); ?>
                            <option
                                    value="<?php echo esc_attr($post->ID) ?>"><?php echo wp_kses_post($post->post_title) ?></option>
                        <?php
                        endforeach;
                        wp_reset_postdata();
                        ?>
                    </select>
                </div>
            </li>

            <li class="field-group dependence-element" data-dependence-id="sc_fat_album_data_source" data-value="">
                <div class="fat-title">Show Category Filter:</div>
                <div class="fat-field">
                    <select name="sc_show_category" id="sc_fat_album_show_category">
                        <option value=""><?php echo esc_html__('None', 'fat-gallery'); ?></option>
                        <option value="left"><?php echo esc_html__('Show in left', 'fat-gallery'); ?></option>
                        <option value="center"><?php echo esc_html__('Show in center', 'fat-gallery'); ?></option>
                        <option value="right"><?php echo esc_html__('Show in right', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Columns:</div>
                <div class="fat-field">
                    <select name="sc_show_pagging" id="sc_fat_album_columns">
                        <option value="5"><?php echo esc_html__('5 columns', 'fat-gallery'); ?></option>
                        <option value="4"><?php echo esc_html__('4 columns', 'fat-gallery'); ?></option>
                        <option value="3"><?php echo esc_html__('3 columns', 'fat-gallery'); ?></option>
                        <option value="2"><?php echo esc_html__('2 columns', 'fat-gallery'); ?></option>
                        <option value="1"><?php echo esc_html__('1 column', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Image size:</div>
                <div class="fat-field">
                    <input type="text" name="sc_image_size_width" id="sc_fat_album_image_width" class="number"
                           value="170"> x
                    <input value="127" type="text" name="sc_image_size_height" id="sc_fat_album_image_height"
                           class="number"> (px)

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Columns on each album:</div>
                <div class="fat-field">
                    <select name="sc_show_pagging" id="sc_fat_album_columns_of_album">
                        <option value="5"><?php echo esc_html__('5 columns', 'fat-gallery'); ?></option>
                        <option value="4"><?php echo esc_html__('4 columns', 'fat-gallery'); ?></option>
                        <option value="3" selected><?php echo esc_html__('3 columns', 'fat-gallery'); ?></option>
                        <option value="2"><?php echo esc_html__('2 columns', 'fat-gallery'); ?></option>
                    </select>
                </div>
            </li>
            <li class="field-group">
                <div class="fat-title">Total item on each album:</div>
                <div class="fat-field">
                    <input type="text" name="sc_total_item_on_album" id="sc_total_item_on_album" class="number"
                           value="9">
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Padding:</div>
                <div class="fat-field">
                    <select name="sc_padding" id="sc_fat_album_padding">
                        <option value="">None</option>
                        <option value="col-padding-5">5 px</option>
                        <option value="col-padding-10">10 px</option>
                        <option value="col-padding-15">15 px</option>
                        <option value="col-padding-20">20 px</option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Has box shadow:</div>
                <div class="fat-field">
                    <select name="sc_animation_filter" id="sc_fat_album_has_box_shadow">
                        <option value="has-shadow">Yes</option>
                        <option value="">No</option>
                    </select>
                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">Has padding item on thumbnail:</div>
                <div class="fat-field">
                    <select name="sc_animation_filter" id="sc_fat_album_has_padding">
                        <option value="has-padding">Yes</option>
                        <option value="">No</option>
                    </select>
                </div>
            </li>

            <li class="field-group" id="sc_fat_album_output" style="display: none;">
                <div class="fat-title">Shortcode:</div>
                <div class="fat-field" style="width: 70%">
                    <p>Please copy shortcode bellow and paste to page, post or widget that you want display</p>
                    <textarea style="width: 100%;height: 200px;line-height: 2" spellcheck="false"></textarea>

                </div>
            </li>

            <li class="field-group">
                <div class="fat-title">&nbsp;</div>
                <div class="fat-field"><input id="bt_sc_fat_album"
                                              class="button button-large button-primary bt_sc_fat_album-generate"
                                              type="button"
                                              value="Generate"/></div>
            </li>

        </ul>
    </div>

</form>