<?php
/*
Plugin Name: FAT Gallery
Plugin URI:   http://roninwp.com/plugins/gallery
Description: FAT Gallery is a premium responsive WordPress gallery plugin
Version:     1.4.5
Author:      Roninwp
Author URI:  http://roninwp.com/plugins/gallery
Domain Path: /languages
Text Domain: fat-gallery
*/

if (!defined('ABSPATH')) die('-1');

if (!defined('FAT_GALLERY_CATEGORY_TAXONOMY'))
    define('FAT_GALLERY_CATEGORY_TAXONOMY', 'fat-gallery-category');

if (!defined('FAT_GALLERY_POST_TYPE'))
    define('FAT_GALLERY_POST_TYPE', 'fat-gallery');

if (!defined('FAT_GALLERY_DIR_PATH'))
    define('FAT_GALLERY_DIR_PATH', plugin_dir_path(__FILE__));


if (!class_exists('FAT_Gallery')) {

    class FAT_Gallery
    {

        function __construct()
        {
            $this->includes();
            add_action('init', array($this, 'register_taxonomies'), 5);
            add_action('init', array($this, 'register_post_types'), 6);
            add_action('init', array($this, 'register_vc_shortcode'), 7);
            add_action('init', array($this, 'load_text_domain'), 0);
            add_action('admin_init', array($this, 'add_metabox_to_attachment'));
            add_action('edit_attachment', array($this, 'save_attachment_meta'));
            add_filter('rwmb_meta_boxes', array($this, 'register_meta_boxes'));
            add_shortcode('fat_adv_gallery', array($this, 'advance_gallery_shortcode'));
            add_shortcode('fat_gallery_justified', array($this, 'justified_gallery_shortcode'));
            add_shortcode('fat_gallery', array($this, 'gallery_shortcode'));
            add_shortcode('fat_gallery_slider', array($this, 'gallery_slider_shortcode'));
            add_shortcode('fat_gallery_3d', array($this, 'gallery_3d_shortcode'));
            add_shortcode('fat_gallery_galleria', array($this, 'gallery_galleria_shortcode'));
            add_shortcode('fat_gallery_album', array($this, 'gallery_album_shortcode'));
            if (is_admin()) {
                add_filter('manage_edit-' . FAT_GALLERY_POST_TYPE . '_columns', array($this, 'add_admin_columns'));
                add_action('manage_' . FAT_GALLERY_POST_TYPE . '_posts_custom_column', array($this, 'set_admin_columns_value'), 10, 2);
                add_action('restrict_manage_posts', array($this, 'admin_manage_posts'));
                add_filter('parse_query', array($this, 'taxonomy_term_in_query'));
                add_action('admin_menu', array($this, 'addMenuChangeSlug'));
                add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'), 0);
            } else {
                add_filter('body_class', function ($classes) {
                    $settings = get_option(FAT_GALLERY_POST_TYPE . '-settings');
                    $popup_image_action = isset($settings['popup_image_action']) ? $settings['popup_image_action'] : 'fat-gallery-move';
                    return array_merge($classes, array($popup_image_action));
                }, 100);
            }
        }

        function add_admin_columns($columns)
        {
            unset(
                $columns['cb'],
                $columns['title'],
                $columns['date'],
                $columns['author']
            );
            $cols = array_merge(array('cb' => ('')), $columns);
            $cols = array_merge($cols, array('title' => esc_html__('Title', 'fat-gallery')));
            $cols = array_merge($cols, array('thumbnail' => esc_html__('Thumbnail', 'fat-gallery')));
            $cols = array_merge($cols, array(FAT_GALLERY_CATEGORY_TAXONOMY => esc_html__('Categories', 'fat-gallery')));
            $cols = array_merge($cols, array('author' => esc_html__('Author', 'fat-gallery')));
            $cols = array_merge($cols, array('date' => esc_html__('Date', 'fat-gallery')));
            return $cols;
        }

        function set_admin_columns_value($column, $post_id)
        {

            switch ($column) {
                case 'id':
                    {
                        echo wp_kses_post($post_id);
                        break;
                    }
                case 'thumbnail':
                    {
                        echo get_the_post_thumbnail($post_id, 'thumbnail');
                        break;
                    }
                case 'author':
                    {
                        echo get_the_author_link();
                        break;
                    }
                case FAT_GALLERY_CATEGORY_TAXONOMY:
                    {
                        $terms = wp_get_post_terms(get_the_ID(), array(FAT_GALLERY_CATEGORY_TAXONOMY));
                        $cat = '<ul>';
                        foreach ($terms as $term) {
                            $cat .= '<li><a href="' . get_term_link($term, FAT_GALLERY_CATEGORY_TAXONOMY) . '">' . $term->name . '<a/></li>';
                        }
                        $cat .= '</ul>';
                        echo wp_kses_post($cat);
                        break;
                    }
            }
        }

        function admin_manage_posts()
        {
            global $typenow;
            if ($typenow == FAT_GALLERY_POST_TYPE) {
                $selected = isset($_GET[FAT_GALLERY_CATEGORY_TAXONOMY]) ? $_GET[FAT_GALLERY_CATEGORY_TAXONOMY] : '';
                $args = array(
                    'show_count' => true,
                    'show_option_all' => esc_html__('Show All Categories', 'fat-gallery'),
                    'taxonomy' => FAT_GALLERY_CATEGORY_TAXONOMY,
                    'name' => FAT_GALLERY_CATEGORY_TAXONOMY,
                    'selected' => $selected,

                );
                wp_dropdown_categories($args);
            }
        }

        function taxonomy_term_in_query($query)
        {
            global $pagenow;
            $qv = &$query->query_vars;
            if ($pagenow == 'edit.php' &&
                isset($qv[FAT_GALLERY_CATEGORY_TAXONOMY]) &&
                is_numeric($qv[FAT_GALLERY_CATEGORY_TAXONOMY])
            ) {
                $term = get_term_by('id', $qv[FAT_GALLERY_CATEGORY_TAXONOMY], FAT_GALLERY_CATEGORY_TAXONOMY);
                $qv[FAT_GALLERY_CATEGORY_TAXONOMY] = $term->slug;
            }
        }

        function load_text_domain()
        {
            load_plugin_textdomain('fat-gallery', false, plugin_basename(dirname(__FILE__)) . '/languages');
        }

        function front_scripts($detail_effect = '')
        {
            wp_dequeue_script('retinajs');
            wp_enqueue_style('font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), false);
            wp_enqueue_style('fat-magnific-css', plugins_url() . '/fat-gallery/assets/js/magnific-popup/magnific-popup.css', array(), false);
            wp_enqueue_style('fat-ladda-css', plugins_url() . '/fat-gallery/assets/js/ladda/ladda-themeless.min.css', array(), false);

            wp_enqueue_script('modernizr', plugins_url() . '/fat-gallery/assets/js/modernizr-custom.js', array('jquery'), false, true);
            wp_enqueue_script('isotope', plugins_url() . '/fat-gallery/assets/js/isotope/isotope.pkgd.min.js', array('jquery'), false, true);
            wp_enqueue_script('imagesloaded', plugins_url() . '/fat-gallery/assets/js/codo-effects/imagesloaded.pkgd.min.js', array('jquery'), false, true);
            wp_enqueue_script('magnific-popup', plugins_url() . '/fat-gallery/assets/js/magnific-popup/jquery.magnific-popup.min.js', array('jquery'), false, true);
            wp_enqueue_script('ladda-spin', plugins_url() . '/fat-gallery/assets/js/ladda/spin.min.js', array('jquery', 'common'), array('jquery'), false, true);
            wp_enqueue_script('ladda', plugins_url() . '/fat-gallery/assets/js/ladda/ladda.min.js', array('jquery', 'common'), array('jquery'), false, true);

            wp_enqueue_script('hoverdir', plugins_url() . '/fat-gallery/assets/js/hoverdir/jquery.hoverdir.js', array('jquery', 'common'), false, true);

            if ($detail_effect == 'codoEffect' || $detail_effect == 'all') {
                wp_enqueue_script('classie', plugins_url() . '/fat-gallery/assets/js/codo-effects/classie.js', array('jquery'), false, true);
                wp_enqueue_script('masonry', plugins_url() . '/fat-gallery/assets/js/codo-effects/masonry.pkgd.min.js', array('jquery'), false, true);
                wp_enqueue_script('codo-gridfx', plugins_url() . '/fat-gallery/assets/js/codo-effects/grid-fx.js', array('jquery'), '1.3', true);
            }
            if ($detail_effect == '3d' || $detail_effect == 'all') {
                wp_enqueue_script('jquery-3d-gallery', plugins_url() . '/fat-gallery/assets/js/jquery-gallery/jquery.gallery.js', '1.1.0', true);
            }
            if ($detail_effect == 'slider' || $detail_effect == 'all') {
                wp_enqueue_script('jquery-owl-carousel', plugins_url() . '/fat-gallery/assets/js/owl-carousel/owl.carousel.min.js', false, true);
            }
            if ($detail_effect == 'galleria' || $detail_effect == 'all') {
                wp_enqueue_script('galleria', plugins_url() . '/fat-gallery/assets/js/galleria/galleria-1.4.2.min.js', false, true);
                wp_enqueue_script('galleria-classic', plugins_url() . '/fat-gallery/assets/js/galleria/themes/classic/galleria.classic.min.js', false, true);
            }
            if ($detail_effect == 'justified' || $detail_effect == 'all') {
                wp_enqueue_script('justified-gallery', plugins_url() . '/fat-gallery/assets/js/justified-gallery/justified-gallery.min.js', false, true);
            }

            wp_enqueue_script('jquery-light-gallery', plugins_url() . '/fat-gallery/assets/js/light-gallery/js/lightgallery.min.js', false, true);

            wp_enqueue_style('jquery-light-gallery', plugins_url() . '/fat-gallery/assets/js/light-gallery/css/lightgallery.min.css', array(), false);
            wp_enqueue_style('jquery-light-gallery-transition', plugins_url() . '/fat-gallery/assets/js/light-gallery/css/lg-transitions.min.css', array(), false);

            if ($detail_effect == '3d' || $detail_effect == 'all') {
                wp_enqueue_style('jquery-gallery-css', plugins_url() . '/fat-gallery/assets/js/jquery-gallery/jquery.gallery.css', array(), false);
            }
            if ($detail_effect == 'slider' || $detail_effect == 'all') {
                wp_enqueue_style('animate-css', plugins_url() . '/fat-gallery/assets/js/owl-carousel/animate.css', array(), false);
                wp_enqueue_style('jquery-owl-carousel-css', plugins_url() . '/fat-gallery/assets/js/owl-carousel/owl.carousel.css', array(), false);
            }
            if ($detail_effect == 'justified' || $detail_effect == 'all') {
                wp_enqueue_style('justified-gallery', plugins_url() . '/fat-gallery/assets/js/justified-gallery/justified-gallery.min.css', array(), false);
            }
            wp_enqueue_script('fat-gallery', plugins_url() . '/fat-gallery/assets/js/gallery.js', array('jquery'), '1.4.5', true);
            wp_enqueue_style('fat-gallery-css', plugins_url() . '/fat-gallery/assets/css/frontend/gallery.css', array(), false);
            //wp_register_style('fat-gallery-css', plugins_url() . '/fat-gallery/assets/css/frontend/gallery.css', array(), '1.4.4');
            //wp_print_styles('fat-gallery-css');
        }

        function admin_enqueue_scripts()
        {
            wp_register_style('fat-gallery-css', plugins_url() . '/fat-gallery/assets/css/admin/gallery.css', array(), false);
            wp_print_styles('fat-gallery-css');

            wp_enqueue_style('selectize', plugins_url() . '/fat-gallery/assets/js/selectize/css/selectize.css', array(), false);
            wp_enqueue_style('selectize-default', plugins_url() . '/fat-gallery/assets/js/selectize/css/selectize.default.css', array(), false);
            wp_enqueue_script('selectize', plugins_url() . '/fat-gallery/assets/js/selectize/js/selectize.min.js', array('jquery-ui-sortable'), false, true);
        }

        function register_post_types()
        {

            $post_type = FAT_GALLERY_POST_TYPE;
            $slug = 'fat-gallery';
            $name = $singular_name = 'FAT Gallery';

            if (post_type_exists($post_type)) {
                return;
            }
            $fat_settings = $this->get_settings();
            if (isset($fat_settings['slug']) && $fat_settings['slug'] != '') {
                $slug = $fat_settings['slug'];
            }

            register_post_type($post_type,
                array(
                    'label' => esc_html__('Gallery', 'fat-gallery'),
                    'description' => esc_html__('Gallery Description', 'fat-gallery'),
                    'labels' => array(
                        'name' => $name,
                        'singular_name' => $singular_name,
                        'menu_name' => ucfirst($name),
                        'parent_item_colon' => esc_html__('Parent Item:', 'fat-gallery'),
                        'all_items' => sprintf(esc_html__('All %s', 'fat-gallery'), $name),
                        'view_item' => esc_html__('View Item', 'fat-gallery'),
                        'add_new_item' => sprintf(esc_html__('Add New  %s', 'fat-gallery'), $name),
                        'add_new' => esc_html__('Add New', 'fat-gallery'),
                        'edit_item' => esc_html__('Edit Item', 'fat-gallery'),
                        'update_item' => esc_html__('Update Item', 'fat-gallery'),
                        'search_items' => esc_html__('Search Item', 'fat-gallery'),
                        'not_found' => esc_html__('Not found', 'fat-gallery'),
                        'not_found_in_trash' => esc_html__('Not found in Trash', 'fat-gallery'),
                    ),
                    'supports' => array('title', 'thumbnail', 'editor'),
                    'public' => false,
                    'show_ui' => true,
                    '_builtin' => false,
                    'has_archive' => true,
                    'menu_icon' => 'dashicons-format-gallery',
                    'rewrite' => array('slug' => $slug, 'with_front' => true),
                )
            );
            if (isset($fat_settings['require_flush_slug']) && $fat_settings['require_flush_slug'] == '1') {
                $fat_settings['require_flush_slug'] = 0;
                update_option(FAT_GALLERY_POST_TYPE . '-settings', $fat_settings);
                flush_rewrite_rules();
            }

        }

        function register_taxonomies()
        {
            if (taxonomy_exists(FAT_GALLERY_CATEGORY_TAXONOMY)) {
                return;
            }

            $taxonomy_slug = FAT_GALLERY_CATEGORY_TAXONOMY;
            $taxonomy_name = 'Gallery Categories';

            $fat_settings = $this->get_settings();
            if (isset($fat_settings['category_slug']) && $fat_settings['category_slug'] != '') {
                $taxonomy_slug = $fat_settings['category_slug'];
            }

            register_taxonomy(FAT_GALLERY_CATEGORY_TAXONOMY, FAT_GALLERY_POST_TYPE,
                array('hierarchical' => true,
                    'label' => $taxonomy_name,
                    'query_var' => true,
                    'rewrite' => array('slug' => $taxonomy_slug))
            );
            if (isset($fat_settings['require_flush_category_slug']) && $fat_settings['require_flush_category_slug'] == '1') {
                $fat_settings['require_flush_category_slug'] = 0;
                update_option(FAT_GALLERY_POST_TYPE . '-settings', $fat_settings);
                flush_rewrite_rules();
            }
        }

        function register_vc_shortcode()
        {
            if (function_exists('vc_map')) {
                $gallery_categories = get_terms(FAT_GALLERY_CATEGORY_TAXONOMY, array('hide_empty' => 0, 'orderby' => 'ASC', 'offset' => 0, 'number' => 0));
                $gallery_cat = array();
                if (is_array($gallery_categories)) {
                    foreach ($gallery_categories as $cat) {
                        $gallery_cat[$cat->name . ' ( ' . $cat->slug . ' )'] = $cat->slug;
                    }
                }
                $args = array(
                    'posts_per_page' => -1,
                    'post_type' => FAT_GALLERY_POST_TYPE,
                    'post_status' => 'publish');
                $list_gallery = array();
                $post_array = get_posts($args);
                foreach ($post_array as $post) : setup_postdata($post);
                    $list_gallery[$post->post_title] = $post->ID;
                endforeach;
                wp_reset_postdata();

                vc_map(array(
                    'name' => 'FAT Gallery',
                    'base' => 'fat_adv_gallery',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Layout', 'fat-gallery'),
                            'param_name' => 'layout_type',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Grid', 'fat-gallery') => 'grid',
                                esc_html__('Masonry', 'fat-gallery') => 'masonry',
                                esc_html__('Codo Effect', 'fat-gallery') => 'codo-effect'
                            )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Display', 'fat-gallery'),
                            'param_name' => 'display_type',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Compact', 'fat-gallery') => '',
                                esc_html__('Full', 'fat-gallery') => 'full'),
                            'dependency' => Array('element' => 'layout_type', 'value' => array('grid', 'masonry'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Hover effect', 'fat-gallery'),
                            'param_name' => 'overlay_style',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Hover dir', 'fat-gallery') => 'icon-view',
                                esc_html__('Lily', 'fat-gallery') => 'lily',
                                esc_html__('Zoe', 'fat-gallery') => 'zoe'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Detail Popup Effect', 'fat-gallery'),
                            'param_name' => 'popup_type',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Ligh gallery', 'fat-gallery') => 'light-gallery',
                                esc_html__('Maginic Popup', 'fat-gallery') => 'magnificPopup'),
                            'std' => 'light-gallery',
                            'dependency' => Array('element' => 'layout_type', 'value' => array('grid', 'masonry'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Detail Popup Effect', 'fat-gallery'),
                            'param_name' => 'popup_transition',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Slide', 'fat-gallery') => 'lg-slide',
                                esc_html__('Fade', 'fat-gallery') => 'lg-fade',
                                esc_html__('Zoom in', 'fat-gallery') => 'lg-zoom-in',
                                esc_html__('Zoom out', 'fat-gallery') => 'lg-zoom-out',
                                esc_html__('Zoom out in', 'fat-gallery') => 'lg-zoom-out-in',
                                esc_html__('Scale up', 'fat-gallery') => 'lg-scale-up',
                                esc_html__('Slide Circular', 'fat-gallery') => 'lg-slide-circular'
                            ),
                            'std' => 'lg-slide',
                            'dependency' => Array('element' => 'popup_type', 'value' => array('light-gallery'))
                        ),


                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Image size (width x height .ex: 475x360)', 'fat-gallery'),
                            'param_name' => 'image_size',
                            'admin_label' => true,
                            'value' => '475x475'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Select Source', 'fat-gallery'),
                            'param_name' => 'data_source',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('From Category', 'fat-gallery') => 'category',
                                esc_html__('From Gallery IDs', 'fat-gallery') => 'list_id')
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Category', 'fat-gallery'),
                            'param_name' => 'category',
                            'admin_label' => true,
                            'options' => $gallery_cat,
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery,
                            'dependency' => Array('element' => 'data_source', 'value' => array('list_id'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Display Category', 'fat-gallery'),
                            'param_name' => 'show_category',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                esc_html__('Show in left', 'fat-gallery') => 'left',
                                esc_html__('Show in center', 'fat-gallery') => 'center',
                                esc_html__('Show in right', 'fat-gallery') => 'right')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Category Style', 'fat-gallery'),
                            'param_name' => 'category_style',
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Normal', 'fat-gallery') => 'normal',
                                esc_html__('Uppercase', 'fat-gallery') => 'uppercase',
                                esc_html__('Lowercase', 'fat-gallery') => 'lowercase',
                                esc_html__('Italic', 'fat-gallery') => 'italic',
                                esc_html__('Bold', 'fat-gallery') => 'bold'),
                            'std' => '',
                            'dependency' => Array('element' => 'show_category', 'value' => array('left', 'center', 'right'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Filter type', 'fat-gallery'),
                            'param_name' => 'filter_type',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Isotope', 'fat-gallery') => 'isotope',
                                esc_html__('Ajax', 'fat-gallery') => 'ajax'),
                            'dependency' => Array('element' => 'show_category', 'value' => array('left', 'center', 'right'))

                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Animation filter / load more', 'fat-gallery'),
                            'param_name' => 'animation_filter',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Yes', 'fat-gallery') => '1',
                                esc_html__('No', 'fat-gallery') => '0')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Number of column', 'fat-gallery'),
                            'param_name' => 'column',
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('5 columns', 'fat-gallery') => '5',
                                esc_html__('4 columns', 'fat-gallery') => '4',
                                esc_html__('3 columns', 'fat-gallery') => '3',
                                esc_html__('2 columns', 'fat-gallery') => '2',
                                esc_html__('1 column', 'fat-gallery') => '1'
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Number of item (or number of item per page if choose show paging)', 'fat-gallery'),
                            'param_name' => 'item',
                            'value' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order By', 'fat-gallery'),
                            'param_name' => 'order_by',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => 'none',
                                esc_html__('Post Id', 'fat-gallery') => 'ID',
                                esc_html__('Title', 'fat-gallery') => 'title',
                                esc_html__('Post slug', 'fat-gallery') => 'name',
                                esc_html__('Random', 'fat-gallery') => 'rand',
                            )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order', 'fat-gallery'),
                            'param_name' => 'order',
                            'value' => array(esc_html__('Descending', 'fat-gallery') => 'DESC', esc_html__('Ascending', 'fat-gallery') => 'ASC')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Show Paging', 'fat-gallery'),
                            'param_name' => 'show_pagging',
                            'value' => array(
                                'None' => '',
                                esc_html__('Load more', 'fat-gallery') => '1'),
                            'std' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Padding', 'fat-gallery'),
                            'param_name' => 'padding',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                '5 px' => 'col-padding-5',
                                '10 px' => 'col-padding-10',
                                '15 px' => 'col-padding-15',
                                '20 px' => 'col-padding-20'
                            ),
                            'std' => ''

                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Overlay Background Color', 'fat-gallery'),
                            'param_name' => 'bg_color',
                            'value' => array(
                                esc_html__('Inherit from settings', 'fat-gallery') => 'inherit',
                                esc_html__('Dark', 'fat-gallery') => 'bg-dark',
                                esc_html__('Light', 'fat-gallery') => 'bg-light'),
                            'std' => 'inherit'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Title Style', 'fat-gallery'),
                            'param_name' => 'title_style',
                            'value' => array(
                                esc_html__('Normal', 'fat-gallery') => 'normal',
                                esc_html__('Uppercase', 'fat-gallery') => 'uppercase',
                                esc_html__('Lowercase', 'fat-gallery') => 'lowercase',
                                esc_html__('Italic', 'fat-gallery') => 'italic',
                                esc_html__('Bold', 'fat-gallery') => 'bold'),
                            'std' => 'normal'
                        )
                    )
                ));

                vc_map(array(
                    'name' => 'FAT Justified Gallery',
                    'base' => 'fat_gallery_justified',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Select Source', 'fat-gallery'),
                            'param_name' => 'data_source',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('From Category', 'fat-gallery') => 'category',
                                esc_html__('From Gallery IDs', 'fat-gallery') => 'list_id')
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Category', 'fat-gallery'),
                            'param_name' => 'category',
                            'admin_label' => true,
                            'options' => $gallery_cat,
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery,
                            'dependency' => Array('element' => 'data_source', 'value' => array('list_id'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Display Category', 'fat-gallery'),
                            'param_name' => 'show_category',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                esc_html__('Show in left', 'fat-gallery') => 'left',
                                esc_html__('Show in center', 'fat-gallery') => 'center',
                                esc_html__('Show in right', 'fat-gallery') => 'right')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Category Style', 'fat-gallery'),
                            'param_name' => 'category_style',
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Normal', 'fat-gallery') => 'normal',
                                esc_html__('Uppercase', 'fat-gallery') => 'uppercase',
                                esc_html__('Lowercase', 'fat-gallery') => 'lowercase',
                                esc_html__('Italic', 'fat-gallery') => 'italic',
                                esc_html__('Bold', 'fat-gallery') => 'bold'),
                            'std' => '',
                            'dependency' => Array('element' => 'show_category', 'value' => array('left', 'center', 'right'))
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Row height', 'fat-gallery'),
                            'param_name' => 'row_height',
                            'value' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Number of item (or number of item per page if choose show paging)', 'fat-gallery'),
                            'param_name' => 'item',
                            'value' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order By', 'fat-gallery'),
                            'param_name' => 'order_by',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => 'none',
                                esc_html__('Post Id', 'fat-gallery') => 'ID',
                                esc_html__('Title', 'fat-gallery') => 'title',
                                esc_html__('Post slug', 'fat-gallery') => 'name',
                                esc_html__('Random', 'fat-gallery') => 'rand',
                            )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Order Post Date By', 'fat-gallery'),
                            'param_name' => 'order',
                            'value' => array(esc_html__('Descending', 'fat-gallery') => 'DESC', esc_html__('Ascending', 'fat-gallery') => 'ASC')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Show Paging', 'fat-gallery'),
                            'param_name' => 'show_pagging',
                            'value' => array(
                                'None' => '',
                                esc_html__('Load more', 'fat-gallery') => '1'),
                            'std' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Margin', 'fat-gallery'),
                            'param_name' => 'margin',
                            'value' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Overlay Background Color', 'fat-gallery'),
                            'param_name' => 'bg_color',
                            'value' => array(
                                esc_html__('Inherit from settings', 'fat-gallery') => 'inherit',
                                esc_html__('Dark', 'fat-gallery') => 'bg-dark',
                                esc_html__('Light', 'fat-gallery') => 'bg-light'),
                            'std' => 'inherit'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Title Style', 'fat-gallery'),
                            'param_name' => 'title_style',
                            'value' => array(
                                esc_html__('Normal', 'fat-gallery') => 'normal',
                                esc_html__('Uppercase', 'fat-gallery') => 'uppercase',
                                esc_html__('Lowercase', 'fat-gallery') => 'lowercase',
                                esc_html__('Italic', 'fat-gallery') => 'italic',
                                esc_html__('Bold', 'fat-gallery') => 'bold'),
                            'std' => 'normal'
                        )
                    )
                ));

                vc_map(array(
                    'name' => 'FAT Gallery 3D Slider',
                    'base' => 'fat_gallery_3d',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Auto play', 'fat-gallery'),
                            'param_name' => 'auto_play',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Navigation position', 'fat-gallery'),
                            'param_name' => 'nav_position',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Bottom', 'fat-gallery') => 'nav-bottom',
                                esc_html__('Middle', 'fat-gallery') => 'nav-middle')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Select Source', 'fat-gallery'),
                            'param_name' => 'data_source',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('From Category', 'fat-gallery') => 'category',
                                esc_html__('From Gallery IDs', 'fat-gallery') => 'list_id')
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Category', 'fat-gallery'),
                            'param_name' => 'category',
                            'admin_label' => true,
                            'options' => $gallery_cat,
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery,
                            'dependency' => Array('element' => 'data_source', 'value' => array('list_id'))
                        ),
                    )
                ));

                vc_map(array(
                    'name' => 'FAT Gallery Slider',
                    'base' => 'fat_gallery_slider',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Display', 'fat-gallery'),
                            'param_name' => 'display_type',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Full', 'fat-gallery') => 'full',
                                esc_html__('Compact', 'fat-gallery') => ''),
                            'dependency' => Array('element' => 'layout_type', 'value' => array('grid', 'masonry'))
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Image size (width x height .ex: 475x360)', 'fat-gallery'),
                            'param_name' => 'image_size',
                            'admin_label' => true,
                            'value' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Auto play', 'fat-gallery'),
                            'param_name' => 'auto_play',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Columns', 'fat-gallery'),
                            'param_name' => 'columns',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('1 column', 'fat-gallery') => '1',
                                esc_html__('2 columns', 'fat-gallery') => '2',
                                esc_html__('3 columns', 'fat-gallery') => '3',
                                esc_html__('4 columns', 'fat-gallery') => '4',
                                esc_html__('5 columns', 'fat-gallery') => '5',
                                esc_html__('6 columns', 'fat-gallery') => '6'
                            )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Margin between items', 'fat-gallery'),
                            'param_name' => 'margin',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('5 px', 'fat-gallery') => '5',
                                esc_html__('10 px', 'fat-gallery') => '10',
                                esc_html__('15 px', 'fat-gallery') => '15',
                                esc_html__('20 px', 'fat-gallery') => '20',
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Loop', 'fat-gallery'),
                            'param_name' => 'loop',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Center', 'fat-gallery'),
                            'param_name' => 'center',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('No', 'fat-gallery') => 'false',
                                esc_html__('Yes', 'fat-gallery') => 'true')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Animation', 'fat-gallery'),
                            'param_name' => 'animation',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Show navigation', 'fat-gallery'),
                            'param_name' => 'show_nav',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Navigation position', 'fat-gallery'),
                            'param_name' => 'nav_position',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Bottom', 'fat-gallery') => 'nav-bottom',
                                esc_html__('Middle', 'fat-gallery') => 'nav-middle')
                        ),

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Show dot paging', 'fat-gallery'),
                            'param_name' => 'show_dot',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('Yes', 'fat-gallery') => 'true',
                                esc_html__('No', 'fat-gallery') => 'false')
                        ),

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Select Source', 'fat-gallery'),
                            'param_name' => 'data_source',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('From Category', 'fat-gallery') => 'category',
                                esc_html__('From Gallery IDs', 'fat-gallery') => 'list_id')
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Category', 'fat-gallery'),
                            'param_name' => 'category',
                            'admin_label' => true,
                            'options' => $gallery_cat,
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery,
                            'dependency' => Array('element' => 'data_source', 'value' => array('list_id'))
                        ),
                    )
                ));

                vc_map(array(
                    'name' => 'FAT Galleria',
                    'base' => 'fat_gallery_galleria',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Width (empty for full width)', 'fat-gallery'),
                            'param_name' => 'width',
                            'admin_label' => true,
                            'value' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Width (empty for full height)', 'fat-gallery'),
                            'param_name' => 'height',
                            'admin_label' => true,
                            'value' => ''
                        )

                    )
                ));

                vc_map(array(
                    'name' => 'FAT Album',
                    'base' => 'fat_gallery_album',
                    'icon' => 'dashicons dashicons-format-gallery',
                    'category' => esc_html__('FAT Shortcode', 'fat-gallery'),
                    'description' => esc_html__('A custom gallery for your site', 'fat-gallery'),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Select Source', 'fat-gallery'),
                            'param_name' => 'data_source',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('From Category', 'fat-gallery') => 'category',
                                esc_html__('From Gallery IDs', 'fat-gallery') => 'list_id')
                        ),

                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Category', 'fat-gallery'),
                            'param_name' => 'category',
                            'admin_label' => true,
                            'options' => $gallery_cat,
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),
                        array(
                            'type' => 'select2',
                            'heading' => esc_html__('Select Gallery', 'fat-gallery'),
                            'param_name' => 'gallery_ids',
                            'options' => $list_gallery,
                            'dependency' => Array('element' => 'data_source', 'value' => array('list_id'))
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Display Category', 'fat-gallery'),
                            'param_name' => 'show_category',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                esc_html__('Show in left', 'fat-gallery') => 'left',
                                esc_html__('Show in center', 'fat-gallery') => 'center',
                                esc_html__('Show in right', 'fat-gallery') => 'right'),
                            'dependency' => Array('element' => 'data_source', 'value' => array('category'))
                        ),

                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Number of column', 'fat-gallery'),
                            'param_name' => 'column',
                            'value' => array(
                                esc_html__('Inherit from setting', 'fat-gallery') => '',
                                esc_html__('5 columns', 'fat-gallery') => '5',
                                esc_html__('4 columns', 'fat-gallery') => '4',
                                esc_html__('3 columns', 'fat-gallery') => '3',
                                esc_html__('2 columns', 'fat-gallery') => '2',
                                esc_html__('1 column', 'fat-gallery') => '1'
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Image size on thumbnail (width x height .ex: 170x127)', 'fat-gallery'),
                            'param_name' => 'image_size',
                            'admin_label' => true,
                            'value' => '170x127'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Number of column on each album', 'fat-gallery'),
                            'param_name' => 'column_of_album',
                            'value' => array(
                                esc_html__('5 columns', 'fat-gallery') => '5',
                                esc_html__('4 columns', 'fat-gallery') => '4',
                                esc_html__('3 columns', 'fat-gallery') => '3',
                                esc_html__('2 columns', 'fat-gallery') => '2',
                            ),
                            'std' => '3'
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Total item on each album', 'fat-gallery'),
                            'param_name' => 'total_item_of_album',
                            'value' => '9'
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Padding', 'fat-gallery'),
                            'param_name' => 'padding',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                '5 px' => 'col-padding-5',
                                '10 px' => 'col-padding-10',
                                '15 px' => 'col-padding-15',
                                '20 px' => 'col-padding-20'
                            ),
                            'std' => ''

                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Has box shadow on item', 'fat-gallery'),
                            'param_name' => 'has_box_shadow',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                'Yes' => 'has-shadow'
                            ),
                            'std' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Has padding item on thumbnail', 'fat-gallery'),
                            'param_name' => 'has_padding',
                            'value' => array(
                                esc_html__('None', 'fat-gallery') => '',
                                'Yes' => 'has-padding'
                            ),
                            'std' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => esc_html__('Detail Popup Effect', 'fat-gallery'),
                            'param_name' => 'popup_transition',
                            'admin_label' => true,
                            'value' => array(
                                esc_html__('Slide', 'fat-gallery') => 'lg-slide',
                                esc_html__('Fade', 'fat-gallery') => 'lg-fade',
                                esc_html__('Zoom in', 'fat-gallery') => 'lg-zoom-in',
                                esc_html__('Zoom out', 'fat-gallery') => 'lg-zoom-out',
                                esc_html__('Zoom out in', 'fat-gallery') => 'lg-zoom-out-in',
                                esc_html__('Scale up', 'fat-gallery') => 'lg-scale-up',
                                esc_html__('Slide Circular', 'fat-gallery') => 'lg-slide-circular'
                            ),
                            'std' => 'lg-slide'
                        )
                    )
                ));
            }
        }

        function advance_gallery_shortcode($atts)
        {
            $detail_effect = $popup_transition = $popup_type = $display_type = $image_size = $animation_filter = $ajax_load = $overlay_style = $filter_type = $category_position =
            $data_source = $gallery_ids = $layout_type = $offset = $current_page = $show_pagging = $show_category = $category = $column = $item =
            $padding = $bg_color = $title_style = $oder_by = $order = '';
            extract(shortcode_atts(array(
                'display_type' => '',
                'overlay_style' => 'icon-view',
                'layout_type' => 'grid',
                'popup_type' => 'light-gallery',
                'popup_transition' => 'lg-slide',
                'image_size' => '475x475',
                'data_source' => '',
                'show_pagging' => '',
                'show_category' => '',
                'default_category' => '',
                'show_root_category' => '1',
                'category' => '',
                'category_style' => 'normal',
                'gallery_ids' => '',
                'filter_type' => 'isotope',
                'animation_filter' => '1',
                'column' => '5',
                'item' => '',
                'order_by' => 'none',
                'order' => 'DESC',
                'padding' => '',
                'bg_color' => '',
                'title_style' => 'normal',
                'current_page' => '1',
                'ajax_load' => '0',
                'detail_effect' => 'magnificPopup'
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            //$overlay_style = 'icon-view';
            $hover_effect = $overlay_style == 'icon-view' ? 'hover-dir' : $overlay_style;
            if ($item == '') {
                $offset = 0;
                $post_per_page = -1;
            } else {
                $post_per_page = $item;
                $offset = ($current_page - 1) * $item;
            }
            $detail_effect = $layout_type == 'codo-effect' ? 'codoEffect' : $popup_type;
            $this->front_scripts($detail_effect);
            add_action('wp_footer', array($this, 'generate_custom_css'));
            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-advance.php';
            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;
        }

        function justified_gallery_shortcode($atts)
        {

            $data_source = $category = $gallery_ids = $show_category = $category_style = $row_height = $item = $order = $show_pagging
                = $margin = $bg_color = $title_style = $current_page = $offset = $post_per_page = '';

            extract(shortcode_atts(array(
                'data_source' => '',
                'category' => '',
                'gallery_ids' => '',
                'show_category' => '',
                'category_style' => 'normal',
                'row_height' => '120',
                'item' => '',
                'show_pagging' => '',
                'order' => 'DESC',
                'margin' => '',
                'bg_color' => '',
                'title_style' => 'normal',
                'current_page' => '1',
                'ajax_load' => '0'
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            $overlay_style = 'icon-view';
            if ($item == '') {
                $offset = 0;
                $post_per_page = -1;
            } else {
                $post_per_page = $item;
                $offset = ($current_page - 1) * $item;
            }
            $this->front_scripts('justified');
            add_action('wp_footer', array($this, 'generate_custom_css'));

            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-justified.php';
            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;
        }

        function gallery_3d_shortcode($atts)
        {
            $auto_play = $gallery_3d_enable_window = $nav_position = $category = $data_source = $gallery_ids = $oder_by = $order = '';
            $fat_settings = $this->get_settings();
            extract(shortcode_atts(array(
                'auto_play' => '',
                'nav_position' => '',
                'data_source' => '',
                'category' => '',
                'gallery_ids' => '',
                'image_width' => '',
                'image_height' => '',
                'order_by' => 'none',
                'order' => 'DESC',
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            if ($auto_play == '') {
                $auto_play = $fat_settings['gallery_3d_auto_play'];
            }
            if ($nav_position == '') {
                $nav_position = $fat_settings['gallery_3d_nav_position'];
            }
            $gallery_3d_enable_window = isset($fat_settings['gallery_3d_enable_window']) ? $fat_settings['gallery_3d_enable_window'] : '';
            $hover_effect = 'hover-dir';

            $this->front_scripts('3d');
            add_action('wp_footer', array($this, 'generate_custom_css'));

            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-3d.php';
            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;
        }

        function gallery_slider_shortcode($atts)
        {
            $display_type = $overlay_style = $layout_type = $auto_play = $image_size = $columns = $nav_position = $margin = $loop = $center = $animation = $show_nav = $show_dot = $category = $data_source = $gallery_ids = $oder_by = $order = '';
            $fat_settings = $this->get_settings();
            extract(shortcode_atts(array(
                'overlay_style' => 'icon-view',
                'layout_type' => 'grid',
                'display_type' => 'full',
                'image_size' => '',
                'auto_play' => '',
                'columns' => '',
                'margin' => '',
                'loop' => '',
                'center' => '',
                'animation' => '',
                'show_nav' => '',
                'nav_position' => '',
                'show_dot' => '',
                'data_source' => '',
                'order_by' => 'none',
                'order' => 'DESC',
                'category' => '',
                'gallery_ids' => ''
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            $columns = str_replace('col-', '', $columns);
            $image_carousel_size_width = isset($fat_settings['image_carousel_size_width']) ? $fat_settings['image_carousel_size_width'] : '270';
            $image_carousel_size_height = isset($fat_settings['image_carousel_size_height']) ? $fat_settings['image_carousel_size_height'] : '270';
            $image_size = $image_size == '' ? ($image_carousel_size_width . 'x' . $image_carousel_size_height) : $image_size;
            $auto_play = $auto_play == '' ? $fat_settings['carousel_auto_play'] : $auto_play;
            $columns = $columns == '' ? $fat_settings['carousel_columns'] : $columns;
            $margin = $margin == '' ? $fat_settings['carousel_margin'] : $margin;
            $loop = $loop == '' ? $fat_settings['carousel_loop'] : $loop;
            $center = $center == '' ? $fat_settings['carousel_center'] : $center;
            $animation = $animation == '' ? $fat_settings['carousel_animation'] : $animation;
            $show_nav = $show_nav == '' ? $fat_settings['carousel_show_nav'] : $show_nav;
            $nav_position = $nav_position == '' ? $fat_settings['carousel_nav_position'] : $nav_position;
            $show_dot = $show_dot == '' ? $fat_settings['carousel_show_dot'] : $show_dot;
            $hover_effect = $overlay_style == 'icon-view' ? 'hover-dir' : $overlay_style;

            $this->front_scripts('slider');
            add_action('wp_footer', array($this, 'generate_custom_css'));

            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-slider.php';
            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;
        }

        function gallery_shortcode($atts)
        {
            $fat_settings = $this->get_settings();
            $show_pagging = $show_category = $item = $gallery_ids = $title_style = $oder_by = $order = '';
            $display_type = 'full';
            $layout_type = isset($atts['layout_type']) ? $atts['layout_type'] : $fat_settings['layout_type'];
            $popup_type = isset($fat_settings['popup_type']) ? $fat_settings['popup_type'] : 'light-gallery';
            $popup_transition = isset($fat_settings['popup_transition']) ? $fat_settings['popup_transition'] : 'lg-slide';
            $image_size = isset($fat_settings['image_size_width']) && isset($fat_settings['image_size_height']) ? ($fat_settings['image_size_width'] . 'x' . $fat_settings['image_size_height']) : '475x475';
            if ($layout_type === 'masonry') {
                $image_size = '';
            }
            $data_source = 'list_id';
            $category_style = isset($fat_settings['category_style']) ? $fat_settings['category_style'] : 'normal';
            $filter_type = isset($fat_settings['filter_type']) ? $fat_settings['filter_type'] : 'ajax';
            $animation_filter = isset($fat_settings['animation_filter']) ? $fat_settings['animation_filter'] : '';
            $column = isset($fat_settings['columns']) ? $fat_settings['columns'] : '4';
            $order = 'DESC';
            $padding = isset($fat_settings['padding']) ? $fat_settings['padding'] : '';
            $bg_color = isset($fat_settings['bg_hover_color']) ? $fat_settings['bg_hover_color'] : '';
            $current_page = '1';
            $ajax_load = '0';
            $detail_effect = $layout_type == 'codo-effect' ? 'codoEffect' : $popup_type;
            $overlay_style = 'icon-view';
            $hover_effect = $overlay_style == 'icon-view' ? 'hover-dir' : $overlay_style;
            $offset = 0;
            $post_per_page = -1;

            extract(shortcode_atts(array(
                'gallery_ids' => '',
                'order_by' => 'none',
                'order' => 'DESC',
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            $this->front_scripts($detail_effect);
            add_action('wp_footer', array($this, 'generate_custom_css'));

            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing.php';

            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;

        }

        function gallery_galleria_shortcode($atts)
        {
            $fat_settings = $this->get_settings();
            $gallery_ids = $width = $heigh = $oder_by = $order = '';
            extract(shortcode_atts(array(
                'gallery_ids' => '',
                'width' => '',
                'height' => '',
                'order_by' => 'none',
                'order' => 'DESC',
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            $this->front_scripts('galleria');
            add_action('wp_footer', array($this, 'generate_custom_css'));

            $hover_effect = 'hover-dir';
            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-galleria.php';

            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;

        }

        function gallery_album_shortcode($atts)
        {
            $fat_settings = $this->get_settings();
            $data_source = $filter_type = $category = $show_category = $gallery_ids = $has_box_shadow = $has_padding = $padding = $column = $image_size = $popup_transition = $column_of_album = $total_item_of_album = $oder_by = $order = '';
            extract(shortcode_atts(array(
                'data_source' => '',
                'category' => '',
                'show_category' => '',
                'filter_type' => 'isotope',
                'gallery_ids' => '',
                'column' => '',
                'column_of_album' => 3,
                'total_item_of_album' => 9,
                'padding' => '',
                'has_box_shadow' => '',
                'has_padding' => '',
                'image_size' => '170x127',
                'popup_transition' => 'lg-slide',
                'order_by' => 'none',
                'order' => 'DESC',
            ), $atts));

            if (is_admin() && (!isset($atts['ajax_load']) || $atts['ajax_load'] != 1)) {
                return;
            }

            $column = $column && $column != '' ? $column : $fat_settings['columns'];
            $all_category_filter = isset($fat_settings['all_category_filter']) ? $fat_settings['all_category_filter'] : 'All';

            $this->front_scripts('album');
            add_action('wp_footer', array($this, 'generate_custom_css'));
            $hover_effect = 'hover-dir';
            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $template_path = $plugin_path . '/templates/listing-album.php';

            ob_start();
            include($template_path);
            $ret = ob_get_contents();
            ob_end_clean();
            return $ret;

        }

        function addMenuChangeSlug()
        {
            add_submenu_page('edit.php?post_type=' . FAT_GALLERY_POST_TYPE, 'Setting', 'Settings', 'edit_posts', wp_basename(__FILE__), array($this, 'initPageSettings'));
        }

        function initPageSettings()
        {
            $setting_path = untrailingslashit(plugin_dir_path(__FILE__) . '/settings/settings.php');
            if (file_exists($setting_path))
                include_once $setting_path;
        }

        function register_meta_boxes($meta_boxes)
        {
            $gallery_3d_shortcode = '';
            $gallery_slider_shortcode = '';
            $gallery_shortcode = '';
            if (isset($_GET['post'])) {
                $gallery_3d_shortcode = '[fat_gallery_3d data_source ="list_id" gallery_ids="' . $_GET['post'] . '"]';
                $gallery_slider_shortcode = '[fat_gallery_slider data_source ="list_id" gallery_ids="' . $_GET['post'] . '"]';
                $gallery_shortcode = '[fat_gallery data_source ="list_id" gallery_ids="' . $_GET['post'] . '"]';
            }

            $meta_boxes[] = array(
                'title' => esc_html__('Gallery Shortcode Generate', 'fat-gallery'),
                'id' => 'fat-meta-box-gallery-shortcode',
                'priority' => 'high',
                'pages' => array(FAT_GALLERY_POST_TYPE),
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'name' => __('Gallery 3D Shortcode : ', 'fat-gallery'),
                        'desc' => $gallery_3d_shortcode,
                    ),
                    array(
                        'type' => 'heading',
                        'name' => __('Gallery Slider Shortcode : ', 'fat-gallery'),
                        'desc' => $gallery_slider_shortcode,
                    ),
                    array(
                        'type' => 'heading',
                        'name' => __('Gallery Shortcode : ', 'fat-gallery'),
                        'desc' => $gallery_shortcode,
                    )
                )
            );

            $meta_boxes[] = array(
                'title' => esc_html__('Gallery Type', 'fat-gallery'),
                'id' => 'fat-meta-box-gallery-type',
                'priority' => 'high',
                'pages' => array(FAT_GALLERY_POST_TYPE),
                'fields' => array(
                    array(
                        'name' => esc_html__('Select gallery type', 'fat-gallery'),
                        'id' => 'fat_gallery_format',
                        'type' => 'radio',
                        'options' => array(
                            'image' => esc_html__('Image', 'your-prefix'),
                            'mix' => esc_html__('Mix Image and Video', 'your-prefix')
                        ),
                        'std' => 'image'
                    ),
                    array(
                        'name' => esc_html__('Link album detail page', 'fat-gallery'),
                        'id' => 'fat_gallery_album_page',
                        'type' => 'text',
                        'std' => ''
                    )
                )
            );
            $meta_boxes[] = array(
                'title' => esc_html__('Gallery', 'fat-gallery'),
                'id' => 'fat-meta-box-gallery',
                'pages' => array(FAT_GALLERY_POST_TYPE),
                'priority' => 'high',
                'fields' => array(
                    array(
                        'name' => esc_html__('Select images', 'fat-gallery'),
                        'desc' => esc_html__('Keep Ctrl to multiple choice', 'fat-gallery'),
                        'id' => 'galleries',
                        'type' => 'image_advanced',
                    )
                )
            );
            return $meta_boxes;
        }

        private function includes()
        {
            if (!class_exists('RWMB_Loader')) {
                include_once('meta-box/meta-box.php');
            }
            if (!class_exists('FAT_WPAlchemy_MetaBox')) {
                include_once('acf/MetaBox.php');
            }
            if (!class_exists('WPAlchemy_MediaAccess')) {
                include_once('acf/MediaAccess.php');
            }
            include_once('acf/spec.php');
            include_once('vc/vc-field.php');
            include_once('utils/ajax-action.php');
            include_once('utils/resize.php');
        }

        function generate_custom_css()
        {
            $fat_settings = $this->get_settings();
            ob_start();
            $plugin_path = untrailingslashit(plugin_dir_path(__FILE__));
            $css_template = $plugin_path . '/assets/css/frontend/custom-css.php';
            include_once($css_template);
            $custom_css = ob_get_contents();
            ob_end_clean();
            echo $custom_css;
        }

        private function get_settings()
        {
            $fat_settings = array(
                'slug' => FAT_GALLERY_POST_TYPE,
                'category_slug' => FAT_GALLERY_CATEGORY_TAXONOMY,
                'require_flush_rewrite' => '0',
                'require_flush_category_slug' => '0',
                'all_category_filter' => 'All',
                'view_more' => 'View more',
                'hide_title' => '',
                'hide_excerpt' => '',
                'disable_crop_masonry' => '',
                'layout_type' => 'grid',
                'popup_type' => 'magnificPopup',
                'popup_transition' => 'lg-slide',
                'filter_type' => 'isotope',
                'animation_filter' => '1',
                'show_paging' => '',
                'padding' => 'col-padding-5',
                'columns' => '4',
                'image_size_width' => '475',
                'image_size_height' => '475',
                'category_font_size' => '14',
                'category_style' => 'normal',
                'category_text_transform' => 'none',
                'category_text_color' => '#333',
                'category_text_hover_color' => '#333',
                'title_font_size' => '14',
                'title_style' => 'normal',
                'title_text_transform' => 'none',
                'title_text_color' => '#333',
                'icon_font_size' => '14',
                'icon_color' => '#333',
                'icon_hover_color' => '#333',
                'bg_hover_color' => 'rgba(40, 150, 223, 0.8)',
                'loading_color' => '#333',
                'gallery_3d_enable_window' => 'true',
                'gallery_3d_auto_play' => 'true',
                'gallery_3d_nav_position' => 'nav-bottom',
                'carousel_auto_play' => 'true',
                'carousel_columns' => '4',
                'image_carousel_size_width' => '270',
                'image_carousel_size_height' => '270',
                'carousel_padding' => '',
                'carousel_loop' => '0',
                'carousel_center' => '0',
                'carousel_animation' => '',
                'carousel_show_nav' => '1',
                'carousel_nav_position' => 'nav-bottom',
                'carousel_show_dot' => '0',
                'custom_css' => '',
            );
            $settings = get_option(FAT_GALLERY_POST_TYPE . '-settings', $fat_settings);

            if (isset($settings) && is_array($settings)) {
                $fat_settings = array_merge($fat_settings, $settings);
            }
            return $fat_settings;
        }

        function add_metabox_to_attachment()
        {
            add_meta_box('custom-attachment-meta-box',
                'Attachment Extra Details',
                array($this, 'attachment_meta_box_callback'),
                'attachment',
                'normal',
                'low');
        }

        function save_attachment_meta()
        {
            global $post;
            if (isset($_POST['extra_class'])) {
                update_post_meta($post->ID, 'extra_class', $_POST['extra_class']);
            }
            if (isset($_POST['extra_title_link'])) {
                update_post_meta($post->ID, 'extra_title_link', $_POST['extra_title_link']);
            }
        }

        function attachment_meta_box_callback()
        {
            global $post;
            $value = get_post_meta($post->ID, 'extra_class', 1);
            $value = isset($value) && $value !== null ? $value : '';
            $title_link = get_post_meta($post->ID, 'extra_title_link', 1);
            $title_link = isset($title_link) && $title_link !== null ? $title_link : '';
            ?>
            <p>
                <label><?php echo esc_html__('Class name', 'fat-gallery'); ?></label>
                <input type="text" name="extra_class" value="<?php echo esc_attr($value); ?>"/>
            </p>
            <p>
                <label><?php echo esc_html__('Title link on popup gallery', 'fat-gallery'); ?></label>
                <input type="text" name="extra_title_link" value="<?php echo esc_attr($title_link); ?>"/>
            </p>
        <?php }
    }

    new FAT_Gallery();
}