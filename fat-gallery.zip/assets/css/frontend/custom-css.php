<style type='text/css'>
    .fat-gallery-tabs ul li a{
        font-size: <?php echo sprintf('%s',$fat_settings['category_font_size']) ?>px;
        color: <?php echo sprintf('%s',$fat_settings['category_text_color']) ?>;
        <?php if($fat_settings['category_style']!='bold'): ?>
            font-style: <?php echo sprintf('%s',$fat_settings['category_style']) ?>;
        <?php endif ?>
        <?php if($fat_settings['category_style']!='italic'): ?>
            font-weight: <?php echo sprintf('%s',$fat_settings['category_style']) ?>;
        <?php endif ?>
        text-transform: <?php echo sprintf('%s',$fat_settings['category_text_transform']) ?>;
    }
    .fat-gallery-tabs ul li a:hover,
    .fat-gallery-tabs ul li a.active{
        color: <?php echo sprintf('%s',$fat_settings['category_text_hover_color']) ?>;
        border-bottom: solid 1px <?php echo sprintf('%s',$fat_settings['category_text_hover_color']) ?>;
        border-top: solid 1px <?php echo sprintf('%s',$fat_settings['category_text_hover_color']) ?>;
    }

    .fat-gallery-icon i{
        color: <?php echo sprintf('%s',$fat_settings['icon_color']) ?>;
        font-size: <?php echo sprintf('%s',$fat_settings['icon_font_size']) ?>px;
    }
    .fat-gallery-icon a:hover i{
        color: <?php echo sprintf('%s',$fat_settings['icon_hover_color']) ?>;
    }
    .fat-gallery-title h5{
        font-size: <?php echo sprintf('%s',$fat_settings['title_font_size']) ?>px;
        color: <?php echo sprintf('%s',$fat_settings['title_text_color']) ?>;
        <?php if($fat_settings['title_style']!='bold'): ?>
            font-style: <?php echo sprintf('%s',$fat_settings['title_style']) ?>;
        <?php endif ?>
        <?php if($fat_settings['title_style']!='italic'): ?>
            font-weight: <?php echo sprintf('%s',$fat_settings['title_style']) ?>;
        <?php endif ?>
        text-transform: <?php echo sprintf('%s',$fat_settings['title_text_transform']) ?>;
    }
    .fat-gallery-excerpt{
        color: <?php echo sprintf('%s',$fat_settings['title_text_color']) ?>;
    }

    .fat-gallery-item .fat-hover-outer{
        background-color: <?php echo sprintf('%s',$fat_settings['bg_hover_color']) ?>;
    }
    .dg-wrapper a .gallery-3d-title{
        font-size: <?php echo sprintf('%s',$fat_settings['title_font_size']) ?>px;
        color: <?php echo sprintf('%s',$fat_settings['title_text_color']) ?>;
        font-style: <?php echo sprintf('%s',$fat_settings['title_style']) ?>;
        text-transform: <?php echo sprintf('%s',isset($fat_settings['gallery_3d_title_text_transform']) ? $fat_settings['gallery_3d_title_text_transform'] : 'normal') ?>;
    }
    #lg-counter{
        display: <?php echo isset($fat_settings['hide_image_counter']) && $fat_settings['hide_image_counter'] == '1' ? 'none' : 'block'; ?> !important;
    }
    #lg-actual-size{
        display: <?php echo isset($fat_settings['hide_actual_size']) && $fat_settings['hide_actual_size'] == '1' ? 'none' : 'block'; ?> !important;
    }
    #lg-zoom-in,
    #lg-zoom-out{
        display: <?php echo isset($fat_settings['hide_zoom_icon']) && $fat_settings['hide_zoom_icon'] == '1' ? 'none' : 'block'; ?> !important;
    }
    #lg-share{
        display: <?php echo isset($fat_settings['hide_share_icon']) && $fat_settings['hide_share_icon'] == '1' ? 'none' : 'block'; ?> !important;
    }
    .lg-fullscreen{
        display: <?php echo isset($fat_settings['hide_fullscreen']) && $fat_settings['hide_fullscreen'] == '1' ? 'none' : 'block'; ?> !important;
    }
    .lg-sub-html{
        display: <?php echo isset($fat_settings['hide_image_title']) && $fat_settings['hide_image_title'] == '1' ? 'none' : 'block'; ?> !important;
    }
    .lg-autoplay-button{
        display: <?php echo isset($fat_settings['hide_autoplay']) && $fat_settings['hide_autoplay'] == '1' ? 'none' : 'block'; ?> !important;
    }
    .lg-toolbar > .lg-icon{
        font-weight: <?php echo isset($fat_settings['bold_icon']) && $fat_settings['bold_icon'] == '1' ? 600 : 400; ?> !important;
    }
    <?php if(isset($fat_settings['display_social_icon_simple']) && $fat_settings['display_social_icon_simple'] =='1' ) { ?>
        #lg-share .lg-dropdown li .lg-icon,
        #lg-share .lg-dropdown .lg-dropdown-text{
            color: #000 !important;
        }
        #lg-share .lg-dropdown li a#lg-share-facebook .lg-icon:after{
            content: "\f09a" !important;
            font-family: FontAwesome !important;
        }
        #lg-share .lg-dropdown li a#lg-share-googleplus .lg-icon:after{
            content: "\f0d5" !important;
            font-family: FontAwesome !important;
        }
        #lg-share .lg-dropdown li a#lg-share-pinterest .lg-icon:after{
            content: "\f231" !important;
            font-family: FontAwesome !important;
        }
        #lg-share .lg-dropdown li a#lg-share-twitter .lg-icon:after{
            content: "\f099" !important;
            font-family: FontAwesome !important;
        }

    <?php } ?>
    <?php if(isset($fat_settings['custom_css']) && $fat_settings['custom_css']!='' ) { echo sprintf('%s',$fat_settings['custom_css']); } ?>

</style>



