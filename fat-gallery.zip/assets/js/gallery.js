/**
 * FatGallery - Version 1.4
 * Copyright 2016, RoninWP
 * http://roninwp.com
 */
"use strict";
var FatGallery = {
    htmlTag: {
        load_more: '.load-more'
    },
    vars: {
        ajax_url: '',
        dataSectionId: '',
        effect: 'magnificPopup',
        popup_transition: 'lg-slide',
        is_drag: false
    },
    registerImageDetailPopup: function ($wrap) {
        setTimeout(function () {
            jQuery('a:not(.link-to-album)', $wrap).off('click');
            jQuery('a', $wrap).removeData('magnificPopup');
            jQuery('a', $wrap).removeAttr('data-rel').off("click.fb-start");
            if (FatGallery.vars.effect == 'magnificPopup') {
                jQuery('a.magnific-popup:not(.video-iframe)', $wrap).each(function(){
                    var container = jQuery(this).closest('.fat-gallery');
                    if(container.hasClass('fat-slider')){
                        jQuery('.owl-item:not(.cloned) a.magnific-popup:not(.video-iframe)', $wrap).magnificPopup({
                            gallery: {
                                enabled: true
                            },
                            mainClass: 'mfp-fade'
                        });
                    }else{
                        jQuery('a.magnific-popup:not(.video-iframe)', $wrap).magnificPopup({
                            gallery: {
                                enabled: true
                            },
                            mainClass: 'mfp-fade'
                        });
                    }
                });

                jQuery('a.video-iframe').off('click').click(function (event) {
                    event.preventDefault();
                    var $items = [],
                        $current_iframe = jQuery(this).attr('data-iframe'),
                        $current_index = 0;
                    jQuery('a.video-iframe').each(function ($index) {
                        var $iframe = jQuery(this).attr('data-iframe');
                        if (typeof $iframe != 'undefined' && $iframe != '') {
                            $items.push({src: jQuery($iframe), type: 'inline'});
                            if ($current_iframe == $iframe) {
                                $current_index = $index;
                            }
                        }
                    });
                    if ($items.length > 0) {
                        jQuery.magnificPopup.open({
                            items: $items,
                            gallery: {
                                enabled: true
                            },
                            type: 'image',
                            mainClass: 'mfp-fade'
                        }, $current_index);

                    }

                });
            }

            if (FatGallery.vars.effect == 'light-gallery') {
                var $gallery = jQuery($wrap);
                if ($gallery.data('lightGallery')) {
                    $gallery.data('lightGallery').destroy(true);
                }

                jQuery('.fat-light-gallery .fat-gallery-icon a', $gallery).on('click', function (event) {
                    var $icon_gallery = jQuery(this),
                        $gallery_wrap = jQuery(this).closest('.fat-gallery-wrapper'),
                        $gallery_id = $icon_gallery.attr('data-gallery'),
                        $img = jQuery(this).attr('href'),
                        $index = 0,
                        $idx = 0,
                        $galleries = [],
                        $cat = jQuery('.fat-gallery-tabs li.active > a').attr('data-category'),
                        $selector = '.fat-gallery-icon a',
                        $wrap = jQuery(this).closest('.fat-gallery-wrapper'),
                        $download_icon = $wrap.attr('data-hide-download'),
                        $counter_icon = $wrap.attr('data-hide-image-counter'),
                        $fullscreen_icon = $wrap.attr('data-hide-fullscreen'),
                        $zoom_icon = $wrap.attr('data-hide-zoom'),
                        $share_icon = $wrap.attr('data-hide-share'),
                        $autoplay_icon = $wrap.attr('data-hide-autoplay');


                    event.preventDefault();
                    if (typeof $cat === 'undefined' || $cat.indexOf(',') < 1) {
                        $selector += '[data-gallery="' + $gallery_id + '"]';
                    }

                    var $extra_title_link = '', $subHtml = '', $title = '', $excerpt = '';
                    jQuery($selector,$gallery_wrap).each(function () {
                        $title = jQuery('h5', jQuery(this).closest('.fat-hover-inner')).text();
                        $extra_title_link = jQuery(this).attr('data-extra-title-link');
                        $excerpt = jQuery(this).attr('data-excerpt');
                        if (typeof $extra_title_link !== 'undefined' && $extra_title_link !== '') {
                            $subHtml = '<a href="' + $extra_title_link + '">' + $title + '</a>';
                        } else {
                            $subHtml = $title;
                        }
                        if (typeof $excerpt !== 'undefined' && $excerpt !== '') {
                            $subHtml += '<div>' + jQuery(this).attr('data-excerpt') + '</div>';
                        }

                        if (jQuery(this).attr('href') == $img) {
                            $index = $idx;
                        }
                        $idx++;
                        $galleries.push({
                            'src': jQuery(this).attr('href'),
                            'thumb': jQuery(this).attr('href'),
                            'subHtml': $subHtml
                        });
                    });

                    var enable_zoom_in = true;
                    var enable_zoom_out = false;
                    $icon_gallery.lightGallery({
                        downloadUrl: false,
                        dynamic: true,
                        dynamicEl: $galleries,
                        hideBarsDelay: 6000,
                        hash: false,
                        share: typeof $share_icon=='undefined' || $share_icon!='1',
                        zoom:  typeof $zoom_icon=='undefined' || $zoom_icon!='1',
                        actualSize: typeof $fullscreen_icon=='undefined' || $fullscreen_icon!='1',
                        index: $index,
                        counter: typeof $counter_icon=='undefined' || $counter_icon!='1',
                        download: typeof $download_icon=='undefined' || $download_icon!='1',
                        autoplay: typeof $autoplay_icon=='undefined' || $autoplay_icon!='1'
                    }).on('onAfterOpen.lg', function (event, index) {
                        jQuery('.lg-thumb-outer').css('opacity', '0');
                        setTimeout(function () {
                            jQuery('.lg-has-thumb').removeClass('lg-thumb-open');
                            jQuery('.lg-thumb-outer').css('opacity', '1');

                            FatGallery.zoomInOut();

                        }, 700);

                    }).on('onAfterSlide.lg', function (event, index) {
                        FatGallery.zoomInOut();
                    });
                    return false;
                });

                jQuery('.fat-light-gallery-compact .fat-gallery-icon a', $gallery).on('click', function (event) {
                    var $icon_gallery = jQuery(this),
                        $fat_gallery_item = $icon_gallery.closest('.fat-gallery-item'),
                        $galleries = [],
                        $wrap = jQuery(this).closest('.fat-gallery-wrapper'),
                        $download_icon = $wrap.attr('data-hide-download'),
                        $counter_icon = $wrap.attr('data-hide-image-counter'),
                        $fullscreen_icon = $wrap.attr('data-hide-fullscreen'),
                        $zoom_icon = $wrap.attr('data-hide-zoom'),
                        $share_icon = $wrap.attr('data-hide-share'),
                        $autoplay_icon = $wrap.attr('data-hide-autoplay');

                    event.preventDefault();

                    var $extra_title_link = '', $subHtml = '', $excerpt = '';
                    jQuery('.hide a', $fat_gallery_item).each(function () {
                        $extra_title_link = jQuery(this).attr('data-extra-title-link');
                        $excerpt = jQuery(this).attr('data-excerpt');
                        if (typeof $extra_title_link !== 'undefined' && $extra_title_link !== '') {
                            $subHtml = '<a href="' + $extra_title_link + '">' + jQuery(this).attr('title') + '</a>';
                        } else {
                            $subHtml = jQuery(this).attr('title');
                        }
                        if (typeof $excerpt !== 'undefined' && $excerpt !== '') {
                            $subHtml += '<div>' + jQuery(this).attr('data-excerpt') + '</div>';
                        }
                        $galleries.push({
                            'src': jQuery(this).attr('href'),
                            'thumb': jQuery(this).attr('href'),
                            'subHtml': $subHtml
                        });
                    });

                    if($galleries.length==0){
                        $galleries.push({
                            'src': jQuery(this).attr('href'),
                            'thumb': jQuery(this).attr('href'),
                            'subHtml': jQuery(this).attr('title')
                        });
                    }

                    var enable_zoom_in = true;
                    var enable_zoom_out = false;
                    $icon_gallery.lightGallery({
                        downloadUrl: false,
                        dynamic: true,
                        dynamicEl: $galleries,
                        hideBarsDelay: 6000,
                        hash: false,
                        share: typeof $share_icon=='undefined' || $share_icon!='1',
                        zoom:  typeof $zoom_icon=='undefined' || $zoom_icon!='1',
                        actualSize: typeof $fullscreen_icon=='undefined' || $fullscreen_icon!='1',
                        counter: typeof $counter_icon=='undefined' || $counter_icon!='1',
                        download: typeof $download_icon=='undefined' || $download_icon!='1',
                        autoplay: typeof $autoplay_icon=='undefined' || $autoplay_icon!='1'
                    }).on('onAfterOpen.lg', function (event, index) {
                        jQuery('.lg-thumb-outer').css('opacity', '0');
                        setTimeout(function () {
                            jQuery('.lg-has-thumb').removeClass('lg-thumb-open');
                            jQuery('.lg-thumb-outer').css('opacity', '1');

                            FatGallery.zoomInOut();

                        }, 700);

                    }).on('onAfterSlide.lg', function (event, index) {
                        FatGallery.zoomInOut();
                    });
                    return false;
                });

                if(jQuery($gallery).hasClass('album-item')){
                    var $lg_album = jQuery($gallery).lightGallery({
                        mode: FatGallery.vars.popup_transition,
                        selector: '.fat-light-gallery',
                        share: true,
                        download: true
                    });
                    $lg_album.on('onAfterOpen.lg', function (event, index) {
                        jQuery('.lg-thumb-outer').css('opacity', '0');
                        setTimeout(function () {
                            jQuery('.lg-has-thumb').removeClass('lg-thumb-open');
                            jQuery('.lg-thumb-outer').css('opacity', '1');
                        }, 700);

                    });

                }

                /** album */
                jQuery('.fat-gallery.album, .fat-gallery-justified').lightGallery({
                    mode: FatGallery.vars.popup_transition,
                    selector: '.fat-light-gallery',
                    share: true,
                    download: true
                }).on('onAfterOpen.lg', function (event, index) {
                    jQuery('.lg-thumb-outer').css('opacity', '0');
                    setTimeout(function () {
                        jQuery('.lg-has-thumb').removeClass('lg-thumb-open');
                        jQuery('.lg-thumb-outer').css('opacity', '1');
                    }, 700);

                });
                /* jQuery('.fat-light-gallery-compact', $gallery).each(function () {
                 var $gallery_id = jQuery(this).attr('data-gallery');
                 jQuery(this).lightGallery({
                 mode: FatGallery.vars.popup_transition,
                 selector: ('.gallery-' + $gallery_id),
                 exThumbImage:  'data-exthumbimage',
                 share: true
                 });
                 });*/

            }
            if (FatGallery.vars.effect == 'codoEffect') {
                if (window.hasOwnProperty('GridFx')) {
                    var support = {transitions: Modernizr.csstransitions};
                    // transition end event name
                    var transEndEventNames = {
                        'WebkitTransition': 'webkitTransitionEnd',
                        'MozTransition': 'transitionend',
                        'OTransition': 'oTransitionEnd',
                        'msTransition': 'MSTransitionEnd',
                        'transition': 'transitionend'
                    };
                    var transEndEventName = transEndEventNames[Modernizr.prefixed('transition')];
                    var onEndTransition = function (el, callback) {
                        var onEndCallbackFn = function (ev) {
                            if (support.transitions) {
                                if (ev.target != this) return;
                                this.removeEventListener(transEndEventName, onEndCallbackFn);
                            }
                            if (callback && typeof callback === 'function') {
                                callback.call(this);
                            }
                        };
                        if (support.transitions) {
                            el.addEventListener(transEndEventName, onEndCallbackFn);
                        }
                        else {
                            onEndCallbackFn();
                        }
                    };
                    new GridFx(document.querySelector('#fat-gallery-container-' + $wrap.attr('data-section-id')), $wrap.attr('data-section-id'), {
                        imgPosition: {
                            x: -0.5,
                            y: 1
                        },
                        onOpenItem: function (instance, item) {
                            instance.items.forEach(function (el) {
                                if (item != el) {
                                    var delay = Math.floor(Math.random() * 50);
                                    el.style.WebkitTransition = 'opacity .5s ' + delay + 'ms cubic-bezier(.7,0,.3,1), -webkit-transform .5s ' + delay + 'ms cubic-bezier(.7,0,.3,1)';
                                    el.style.transition = 'opacity .5s ' + delay + 'ms cubic-bezier(.7,0,.3,1), transform .5s ' + delay + 'ms cubic-bezier(.7,0,.3,1)';
                                    el.style.WebkitTransform = 'scale3d(0.1,0.1,1)';
                                    el.style.transform = 'scale3d(0.1,0.1,1)';
                                    el.style.opacity = 0;
                                }
                            });
                        },
                        onCloseItem: function (instance, item) {
                            instance.items.forEach(function (el) {
                                if (item != el) {
                                    el.style.WebkitTransition = 'opacity .4s, -webkit-transform .4s';
                                    el.style.transition = 'opacity .4s, transform .4s';
                                    el.style.WebkitTransform = 'scale3d(1,1,1)';
                                    el.style.transform = 'scale3d(1,1,1)';
                                    el.style.opacity = 1;

                                    onEndTransition(el, function () {
                                        el.style.transition = 'none';
                                        el.style.WebkitTransform = 'none';
                                    });
                                }
                            });
                        }
                    });
                }
            }

            jQuery('.fat-thumbnail a.fat-image-clickable').off('click').on('click', function () {
                var $thumb = jQuery(this).closest('.fat-thumbnail'),
                    $linkViewGallery = jQuery('.fat-gallery-icon > a', $thumb);
                FatGallery.registerImageDetailPopup($wrap);
                setTimeout(function(){
                    if (typeof $linkViewGallery != 'undefined') {
                        $linkViewGallery.click();
                    }
                },500);
            });

        }, 500);
    },

    zoomInOut: function () {
        jQuery('.lg-outer .lg-item .lg-image').off('click').on('click', function () {
            var zoomIn = jQuery('#lg-zoom-in'),
                zoomOut = jQuery('#lg-zoom-out'),
                lgOuter = jQuery(this).closest('.lg-outer');

            if (jQuery('body').hasClass('fat-gallery-zoom')) {
                if (typeof lgOuter != 'undefined') {
                    if (lgOuter.hasClass('lg-zoomed') && !lgOuter.hasClass('has-event-zoom-dragging')) {
                        if (typeof zoomOut !== 'undefined') {
                            zoomOut.trigger('click');
                            jQuery(this).off('dblclick');
                        }
                    } else {
                        if (typeof zoomIn !== 'undefined' && !lgOuter.hasClass('has-event-zoom-dragging')) {
                            zoomIn.trigger('click');
                            jQuery(this).off('dblclick');
                        }
                    }
                }
            }
        });
    },

    processFilter: function (elm) {
        var $this = jQuery(elm);
        var category = $this.attr('data-category');
        var $filterType = $this.attr('data-load-type');
        var $filter = $this.attr('data-filter');
        var $layout_type = $this.attr('data-layout-type');
        var $animation_filter = $this.attr('data-animation-filter');
        var $fat_gallery_cointainer = $this.closest('.fat-gallery');
        var $container = jQuery('.fat-gallery-wrapper', $fat_gallery_cointainer),
            $section_id = $container.attr('data-section-id');

        $animation_filter = typeof $animation_filter != 'undefined' && $animation_filter != null ? $animation_filter : '';

        if($this.closest('.category-two-level').length>0){
            var $tab_container = $this.closest('.fat-gallery-tabs');
            jQuery('ul.fat-cat-level-two li a.active',$tab_container).removeClass('active');
            jQuery('ul.fat-cat-level-two',$tab_container).fadeOut(function(){
                jQuery('ul.fat-cat-level-two li',$tab_container).each(function(){
                    if(jQuery(this).attr('data-parent') ==category || category.split(',').length > 1){
                        jQuery(this).show();
                    }else{
                        jQuery(this).hide();
                    }
                });
                jQuery('ul.fat-cat-level-two',$tab_container).fadeIn();
            })

        }

        jQuery('.fat-gallery-tab-desc li.active',$fat_gallery_cointainer).removeClass('active');
        if($filter!='*'){
            jQuery('.fat-gallery-tab-desc li.' + category ,$fat_gallery_cointainer).addClass('active');
        }

        if ($filterType == 'ajax') {
            jQuery('a.active', jQuery(elm).parent().parent()).removeClass('active');
            jQuery('li.active', jQuery(elm).parent().parent()).removeClass('active');
            jQuery($this).parent().addClass('active');
            jQuery($this).addClass('active');
            var $lada = null;
            if ($this.is('a')) {
                $lada = Ladda.create(elm);
                if (typeof $lada != 'undefined' && $lada != null)
                    $lada.start();
            }

            jQuery('.preview-codo-effect img', '#fat-gallery-' + FatGallery.vars.dataSectionId).remove();

            FatGallery.getMore(elm, function ($data) {
                if ($data != null) {
                    var $items = jQuery('.fat-gallery-item', $data);
                    $items.imagesLoaded(function(){
                        $container.fadeOut(function () {
                            if ($layout_type == 'masonry') {
                                jQuery('.fat-gallery-item', $container).each(function () {
                                    $container.isotope('remove', jQuery(this));
                                });
                            } else {
                                $container.empty();
                            }

                            $items.css('transition', 'opacity 1.5s linear, transform 1s');
                            $items.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
                            $items.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
                            $items.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
                            $items.css('-o-transition', 'opacity 1.5s linear, transform 1s');
                            if ($animation_filter == '1') {
                                $items.css('transform', 'scale(0.2)');
                                $items.css('-ms-transform', 'scale(0.2)');
                                $items.css('-webkit-transform', 'scale(0.2)');
                            }
                            $items.css('opacity', 0);

                            $container.append($items);
                            jQuery('#load-more-' + FatGallery.vars.dataSectionId).empty();
                            $container.fadeIn(function () {
                                if ($layout_type == 'masonry') {
                                    $container.isotope('insert', $items);
                                }

                                if ($animation_filter == '1') {
                                    for (var $i = 0; $i < $items.length; $i++) {
                                        (function ($index) {
                                            var $delay = 150 * $i;
                                            setTimeout(function () {
                                                jQuery($items[$index]).css('transform', 'scale(1)');
                                                jQuery($items[$index]).css('-ms-transform', 'scale(1)');
                                                jQuery($items[$index]).css('-webkit-transform', 'scale(1)');
                                                jQuery($items[$index]).css('opacity', 1);
                                                /*if ($index == ($items.length - 1)) {
                                                 FatGallery.processShowLoadingButton($data);
                                                 }*/
                                            }, $delay);
                                        })($i);
                                    }
                                } else {
                                    jQuery($items).css('opacity', 1);
                                    FatGallery.processShowLoadingButton($section_id, $data);
                                }

                            });
                            jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();

                            FatGallery.processShowLoadingButton($section_id, $data);
                            FatGallery.registerImageDetailPopup($container);
                            if (typeof $lada != 'undefined' && $lada != null)
                                $lada.stop();
                        });
                    });
                }
            });
        } else {
            if (jQuery.isFunction(jQuery.fn.isotope)) {
                $container.isotope({filter: $filter}).isotope(
                    {
                        sortBy : 'original-order'
                    }
                );
            }
            jQuery('a.active', jQuery(elm).parent().parent()).removeClass('active');
            jQuery('li.active', jQuery(elm).parent().parent()).removeClass('active');
            jQuery($this).parent().addClass('active');
            jQuery($this).addClass('active');
        }
        FatGallery.registerFilterByCategory();
    },

    processFilterAlbum: function (elm, $container) {
        var $this = jQuery(elm),
            $filter = $this.attr('data-filter');
        if (jQuery.isFunction(jQuery.fn.isotope)) {
            $container.isotope({filter: $filter});
        }
        jQuery('a.active', jQuery(elm).parent().parent()).removeClass('active');
        jQuery('li.active', jQuery(elm).parent().parent()).removeClass('active');
        jQuery($this).parent().addClass('active');
        jQuery($this).addClass('active');
    },

    processFilterJustified: function (elm, sectionId) {
        var $this = jQuery(elm),
            $container = jQuery('#fat-gallery-container-' + sectionId),
            $rowHeight = $this.attr('data-row-height'),
            $margin = $this.attr('data-margin');
        jQuery('a.active', jQuery(elm).parent().parent()).removeClass('active');
        jQuery('li.active', jQuery(elm).parent().parent()).removeClass('active');
        jQuery($this).parent().addClass('active');
        jQuery($this).addClass('active');
        var $lada = null;
        if ($this.is('a')) {
            $lada = Ladda.create(elm);
            if (typeof $lada != 'undefined' && $lada != null)
                $lada.start();
        }
        FatGallery.getMoreJustified(elm, function ($data) {
            if ($data != null) {
                var $items = jQuery('.fat-gallery-item', $data);
                $container.fadeOut(function () {
                    $container.empty();
                    try {
                        $container.justifiedGallery('destroy');
                    } catch (err) {
                    }

                    $items.css('transition', 'opacity 1.5s linear, transform 1s');
                    $items.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
                    $items.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
                    $items.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
                    $items.css('-o-transition', 'opacity 1.5s linear, transform 1s');
                    $items.css('opacity', 0);

                    $container.append($items);
                    jQuery('#load-more-' + sectionId).empty();

                    if (jQuery('.paging', $data).length > 0) {
                        var $loadButton = jQuery('.paging a', $data);
                        $loadButton.attr('data-section-id', sectionId);
                        jQuery('#load-more-' + sectionId).append($loadButton);
                        FatGallery.registerLoadmoreJustified(sectionId);
                    }
                    $container.fadeIn(function () {
                        $container.justifiedGallery({
                            rowHeight: $rowHeight,
                            margins: $margin,
                            captions: false,
                            selector: '> div.fat-gallery-item:not(.fat-lazy-load)'
                        });
                        FatGallery.registerImageDetailPopup($container);
                    });

                    if (typeof $lada != 'undefined' && $lada != null)
                        $lada.stop();
                });

            }
        });
    },

    processLoadMore: function (elm) {
        var $this = jQuery(elm);
        var $animation_filter = $this.attr('data-animation-filter');
        var $layout_type = $this.attr('data-layout-type');
        var $filter_type = $this.attr('data-filter-type');
        var $show_category = $this.attr('data-show-category');
        var $fat_gallery_cointainer = $this.closest('.fat-gallery');
        var $container = jQuery('.fat-gallery-wrapper', $fat_gallery_cointainer),
            $section_id = $container.attr('data-section-id');

        $animation_filter = typeof $animation_filter != 'undefined' && $animation_filter != null ? $animation_filter : '';
        var l = Ladda.create(elm);
        l.start();
        jQuery('.preview-codo-effect img', '#fat-gallery-' + FatGallery.vars.dataSectionId).remove();
        FatGallery.getMore(elm, function ($data) {
            if ($data != null) {
                var $items = jQuery('.fat-gallery-item', $data);
                if ($layout_type == 'masonry' || ($filter_type == 'isotope' && $show_category != '')) {
                    FatGallery.processAppendItemsIsotope($items, $container, $animation_filter);
                } else {
                    FatGallery.processAppendItemsAjax($items, $container, $animation_filter);
                }
                l.stop();
                jQuery('#load-more-' + FatGallery.vars.dataSectionId).empty();
                FatGallery.processShowLoadingButton($section_id,$data);
            }
        });
    },

    processAppendItemsIsotope: function ($items, $container, $animation_filter) {
        $items.css('transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-o-transition', 'opacity 1.5s linear, transform 1s');
        if ($animation_filter == '1') {
            $items.css('transform', 'scale(0.2)');
            $items.css('-ms-transform', 'scale(0.2)');
            $items.css('-webkit-transform', 'scale(0.2)');
        }
        $items.css('opacity', 0);
        var $delay = 0;

        $container.append($items);
        $container.imagesLoaded(function(){
            $container.isotope('insert', $items);

            if ($animation_filter == '1') {
                for (var $i = 0; $i < $items.length; $i++) {
                    (function ($index) {
                        var $delay = 150 * $i;
                        setTimeout(function () {
                            jQuery($items[$index]).css('transform', 'scale(1)');
                            jQuery($items[$index]).css('-ms-transform', 'scale(1)');
                            jQuery($items[$index]).css('-webkit-transform', 'scale(1)');
                            jQuery($items[$index]).css('opacity', 1);
                            jQuery('div.fat-thumbnail', $items[$index]).hoverdir();


                        }, $delay);
                    })($i);
                }
                FatGallery.registerImageDetailPopup($container);
            } else {
                $items.css('opacity', 1);
                // $container.isotope('insert', $items);
                jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();
            }
        });

    },

    processAppendItemsAjax: function ($items, $container, $animation_filter) {
        $items.css('transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('-o-transition', 'opacity 1.5s linear, transform 1s');
        $items.css('opacity', 0);
        if ($animation_filter == '1') {
            $items.css('transform', 'scale(0.2)');
            $items.css('-ms-transform', 'scale(0.2)');
            $items.css('-webkit-transform', 'scale(0.2)');
        }
        $container.append($items);
        var $delay = 0;
        $container.imagesLoaded(function(){
            if ($animation_filter == '1') {
                for (var $i = 0; $i < $items.length; $i++) {
                    (function ($index) {
                        $delay = 200 * $i;
                        setTimeout(function () {
                            jQuery($items[$index]).css('opacity', 1);
                            jQuery($items[$index]).css('transform', 'scale(1)');
                            jQuery($items[$index]).css('-ms-transform', 'scale(1)');
                            jQuery($items[$index]).css('-webkit-transform', 'scale(1)');
                        }, $delay);
                    })($i);
                }
            } else {
                $items.css('opacity', 1);
            }
            jQuery('.fat-gallery-item.hover-dir > div.fat-thumbnail').hoverdir();
            FatGallery.registerImageDetailPopup($container);
        })
    },

    processShowLoadingButton: function ($section_id, $data) {
        jQuery('#load-more-' + $section_id).empty();
        if (jQuery('.paging', $data).length > 0) {
            var $loadButton = jQuery('.paging a', $data);
            $loadButton.attr('data-section-id', $section_id);
            jQuery('#load-more-' + $section_id).append($loadButton);
            FatGallery.registerLoadmore($section_id);
        }
    },

    processLoadMoreFull: function (elm) {
        var $this = jQuery(elm);
        var $sectionId = $this.attr('data-section-id');
        var $filterType = $this.attr('data-filter-type');
        var $layout = $this.attr('data-layout-type');
        var $current_page = parseInt($this.attr('data-current-page'));
        var $total_page = parseInt($this.attr('data-total-page'));
        var $post_per_page = parseInt($this.attr('data-post-per-page'));
        var $fromItemIndex = ($current_page - 1 ) * $post_per_page;
        var $toItemIndex = $current_page * $post_per_page;
        var $container = jQuery('#fat-gallery-container-' + $sectionId);

        var $itemIndex = 0;
        var $divThumbnail = null;
        var $delay = 150;
        jQuery('div.fat-lazy-load.fat-gallery-item', $container).each(function () {
            $itemIndex = jQuery(this).attr('data-index');
            if (typeof $itemIndex != undefined) {
                $itemIndex = parseInt($itemIndex);
                if ($itemIndex > $fromItemIndex && $itemIndex <= $toItemIndex) {
                    jQuery(this).css('opacity', 0);
                    jQuery(this).css('transition', 'opacity 1.5s linear, transform 1s');
                    jQuery(this).css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
                    jQuery(this).css('-moz-transition', 'opacity 1.5s linear, transform 1s');
                    jQuery(this).css('-ms-transition', 'opacity 1.5s linear, transform 1s');
                    jQuery(this).css('-o-transition', 'opacity 1.5s linear, transform 1s');

                    jQuery(this).css('transform', 'scale(0.2)');
                    jQuery(this).css('-ms-transform', 'scale(0.2)');
                    jQuery(this).css('-webkit-transform', 'scale(0.2)');

                    jQuery(this).removeClass('fat-lazy-load').addClass('fat-light-gallery');
                    $divThumbnail = jQuery('div.fat-thumbnail', this);
                    if (typeof $divThumbnail != 'undefined' && $divThumbnail.length > 0) {
                        $divThumbnail.prepend('<img src="' + $divThumbnail.attr('data-lazy-src') + '" width="' +
                            $divThumbnail.attr('data-width') + '" height="' + $divThumbnail.attr('data-height') + '" alt="' + $divThumbnail.attr('data-alt') + '"></img>');
                    }
                    (function ($item) {
                        $item.imagesLoaded(function(){
                            $delay += 150;
                            setTimeout(function () {
                                if ($filterType == 'isotope' || $layout=='masonry') {
                                    $container.isotope('layout');
                                }
                                $item.css('transform', 'scale(1)');
                                $item.css('-ms-transform', 'scale(1)');
                                $item.css('-webkit-transform', 'scale(1)');
                                $item.css('opacity', 1);
                            }, $delay);
                        });

                    })(jQuery(this));
                }
            }
        });
        FatGallery.registerImageDetailPopup($container);

        if (($current_page + 1) > $total_page) {
            $this.remove();
        } else {
            $current_page = $current_page + 1;
            $this.attr('data-current-page', $current_page);
        }
    },

    getMore: function (elm, callback) {
        var $this = jQuery(elm);
        var $filterType = $this.attr('data-load-type');
        var $overlay_style = $this.attr('data-overlay-style');
        var $bg_color = $this.attr('data-bg-color');
        var $title_style = $this.attr('data-title-style');
        var $section_id = $this.attr('data-section-id');
        var $data_source = $this.attr('data-source');
        var $data_GalleryIds = $this.attr('data-gallery-ids');
        var $data_show_paging = $this.attr('data-show-paging');
        var $current_page = $this.attr('data-current-page');
        var $category = $this.attr('data-category');
        var $offset = 0;
        var $post_per_page = $this.attr('data-post-per-page');
        var $column = $this.attr('data-column');
        var $padding = $this.attr('data-padding');
        var $order_by = $this.attr('data-order-by');
        var $order = $this.attr('data-order');
        var $layout_type = $this.attr('data-layout-type');
        var $display_type = $this.attr('data-display-type');
        var $imageSize = $this.attr('data-image-size');
        var $animation_filter = $this.attr('data-animation-filter');
        var $detail_effect = $this.attr('data-effect');

        $category = typeof $category != 'undefined' && $category != null ? $category : '';
        $data_GalleryIds = typeof $data_GalleryIds != 'undefined' && $data_GalleryIds != null ? $data_GalleryIds : '';
        $animation_filter = typeof $animation_filter != 'undefined' && $animation_filter != null ? $animation_filter : '';

        jQuery.ajax({
            url: FatGallery.vars.ajax_url,
            data: ({
                action: 'roninwp_gallery_load_by_category', postsPerPage: $post_per_page, current_page: $current_page,
                layoutType: $layout_type, category: $category, animationFilter: $animation_filter,
                columns: $column, colPadding: $padding, offset: $offset, order: $order, order_by: $order_by,
                data_source: $data_source, galleryIds: $data_GalleryIds, data_show_paging: $data_show_paging,
                overlay_style: $overlay_style, bgColor: $bg_color, titleStyle: $title_style, imageSize: $imageSize,
                displayType: $display_type, detailEffect: $detail_effect
            }),
            success: function (data) {
                if (callback) {
                    callback(data);
                }
            },
            error: function () {
                return null;
            }
        });

    },

    getMoreJustified: function (elm, callback) {

        var $this = jQuery(elm);
        var $data_source = $this.attr('data-source'),
            $category = $this.attr('data-category'),
            $data_GalleryIds = $this.attr('data-gallery-ids'),
            $rowHeight = $this.attr('data-row-height'),
            $item = $this.attr('data-item'),
            $order = $this.attr('data-order'),
            $margin = $this.attr('data-margin'),
            $bg_color = $this.attr('data-bg-color'),
            $show_pagging = $this.attr('data-show-paging'),
            $title_style = $this.attr('data-title-style');

        $category = typeof $category != 'undefined' && $category != null ? $category : '';
        $data_GalleryIds = typeof $data_GalleryIds != 'undefined' && $data_GalleryIds != null ? $data_GalleryIds : '';

        jQuery.ajax({
            url: FatGallery.vars.ajax_url,
            data: ({
                action: 'roninwp_gallery_justified_load_by_category',
                category: $category,
                margin: $margin,
                order: $order,
                data_source: $data_source,
                galleryIds: $data_GalleryIds,
                bgColor: $bg_color,
                titleStyle: $title_style,
                rowHeight: $rowHeight,
                item: $item,
                showPagging: $show_pagging
            }),
            success: function (data) {
                if (callback) {
                    callback(data);
                }
            },
            error: function () {
                return null;
            }
        });
    },

    registerFilterByCategory: function () {

        jQuery('li', '.fat-gallery .fat-gallery-tabs').each(function () {
            jQuery('a', jQuery(this)).off();
            jQuery('a', jQuery(this)).click(function () {
                jQuery('a', '.fat-gallery .fat-gallery-tabs').off();
                FatGallery.processFilter(this);
            });
        });

        jQuery('select', '.fat-gallery .fat-gallery-tabs').off();
        jQuery('select', '.fat-gallery .fat-gallery-tabs').change(function () {
            var $item = jQuery("option:selected", this);
            FatGallery.processFilter($item);
        });

    },

    registerFilterAlbum: function ($container) {

        jQuery('li', '.fat-gallery.album .fat-gallery-tabs').each(function () {
            jQuery('a', jQuery(this)).click(function () {
                FatGallery.processFilterAlbum(this, $container);
            });
        });
        jQuery('select', '.fat-gallery.album .fat-gallery-tabs').change(function () {
            var $item = jQuery("option:selected", this);
            FatGallery.processFilterAlbum($item, $container);
        });


    },

    registerFilterJustifiedByCategory: function () {
        var sectionId = '';
        jQuery('li', '.fat-gallery-justified-wrap .fat-gallery-tabs').each(function () {
            jQuery('a', jQuery(this)).off();
            jQuery('a', jQuery(this)).click(function () {
                jQuery('a', '.fat-gallery .fat-gallery-tabs').off();
                sectionId = jQuery(this).attr('data-section-id');
                FatGallery.processFilterJustified(this, sectionId);
            });
        });

        jQuery('select', '.fat-gallery-justified-wrap .fat-gallery-tabs').off();
        jQuery('select', '.fat-gallery-justified-wrap .fat-gallery-tabs').change(function () {
            FatGallery.processFilterJustified(this, sectionId);
        });
    },

    registerLoadmore: function ($section_id) {
        jQuery('a', '#load-more-' + $section_id).off();
        jQuery('a', '#load-more-' + $section_id).click(function () {
            if (jQuery(this).hasClass('full') && jQuery(this).hasClass('load-more')) {
                FatGallery.processLoadMoreFull(this);
            } else {
                FatGallery.processLoadMore(this);
            }

        });
    },

    registerLoadmoreJustified: function ($sectionId) {
        jQuery('a', '#load-more-' + $sectionId).off().click(function () {
            var $this = jQuery(this);

            var $post_per_page = parseInt($this.attr('data-post-per-page')),
                $total_post = parseInt($this.attr('data-total-post')),
                $current_page = parseInt($this.attr('data-current-page')),
                $container = jQuery('#fat-gallery-container-' + $sectionId),
                $item = null;
            var $delay = 100;
            jQuery('.fat-lazy-load', $container).each(function (index) {
                $item = jQuery(this);
                if (index < $post_per_page) {
                    $item.css('transition', 'opacity 1.5s linear, transform 1s');
                    $item.css('-webkit-transition', 'opacity 1.5s linear, transform 1s');
                    $item.css('-moz-transition', 'opacity 1.5s linear, transform 1s');
                    $item.css('-ms-transition', 'opacity 1.5s linear, transform 1s');
                    $item.css('-o-transition', 'opacity 1.5s linear, transform 1s');
                    $item.removeClass('fat-lazy-load').addClass('fat-light-gallery');

                    $item.prepend('<img src="' + $item.attr('data-lazy-src') + '" alt="' + $this.attr('data-alt') + '"></img>');
                    (function ($item, $sectionId) {
                        $delay += 100;
                        setTimeout(function () {
                            $item.css('opacity', '1 !important');
                            jQuery('#fat-gallery-container-' + $sectionId).justifiedGallery('norewind');
                        }, $delay);
                    })(jQuery(this), $sectionId);


                }
            });
            FatGallery.registerImageDetailPopup('#fat-gallery-container-' + $sectionId);
            if (($post_per_page * $current_page ) > $total_post) {
                $this.remove();
            } else {
                $current_page = $current_page + 1;
                $this.attr('data-current-page', $current_page);
            }

        })
    },

    init: function (ajax_url, sectionid, effect, popup_transition) {
        FatGallery.vars.dataSectionId = sectionid;
        FatGallery.vars.effect = effect;
        FatGallery.vars.popup_transition = popup_transition;
        FatGallery.vars.ajax_url = ajax_url;
        FatGallery.registerFilterByCategory();
        FatGallery.registerLoadmore(sectionid);
        var $wrap = jQuery('#fat-gallery-container-' + sectionid);
        FatGallery.registerImageDetailPopup($wrap);

        jQuery('a', '.vc_tta-tabs ul.vc_tta-tabs-list').on('click', function () {
            var $data_content_id = jQuery(this).attr('href');
            setTimeout(function () {
                jQuery('.fat-gallery-wrapper.masonry', $data_content_id).isotope('layout');
            }, 300);
        });

        setTimeout(function(){
            var catFilter = FatGallery.getUrlVars();
            if(catFilter['cat']){
                jQuery('.fat-gallery-tabs li a[data-category="' + catFilter['cat'] + '"]').trigger('click');
            }
        },300)
    },

    initCarousel: function (sectionid, effect, auto_play, loop, margin, center, nav, dots, items) {
        FatGallery.vars.dataSectionId = sectionid;
        FatGallery.vars.effect = effect;
        var $wrap = jQuery('#fat-gallery-container-' + sectionid);
        FatGallery.registerImageDetailPopup($wrap);
        var $item = typeof items != 'undefined' && items > 0 ? items : 4;
        var $margin = typeof margin != 'undefined' && margin >= 0 ? margin : 0;
        var $auto_play = typeof auto_play != 'undefined' && auto_play != null ? auto_play : false;
        var $nav = typeof nav != 'undefined' && nav != null ? nav : false;
        var $navText = ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'];
        var $dots = typeof dots != 'undefined' && dots != null ? dots : false;
        var $center = typeof center != 'undefined' && center != null ? center : false;
        var $loop = typeof loop != 'undefined' && loop != null ? loop : false;
        var $responsive = {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            768: {
                items: 3
            },
            992: {
                items: $item,
                nav: $nav
            }
        };
        if ($item <= 2) {
            $responsive[600] = {items: $item};
            $responsive[768] = {items: $item}
        }
        var $options = {
            autoplay: $auto_play,
            autoplayTimeout: 3000,
            center: $center,
            autoHeight: true,
            loop: $loop,
            nav: $nav,
            navText: $navText,
            dots: $dots,
            items: $item,
            margin: $margin,
            responsive: $responsive
        };
        jQuery(".slider-wrapper", $wrap).imagesLoaded(function(){
            jQuery(".slider-wrapper", $wrap).owlCarousel($options);
            jQuery($wrap).css('opacity', '1');
        });
    },

    initGalleria: function (sectionid, $width, $height) {
        if ($width == '') {
            $width = '100%';
        }
        if ($height == '') {
            $height = jQuery(window).height();
        }
        jQuery('#fat-gallery-container-' + sectionid).css('height', $height);
        jQuery('#fat-gallery-container-' + sectionid).css('width', $width);
        Galleria.run('#fat-gallery-container-' + sectionid);
    },

    initAlbum: function (sectionid, effect, popup_transition) {
        FatGallery.vars.dataSectionId = sectionid;
        FatGallery.vars.effect = effect;
        FatGallery.vars.popup_transition = popup_transition;
        var $wrap = jQuery('.fat-gallery-item .inner', '#fat-gallery-container-' + sectionid);
        var $container = jQuery('#fat-gallery-container-' + sectionid);
        $container.imagesLoaded(function () {
            $container.isotope({
                itemSelector: '.fat-gallery-item'
            }).isotope('layout')
        });
        FatGallery.registerImageDetailPopup($wrap);
        FatGallery.registerFilterAlbum($container);
    },

    initJustified: function (ajax_url, sectionid, rowHeight, margin) {
        FatGallery.vars.ajax_url = ajax_url;
        FatGallery.vars.dataSectionId = sectionid;
        FatGallery.vars.effect = 'light-gallery';
        var $wrap = jQuery('#fat-gallery-container-' + sectionid);
        FatGallery.registerImageDetailPopup($wrap);
        var $row_height = isNaN(rowHeight) ? '120' : rowHeight;
        var $margin = isNaN(margin) ? '0' : margin;

        jQuery($wrap).justifiedGallery({
            rowHeight: $row_height,
            margins: $margin,
            captions: false,
            selector: '> div.fat-gallery-item:not(.fat-lazy-load)'
        }).on('jg.complete', function (e) {
            jQuery($wrap).addClass('justified-completed');
        });
        FatGallery.registerLoadmoreJustified(sectionid);
        FatGallery.registerFilterJustifiedByCategory();
    },

    getUrlVars: function(){
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for(var i = 0; i < hashes.length; i++)
        {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }
};

jQuery(window).on('load', function () {
    setTimeout(function () {
        jQuery('.fat-thumbnail > a.gdlr-core-ilightbox').attr('href', 'javascript:void(0)');
        jQuery('.fat-thumbnail > a.gdlr-core-ilightbox').off('click').on('click', function (event) {
            event.preventDefault();
            return false;
        });
    }, 500);

    jQuery('a[data-toggle]', '.fusion-accordian').on('click', function () {
        var $container = jQuery(this).closest('.fusion-accordian'),
            $fat_gallery = jQuery('.fat-gallery', $container),
            $fat_gallery_wrapper = jQuery('.fat-gallery-wrapper', $container);

        if($fat_gallery.hasClass('has-reinit-toggle')){
            return;
        }
        setTimeout(function () {
            if ($fat_gallery_wrapper.hasClass('masonry')) {
                if (jQuery($fat_gallery).data('isotope')) {
                    jQuery($fat_gallery).isotope('destroy');
                }
                jQuery($fat_gallery).isotope({
                    itemSelector: '.fat-gallery-item'
                }).isotope({filter: '*'});
                jQuery($fat_gallery).addClass('has-reinit-toggle');
            }
        }, 500);
    });

});
/*jQuery(document).on({
 "contextmenu": function (e) {
 // Stop the context menu
 e.preventDefault();
 }
 });*/
