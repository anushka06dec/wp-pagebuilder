(function ($) {
    "use strict";
    $(document).ready(function () {
        var $setting_form_class = '.fat-gallery-setting';
        //register tab change
        $('a', '.fat-gallery-setting .tab-settings-nav').click(function () {
            var $liWrap = $(this).parent();
            if ($liWrap.hasClass('active')) {
                return;
            }
            $('li', $setting_form_class).removeClass('active');
            var tabId = $(this).attr('data-tab');
            var tab = $('#' + tabId, $setting_form_class);

            $('.tab-setting.active', $setting_form_class).fadeOut(300, function () {
                $(this).removeClass('active');
                $liWrap.addClass('active');
                tab.fadeIn(300, function () {
                    tab.addClass('active');
                });
            });
        });

        function rangesSliderValueOutput(element) {
            var value = element.value;
            var outputId = $(element).attr('data-output-id');
            $('#' + outputId).val(value);
        }

        //register ranger slide
        $('input[type="range"]').rangeslider({
            polyfill: false,
            onInit: function () {
                rangesSliderValueOutput(this.$element[0]);
            },
            onSlide: function (position, value) {
                rangesSliderValueOutput(this.$element[0]);
            },
        });
        $('input[type="number"]').change(function () {
            var rangeId = $(this).attr('data-range-id');
            if (typeof rangeId != ' undefined' && rangeId != '') {
                var value = $(this).val();
                $('#' + rangeId).val(value).change();
            }
        });

        //register color picker
        $('.colorpicker-element').colorpicker();

        //register select 2
        /*$('.select2', '.fat-gallery-setting').select2();*/

        //register dependence
        $('.dependence').each(function () {
            fat_gallery_dependence($(this));
        });
        $('.dependence').change(function () {
            fat_gallery_dependence($(this));
        });

        //register button shortcode generate
        $('input.bt-sc-fat-adv-generate').click(function(){
            shortcode_fat_adv_generate();
        });
        $('input.bt-sc-fat-3d-generate').click(function(){
            shortcode_fat_3d_generate();
        });
        $('input.bt-sc-fat-slide-generate').click(function(){
            shortcode_fat_slide_generate();
        });
        $('input.bt_sc_fat_justified-generate').click(function(){
            shortcode_fat_justified_generate();
        });
        $('input.bt_sc_fat_album-generate').click(function(){
            shortcode_fat_album_generate();
        });

        initSelect2();

    });
    function fat_gallery_dependence($elm) {
        var $value = $elm.val(),
            $data_id = $elm.attr('id');
        $('[data-dependence-id="' + $data_id + '"]').hide();
        $('[data-dependence-id="' + $data_id + '"]').each(function () {
            if ($(this).attr('data-value') == $value) {
                $(this).fadeIn();
            }
        });
    }

    function shortcode_fat_adv_generate() {
        var $layout_type = $('#sc_fat_adv_layout_type').val(),
            $display_type = $('#sc_fat_adv_display_type').val(),
            $overlay_style = $('#sc_fat_adv_overlay_style').val(),
            $popup_type = $('#sc_fat_adv_popup_type').val(),
            $popup_transition = $('#sc_fat_adv_popup_transition').val(),
            $image_width = $('#sc_fat_adv_image_width').val(),
            $image_height = $('#sc_fat_adv_image_height').val(),
            $data_source = $('#sc_fat_adv_data_source').val(),
            $category = $('#sc_fat_adv_category').val(),
            $gallery_ids = $('#sc_fat_adv_gallery_ids').val(),
            $show_category = $('#sc_fat_show_category').val(),
            $default_category = $('#sc_fat_default_category').val(),
            $sc_fat_show_all_category_filter = $('#sc_fat_show_all_category_filter').val(),
            $category_style = $('#sc_fat_adv_category_style').val(),
            $filter_type = $('#sc_fat_adv_filter_type').val(),
            $animation_filter = $('#sc_fat_adv_animation_filter').val(),
            $column = $('#sc_fat_adv_column').val(),
            $total_item = $('#sc_fat_total_item').val(),
            $view_more = $('#sc_fat_adv_view_more').val(),
            $padding = $('#sc_fat_adv_padding').val(),
            $bg_color = $('#sc_fat_adv_bg_color').val(),
            $title_style = $('#sc_fat_adv_title_style').val(),
            $order_by = $('#sc_fat_adv_order_by').val(),
            $order = $('#sc_fat_adv_order').val(),
            $shortcode = $('#sc_fat_adv_output');

        var $image_size = '';
        if(typeof $category =='undefined' || $category==null){
            $category = '';
        }
        if(typeof $gallery_ids =='undefined' || $gallery_ids==null){
            $gallery_ids = '';
        }
        if($layout_type!='masonry'){
            if($image_width=='' || typeof $image_width=='undefined'){
                $image_width = '475';
            }
            if($image_height==''|| typeof $image_height=='undefined'){
                $image_height = '475';
            }
        }
        if($image_width!='' && $image_height!=''){
            $image_size = $image_width + 'x' + $image_height;
        }

        var $output = '[fat_adv_gallery layout_type="' + $layout_type + '"';
        $output += ' display_type="' + $display_type + '"';
        $output += ' overlay_style="' + $overlay_style + '"';
        $output += ' popup_type="' + $popup_type + '"';
        $output += ' popup_transition="' + $popup_transition + '"';
        $output += ' image_size="' + $image_size + '"';
        $output += ' data_source="' + $data_source + '"';

        if($data_source=='' || typeof $data_source =='undefined'){
            $output += ' category="' + $category + '"';
        }else{
            $output += ' gallery_ids="' + $gallery_ids + '"';
        }
        if($data_source==''|| typeof $data_source =='undefined'){
            $output += ' show_category="' + $show_category + '"';
            $output += ' default_category="' + $default_category + '"';
            $output += ' show_root_category="' + $sc_fat_show_all_category_filter + '"';
            $output += ' category_style="' + $category_style + '"';
        }

        $output += ' filter_type="' + $filter_type + '"';
        $output += ' animation_filter="' + $animation_filter + '"';
        $output += ' column="' + $column + '"';
        $output += ' item="' + $total_item + '"';
        $output += ' show_pagging="' + $view_more + '"';
        $output += ' padding="' + $padding + '"';
        $output += ' bg_color="' + $bg_color + '"';
        $output += ' title_style="' + $title_style + '"';
        $output += ' order_by="' + $order_by + '"';
        $output += ' order="' + $order + '"';
        $output += ' ]';
        $('textarea',$shortcode).text($output);

        $shortcode.fadeIn();
    }
    function shortcode_fat_3d_generate(){
        var $data_source = $('#sc_fat_3d_data_source').val(),
            $category = $('#sc_fat_3d_category').val(),
            $gallery_ids = $('#sc_fat_3d_gallery_ids').val(),
            $nav_position = $('#sc_fat_3d_navigation_position').val(),
            $auto_play = $('#sc_fat_3d_auto_play').val(),
            $shortcode = $('#sc_fat_3d_output'),
            $width = $('#sc_fat_3d_image_width').val(),
            $height = $('#sc_fat_3d_image_height').val();

        var $output = '[fat_gallery_3d auto_play="' + $auto_play + '"';
        $output += ' nav_position="' + $nav_position + '"';
        $output += ' image_width="' + $width + '"';
        $output += ' image_height="' + $height + '"';

        if(typeof $category =='undefined' || $category==null){
            $category = '';
        }
        if(typeof $gallery_ids =='undefined' || $gallery_ids==null){
            $gallery_ids = '';
        }

        if($data_source==''|| typeof $data_source =='undefined'){
            $output += ' category="' + $category + '"';
        }else{
            $output += ' gallery_ids="' + $gallery_ids + '"';
        }
        $output += ' ]';

        $('textarea',$shortcode).text($output);
        $shortcode.fadeIn();
    }
    function shortcode_fat_slide_generate() {
        var  $display_type = $('#sc_fat_adv_display_type').val(),
            $center = $('#sc_fat_slide_center').val(),
            $two_halves = $('#sc_fat_slide_two_halves').val(),
            $image_width = $('#sc_fat_slide_image_width').val(),
            $image_height = $('#sc_fat_slide_image_height').val(),
            $data_source = $('#sc_fat_slide_data_source').val(),
            $category = $('#sc_fat_slide_category').val(),
            $gallery_ids = $('#sc_fat_slide_gallery_ids').val(),
            $column = $('#sc_fat_slide_column').val(),
            $margin = $('#sc_fat_slide_margin').val(),
            $auto_play = $('#sc_fat_slide_auto_play').val(),
            $show_nav = $('#sc_fat_slide_show_navigation').val(),
            $show_dot = $('#sc_fat_slide_show_dot').val(),
            $nav_position = $('#sc_fat_slide_nav_position').val(),
            $shortcode = $('#sc_fat_slide_output');

        var $image_size = '';
        if($image_width=='' || typeof $image_width=='undefined'){
            $image_width = '475';
        }
        if($image_height==''|| typeof $image_height=='undefined'){
            $image_height = '475';
        }

        if(typeof $category =='undefined' || $category==null){
            $category = '';
        }
        if(typeof $gallery_ids =='undefined' || $gallery_ids==null){
            $gallery_ids = '';
        }
        if($image_width!='' && $image_height!=''){
            $image_size = $image_width + 'x' + $image_height;
        }

        var $output = '[fat_gallery_slider auto_play="' + $auto_play + '"';
        $output += ' columns="' + $column + '"';
        $output += ' margin="' + $margin + '"';
        $output += ' center="' + $center + '"';
        $output += ' two_halves="' + $two_halves + '"';
        $output += ' show_nav="' + $show_nav + '"';
        $output += ' nav_position="' + $nav_position + '"';
        $output += ' show_dot="' + $show_dot + '"';
        $output += ' image_size="' + $image_size + '"';
        $output += ' data_source="' + $data_source + '"';

        if($data_source==''|| typeof $data_source =='undefined'){
            $output += ' category="' + $category + '"';
        }else{
            $output += ' gallery_ids="' + $gallery_ids + '"';
        }
        $output += ' ]';
        $('textarea',$shortcode).text($output);
        $shortcode.fadeIn();
    }
    function shortcode_fat_justified_generate() {
        var $data_source = $('#sc_fat_justified_data_source').val(),
            $category = $('#sc_fat_justified_category').val(),
            $gallery_ids = $('#sc_fat_justified_gallery_ids').val(),
            $show_category = $('#sc_fat_justified_show_category').val(),
            $category_style = $('#sc_fat_justified_category_style').val(),
            $row_height = $('#sc_fat_justified_row_height').val(),
            $total_item = $('#sc_fat_justified_total_item').val(),
            $view_more = $('#sc_fat_justified_view_more').val(),
            $margin = $('#sc_fat_justified_margin').val(),
            $bg_color = $('#sc_fat_justified_bg_color').val(),
            $title_style = $('#sc_fat_justified_title_style').val(),
            $shortcode = $('#sc_fat_justified_output');

        if(typeof $category =='undefined' || $category==null){
            $category = '';
        }
        if(typeof $gallery_ids =='undefined' || $gallery_ids==null){
            $gallery_ids = '';
        }
        var $output = '[fat_gallery_justified ';
        $output += ' data_source="' + $data_source + '"';

        if($data_source=='' || typeof $data_source =='undefined'){
            $output += ' category="' + $category + '"';
        }else{
            $output += ' gallery_ids="' + $gallery_ids + '"';
        }
        if($data_source==''|| typeof $data_source =='undefined'){
            $output += ' show_category="' + $show_category + '"';
            $output += ' category_style="' + $category_style + '"';
        }
        $output += ' row_height="' + $row_height + '"';
        $output += ' item="' + $total_item + '"';
        $output += ' show_pagging="' + $view_more + '"';
        $output += ' margin="' + $margin + '"';
        $output += ' bg_color="' + $bg_color + '"';
        $output += ' category_style="' + $category_style + '"';
        $output += ' title_style="' + $title_style + '"';
        $output += ' ]';
        $('textarea',$shortcode).text($output);

        $shortcode.fadeIn();
    }
    function shortcode_fat_album_generate() {
        var $image_width = $('#sc_fat_album_image_width').val(),
            $gallery_ids = $('#sc_fat_album_gallery_ids').val(),
            $image_height = $('#sc_fat_album_image_height').val(),
            $data_source = $('#sc_fat_album_data_source').val(),
            $show_category = $('#sc_fat_album_show_category').val(),
            $category = $('#sc_fat_album_category').val(),
            $column = $('#sc_fat_album_columns').val(),
            $column_each_album = $('#sc_fat_album_columns_of_album').val(),
            $total_item_on_album = $('#sc_total_item_on_album').val(),
            $padding = $('#sc_fat_album_padding').val(),
            $has_box_shadow = $('#sc_fat_album_has_box_shadow').val(),
            $has_padding = $('#sc_fat_album_has_padding').val(),
            $shortcode = $('#sc_fat_album_output');

        var $image_size = '';
        if(typeof $category =='undefined' || $category==null){
            $category = '';
        }
        if($image_width!='' && $image_height!=''){
            $image_size = $image_width + 'x' + $image_height;
        }

        var $output = '[fat_gallery_album column="'+ $column + '"';
        $output += ' data_source="' + $data_source + '"';
        if($data_source=='' || typeof $data_source =='undefined'){
            $output += ' category="' + $category + '"';
            $output += ' show_category="' + $show_category + '"';
        }else{
            $output += ' gallery_ids="' + $gallery_ids + '"';
        }
        $output += ' column_of_album="' + $column_each_album + '"';
        $output += ' total_item_of_album="' + $total_item_on_album + '"';
        $output += ' padding="' + $padding + '"';
        $output += ' has_box_shadow="' + $has_box_shadow + '"';
        $output += ' has_padding="' + $has_padding + '"';
        $output += ' image_size="' + $image_size + '"';
        $output += ' popup_transition="slide"';
        $output += ' order_by="none" order="DESC" ]';
        $('textarea',$shortcode).text($output);

        $shortcode.fadeIn();
    }
    function initSelect2(){
        if (jQuery.isFunction(jQuery.fn.selectize)){
            jQuery('.select2').selectize({
                plugins: ['remove_button', 'drag_drop'],
                searchField: 'text',
                delimiter: ',',
                persist: false
            });
        }
        /*jQuery('.select2').each(function () {
            var param_name = jQuery(this).attr('data-param-name');
            var hidden = jQuery('input[id="' + param_name + '"]');

            if (hidden.val() != '' && hidden.val() !=null && typeof hidden.val() != 'undefined') {
                var $val = hidden.val().split(','),
                    $data = [],
                    $option = null;
                for(var $i=0;$i< $val.length; $i++){
                    $option = jQuery(this).find('option[value="'+ $val[$i] +'"]');
                    if(typeof $option !='undefined'){
                        $data.push({'id': $val[$i],'text': $option.text()});
                    }
                    jQuery($option).detach();
                }
                var $options = jQuery(this).find('option');
                for(var $i=0;$i<$options.length;$i++){
                    $option = jQuery($options[$i]);
                    $data.push({'id': $option.val(),'text': $option.text()});
                }
                jQuery($options).detach();

                jQuery(this).select2({data: $data});
                jQuery(this).val($val).trigger('change');
            }else{
                hidden.val('');
                jQuery(this).select2();
            }
            jQuery(this).on("change", function () {
                jQuery(hidden).val(jQuery(this).val());
            })
        });

        jQuery(".select2").on("select2:select", function (evt) {
            var element = evt.params.data.element;
            var $element = jQuery(element);
            $element.detach();
            jQuery(this).append($element);
            jQuery(this).trigger("change");
        });
        jQuery(".select2").on("select2:unselect", function (evt) {
            var element = evt.params.data.element;
            var $element = jQuery(element);
            jQuery(this).append(element);
            jQuery(this).trigger("change");
        });*/
    }
})(jQuery);
