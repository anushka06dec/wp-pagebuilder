if (jQuery.isFunction(jQuery.fn.selectize)) {
    jQuery('.select2').each(function () {
        var $this = jQuery(this),
            $options = jQuery('option',this),
            $data_param_name = jQuery(this).attr('data-param-name'),
            $selected_value = jQuery('#' + $data_param_name).val(),
            $items = [];
        if(typeof $selected_value !='undefined' && $selected_value !=''){
            $items = $selected_value.split(',');
        }

        jQuery(this).selectize({
            plugins: ['remove_button', 'drag_drop'],
            searchField: 'text',
            delimiter: ',',
            items: $items,
            persist: false,
            onChange: function (value) {
                jQuery('#' + $data_param_name).val(value);
            }
        });
    });

}
;