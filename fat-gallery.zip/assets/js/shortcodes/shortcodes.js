(function($) {
    tinymce.create("tinymce.plugins.fat_adv_button_plugin", {

        //url argument holds the absolute url of our plugin directory
        init : function(ed, url) {

            //add new button
            ed.addButton("fa_adv_button", {
                title : "FAT Advance Gallery",
                cmd : "fat_adv_command",
                image : "https://cdn3.iconfinder.com/data/icons/softwaredemo/PNG/32x32/Circle_Green.png"
            });

            //button functionality.
            ed.addCommand("fat_adv_command", function() {
                $.ajax({
                    url: ajaxurl,
                    data: ({
                        action: 'roninwp_fat_adv_shortcode_generate'
                    }),
                    success: function (data) {
                        ed.execCommand("mceInsertContent", 0, data);
                    },
                    error: function () {
                        return null;
                    }
                });

                /*var selected_text = ed.selection.getContent();
                var return_text = "<span style='color: green'>" + selected_text + "</span>";
                ed.execCommand("mceInsertContent", 0, return_text);
                console.log('fat_adv_command');*/
            });

        },

        createControl : function(n, cm) {
            console.log('create control');
            return null;
        },

        getInfo : function() {
            return {
                longname : "Extra Buttons",
                author : "Narayan Prusty",
                version : "1"
            };
        }
    });

    tinymce.PluginManager.add("fat_adv_button_plugin", tinymce.plugins.fat_adv_button_plugin);
})(jQuery);