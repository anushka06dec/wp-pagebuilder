<?php

function fat_multi_select_settings_field_shortcode_param($settings, $value)
{
    $html =  '<input type="hidden" name="' . esc_attr($settings['param_name']) . '" id="' . $settings['param_name'] . '" class="wpb_vc_param_value wpb-textinput" value="' . esc_attr($value) . '" /> ';
    $html .= '<select id="' . $settings['param_name'] . '_select2" data-param-name="' . $settings['param_name'] . '" class="select2 wpb_vc_param_value wpb-input wpb-select" multiple="multiple" >';
    $options = isset($settings['options']) ? $settings['options'] : '';
    if (is_array($options)) {
        foreach ($options as $t => $v) {
            $html .= '<option value="' . $v . '"  >' . htmlspecialchars($t) . '</option>';
        }
    }
    $html .= '</select>';
    return $html;
}

function add_new_type()
{
    if (function_exists('vc_add_shortcode_param')) {
        vc_add_shortcode_param('select2', 'fat_multi_select_settings_field_shortcode_param',  plugins_url() . '/fat-gallery/assets/js/select2/main.js');
    }
}

add_action('vc_before_init', 'add_new_type');
