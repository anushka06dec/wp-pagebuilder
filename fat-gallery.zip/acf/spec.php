<?php
/**
 * Add the question & answer meta box
 * @var [type]
 */
global $wpalchemy_media_access;
global $class_metabox_gallery;
$wpalchemy_media_access = new WPAlchemy_MediaAccess();
$class_metabox_gallery = new FAT_WPAlchemy_MetaBox(array
(
    'id' => 'fat_gallery_acf',
    'title' => __('Gallery', 'fat-gallery'),
    'template' => plugin_dir_path(__FILE__) . 'custom-field.php',
    'types' => array(FAT_GALLERY_POST_TYPE),
    'autosave' => TRUE,
    'priority' => 'low',
    'context' => 'normal',
    'hide_editor' => FALSE
));
