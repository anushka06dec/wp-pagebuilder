<?php
/**
 * Created by PhpStorm.
 * User: roninwp
 * Date: 7/6/15
 * Time: 11:07 AM
 */
global $wpalchemy_media_access;
?>
<div class="gallery-custom-fields" data-wpalchemy-media-group="1">
    <?php
    while ($mb->have_fields_and_multi('galleries', 1)): ?>
        <?php $mb->the_group_open(); ?>

        <?php $mb->the_field('title'); ?>
        <div>
            <label><?php esc_html_e('Title', 'fat-gallery'); ?></label>
            <input class="form-control" type="text" name="<?php $mb->the_name(); ?>"
                   value="<?php $mb->the_value(); ?>"/>
        </div>
        <?php $mb->the_field('description'); ?>
        <div>
            <label><?php esc_html_e('Description', 'fat-gallery'); ?></label>
            <textarea rows="5" class="form-control" type="text" name="<?php $mb->the_name(); ?>"><?php echo sprintf('%s',$mb->the_value()); ?></textarea>
        </div>

        <?php $mb->the_field('video'); ?>
        <div>
            <label><?php esc_html_e('Video link', 'fat-gallery'); ?></label>
            <input class="form-control" type="text" name="<?php $mb->the_name(); ?>"
                   value="<?php $mb->the_value(); ?>"/>
        </div>

        <?php $mb->the_field('video_iframe'); ?>
        <div>
            <label><?php esc_html_e('Video iframe embbed', 'fat-gallery'); ?></label>
            <input class="form-control" type="text" name="<?php $mb->the_name(); ?>"
                   value="<?php $mb->the_value(); ?>"/>
        </div>

        <?php $mb->the_field('link_detail'); ?>
        <div>
            <label><?php esc_html_e('Link detail', 'fat-gallery'); ?></label>
            <input class="form-control" type="text" name="<?php $mb->the_name(); ?>"
                   value="<?php $mb->the_value(); ?>"/>
        </div>

        <?php $mb->the_field('link_target'); ?>
        <div>
            <label><?php esc_html_e('Open type', 'fat-gallery'); ?></label>
            <div>
                <input style="width: 15px" type="radio" name="<?php $mb->the_name(); ?>" value="_self" <?php if($mb->get_the_value()=='_self'){ echo 'checked';} ?> > <?php echo esc_html__('Open same window'); ?><br>
                <input style="width: 15px" type="radio" name="<?php $mb->the_name(); ?>" value="_blank" <?php if($mb->get_the_value()=='_blank'){ echo 'checked';} ?> > <?php echo esc_html__('Open new window'); ?><br>
            </div>
        </div>

        <div>
            <?php $mb->the_field('imgurl'); ?>
            <label><?php esc_html_e('Image', 'fat-gallery'); ?></label>
            <?php $wpalchemy_media_access->setGroupName('img-n' . $mb->get_the_index())->setInsertButtonLabel('Insert'); ?>

            <?php echo $wpalchemy_media_access->getField(array('name' => $mb->get_the_name(), 'value' => $mb->get_the_value())); ?>

        </div>

        <div class='button-groups'>
            <?php echo $wpalchemy_media_access->getButton(); ?>
            <a href="#" class="dodelete button">Remove</a>
        </div>

        <?php $mb->the_group_close(); ?>
    <?php endwhile; ?>
    <div style="clear: both;"></div>
    <p class="footer-button-groups">
        <a href="#" class="docopy-galleries button"><?php esc_html_e('Add item', 'fat-gallery'); ?></a>

        <a href="#" class="dodelete-galleries button">Remove All</a>
    </p>
</div>
<script type="text/javascript">
    (function ($) {
        $(document).ready(function () {
            function show_fat_gallery_format() {
                var $value = $('input[name="fat_gallery_format"]:checked').val();
                if ($value == 'image') {
                    $('#fat_gallery_acf_metabox').fadeOut(function () {
                        $('#fat-meta-box-gallery').fadeIn();
                    });
                } else {
                    $('#fat-meta-box-gallery').fadeOut(function () {
                        $('#fat_gallery_acf_metabox').fadeIn();
                    });
                }
            }

            $('input[name="fat_gallery_format"]', '#fat-meta-box-gallery-type').change(function () {
                show_fat_gallery_format();
            });

            show_fat_gallery_format();
        })
    })(jQuery)
</script>